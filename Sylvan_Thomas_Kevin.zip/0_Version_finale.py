#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('400x400')

#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=400,height=400)
can1.place(x=0,y=0)
#creation des cases images
caseeau=PhotoImage(file="eau.gif")
casepont=PhotoImage(file="pont.gif")
casevillage=PhotoImage(file="housekdc.gif")
rue=PhotoImage(file="rue.gif")
rue_tourned=PhotoImage(file="rue_tourned.gif")
rued=PhotoImage(file="rued.gif")
rue_tourneg=PhotoImage(file="rue_tourneg.gif")
rue_tournedg=PhotoImage(file="rue_tournedg.gif")
rouge=PhotoImage(file="rouge.gif")
rue_tourne=PhotoImage(file="rue_tourne.gif")
yd=PhotoImage(file="yd.gif")
yc=PhotoImage(file="yc.gif")
jiren=PhotoImage(file="jiren.png")
Bo=PhotoImage(file="liasse.png")
maison=PhotoImage(file="maisond.png")
citys=PhotoImage(file="citys.png")
lave=PhotoImage(file="lave3.png")
pont1=PhotoImage(file="pont1.gif")
chateau=PhotoImage(file="chateau1.png")
chemin=PhotoImage(file="chemin.png")
vide=PhotoImage(file="vide.gif")

#déplacements héro
droite1=PhotoImage(file="perso.png")
droite2=PhotoImage(file="perso_walking.png")
droite3=PhotoImage(file="perso_walking_2.png")
droite4=PhotoImage(file="perso_walking.png")
monte1=PhotoImage(file="perso.png")
monte2=PhotoImage(file="perso_walking_2.png")
monte3=PhotoImage(file="perso_walking.png")
monte4=PhotoImage(file="perso.png")

tab_droite=[droite1,droite2,droite3,droite4]
tab_haut=[monte1,monte2,monte3,monte4]
compteur_de_pas=0

#mvmnt du héro
droite1=PhotoImage(file="perso.png")
droite2=PhotoImage(file="perso_walking.png")
droite3=PhotoImage(file="perso_walking_2.png")
monte1=PhotoImage(file="perso.png")
monte2=PhotoImage(file="perso_walking.png")
monte3=PhotoImage(file="perso_walking_2.png")

tab_droite=[droite1,droite2,droite3]
tab_haut=[monte1,monte2,monte3]
compteur_de_pas=0
compteur_jiren=0
#creation de la matrice
L0=["Rd","R","Rdg","m","m","Rd","R","Rdg"]
L1=["V","E","Ru","R","R","yc","E","P"]
L2=["P","E","E","E","E","P","E","P"]
L3=["P","E","Rd","R","yd","Rg","E","P"]
L4=["Ru","R","Rg","c","P","E","E","P"]
L5=["m","m","m","m","Ru","R","R","Rg"]
ma_matrice=[L0,L1,L2,L3,L4,L5]

#creation de la map
dico={"E":caseeau,"P":rue,"V":casevillage,"Rd":rue_tourned,"R":rued,"Rg":rue_tourneg,"Rdg":rue_tournedg,"Ro":rouge,"Ru":rue_tourne,"yd":yd,"yc":yc,"Bo":Bo,"j":jiren,"m":maison,"c":citys}
for i in range(6):
    for j in range(8):
        can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
#position du personnage
posX=200  #abscisse de départ
posY=250 #ordonnée de départ
posBoX=200
posBoY=150
posXJ1=100
posYJ1=150
posXJ2=250
posYJ2=0
posXBO=100
posYBO=50
niveau=1

perso=can1.create_image(posX,posY,image=monte2,anchor="nw")   
Bonus=can1.create_image(posBoX,posBoY,image=Bo,anchor="nw")
Jiren1=can1.create_image(posXJ1,posYJ1,image=jiren,anchor="nw")
Jiren2=can1.create_image(posXJ2,posYJ2,image=jiren,anchor="nw")
Boss=can1.create_image(posXBO,posYBO,image=vide,anchor="nw")


#zone de textes
texte_pnj=can1.create_text(190,310,text="",font=("Arial",14),fill="red")
texte_argent=can1.create_text(200,340,text="",font=("Arial",16),fill="black")
texte_evenement=can1.create_text(210,390,text="",font=("Arial",16),fill="purple")
#variables
arg=100
amendes=0
niveau=1
coeff=1
cases_interdites=["E","m","c","l"]


#textes d'intro
can1.itemconfig(texte_pnj,text="Bienvenue esquive les jirens qui veulent te raquete")
can1.itemconfig(texte_argent,text="ton argent:"+str(arg)+" euros")
can1.itemconfig(texte_pnj,text="va dans ta planque et attention au shoufs")
   


def ennemi():
    global arg,amendes
    can1.itemconfig(texte_evenement,text="jiren te raquete tu perds 50 euros")
    
    arg-=50
    can1.itemconfig(texte_argent,text="ton argent:"+str(arg)+" euros")
    amendes+=1
    if amendes==1:
        can1.itemconfig(texte_argent,text="Il te reste"+str(arg)+" euros")
        can1.itemconfig(texte_evenement,text="attention tu viens de perdre 50 bal")
    elif amendes==2:
        can1.itemconfig(texte_pnj,text="Il te reste"+str(arg)+" euros")  
        can1.itemconfig(texte_evenement,text="attention tu viens de perdre 50 bal")
    elif amendes==3:
        can1.itemconfig(texte_pnj,text="Tu as perdu tout ton argent")    
        can1.after(2000,game_over)

def Clavier(event):
    global posX,posY
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    if touche=='Up' and ma_matrice[ligne-1][colonne] not in cases_interdites:
        mvt_haut()
    if touche=="Right" and ma_matrice[ligne][colonne+1]not in cases_interdites:
        mvt_droite()
    if touche=="Left" and ma_matrice[ligne][colonne-1]not in cases_interdites:
        mvt_gauche()
    if touche=="Down" and ma_matrice[ligne+1][colonne]not in cases_interdites:
        mvt_bas()
        

def mvt_gauche():
    """deplace le perso vers la gauche"""
    global perso,posY,posX,compteur_de_pas,texte_pnj
    posX=posX-50
    if posX<0 :
        posX=0
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas])
    compteur_de_pas+=1
    if compteur_de_pas==3:
        compteur_de_pas=0
    can1.coords(perso,posX,posY)
    
    test_case()
    
def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,niveau
    posY=posY-50
    if posY<0 :
        posY=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas])
    compteur_de_pas+=1
    if compteur_de_pas==3:
        compteur_de_pas=0
    
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    test_case()
    
def mvt_droite():
    """deplace à droite le perso"""    
    global perso,posX,posY,compteur_de_pas
    posX=posX+50
    if posX>400 :
        posX=400
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas])
    compteur_de_pas+=1
    if compteur_de_pas==3:
        compteur_de_pas=0
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    test_case()
    
def mvt_bas():
    """deplace le perso vers le bas"""
    global perso,posY,posX,compteur_de_pas
    posY=posY+50
    if posY>250 :
        posY=250
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas])
    compteur_de_pas+=1
    if compteur_de_pas==3:
        compteur_de_pas=0
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    test_case()
    
def bonus():
    global arg,amendes,posBoX,posBoY
    arg+=50
    can1.itemconfig(texte_evenement,text="tu trouve une grosse liasse d'argent")
    can1.itemconfig(texte_argent,text="il te reste "+str(arg)+" euros")
    amendes-=1
    posBoX+=10000
    posBoY+=10000
    can1.coords(Bonus,posBoX,posBoY)
    
def test_case():
    global possX,posY,posYJ1,posXJ1,posXJ2,posYJ2,posBoX,posXBO,posBoY,posYBO,niveau
    colonne=posX//50
    ligne=posY//50    
    if posX==posXJ1 and posY==posYJ1 or posXJ2==posX and posYJ2==posY:
        ennemi()
    if posBoX==posX and posBoY==posY and niveau==1: 
        bonus()
    if ma_matrice[ligne][colonne]=="V":
        maison()  
    if ma_matrice[ligne][colonne]=="C":
        You_win()  
def game_over():
    """envoie la fenetre de game over"""
    
    can1=Canvas(Mafenetre,bg="black",width=400,height=400)
    can1.place(x=0,y=0)
    can1.create_text(150,200,text="GAME OVER",font=("Impact",30),fill="red")    

def You_win():
    """affiche la victoire"""
    can1=Canvas(Mafenetre,bg="red",width=400,height=400)
    can1.place(x=0,y=0)
    can1.create_text(200,200,text=" YOU WIN",font=("Impact",50),fill="yellow")


def maison():
    """2eme niveau"""
    global can1,text_pnj,perso,ma_matrice,posX,posY,texte_argent,texte_evenement,niveau
    niveau+=1
    can1.destroy()
    ma_matrice=[]
    #creation matrice can2
    l0=["C","ch","ch","l","l","ch","ch","ch"]
    l1=["ch","ch","ch","p","p","ch","ch","ch"]
    l2=["l","l","l","l","l","l","ch","ch"]
    l3=["ch","ch","ch","l","l","l","ch","ch"]
    l4=["ch","V","ch","p","p","p","p","ch"]
    l5=["ch","ch","ch","l","l","l","ch","ch"]
    ma_matrice=[l0,l1,l2,l3,l4,l5]
    can1=Canvas(Mafenetre,bg="white",width=400,height=400)
    can1.place(x=0,y=0)
    #creation de la 2eme map
    dico2={"l":lave,"p":pont1,"C":chateau,"ch":chemin,"V":casevillage,"R":rouge}
    for i in range(6):
        for j in range(8):
            can1.create_image(50*j,50*i,image=dico2[ma_matrice[i][j]],anchor="nw")
    posX=100 #abscisse de départ
    posY=200 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=monte2,anchor="nw")
    
    texte_pnj=can1.create_text(190,310,text="",font=("Arial",14),fill="red")
    texte_argent=can1.create_text(200,340,text="",font=("Arial",16),fill="black")
    texte_evenement=can1.create_text(210,390,text="",font=("Arial",16),fill="purple")
    
    can1.itemconfig(texte_argent,text="ton argent:"+str(arg)+" euros")
    can1.itemconfig(texte_pnj,text="attention au shoufs")
    can1.itemconfig(texte_evenement,text="rejoins le chateau")
    
    Boss=can1.create_image(posXBO,posYBO,image=jiren,anchor="nw")
    
    Boss_final()
    
    can1.focus_set()
    can1.bind('<Key>',Clavier)
 
    
def Boss_final():
    """le jiren qui bouge a la fin"""
    global posXBO,posYBO,compteur_jiren,coeff,Boss
    
    
    posXBO=posXBO+coeff*50
    if posXBO>=250 :
        coeff=-1
        
    if posXBO<=0 :
        coeff=1
        
    compteur_jiren+=1
    if niveau==2 and posXBO==posX and posYBO==posY:
        game_over()
    can1.itemconfig(Boss,image=jiren)
    can1.coords(Boss,posXBO,posYBO)
    can1.after(250,Boss_final)
   

    

can1.focus_set()    
can1.bind('<Key>',Clavier)
Mafenetre.mainloop()