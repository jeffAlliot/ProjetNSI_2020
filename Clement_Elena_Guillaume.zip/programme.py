#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('750x700')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=750,height=700)
can1.place(x=0,y=0)
#creation des cases images
herbe=PhotoImage(file="herbe.gif")
chemin=PhotoImage(file="chemin.gif")
chemin2=PhotoImage(file="chemin2.gif")
viragechemin=PhotoImage(file="virage_chemin.gif")
viragechemin2=PhotoImage(file="virage_chemin2.gif")
viragechemin3=PhotoImage(file="virage_chemin3.gif")
viragechemin4=PhotoImage(file="virage_chemin4.gif")
casevillage=PhotoImage(file="village.gif")
barrieredroite=PhotoImage(file="barriere_droite.gif")
barrieregauche=PhotoImage(file="barriere_gauche.gif")
hautdroit=PhotoImage(file="hautdroit.gif")
hautgauche=PhotoImage(file="hautgauche.gif")
map1=PhotoImage(file="map1.gif")
map2=PhotoImage(file="map2.gif")
map3=PhotoImage(file="map3.gif")
map4=PhotoImage(file="map4.gif")
map5=PhotoImage(file="map5.gif")
map6=PhotoImage(file="map6.gif")
map7=PhotoImage(file="map7.gif")
map30=PhotoImage(file="map30.gif")
map31=PhotoImage(file="map31.gif")
map32=PhotoImage(file="map32.gif")
map42=PhotoImage(file="map42.gif")
map43=PhotoImage(file="map43.gif")
map44=PhotoImage(file="map44.gif")
map45=PhotoImage(file="map45.gif")
map46=PhotoImage(file="map46.gif")
map49=PhotoImage(file="map49.gif")
map50=PhotoImage(file="map50.gif")
map51=PhotoImage(file="map51.gif")
map52=PhotoImage(file="map52.gif")
map53=PhotoImage(file="map53.gif")
map56=PhotoImage(file="map56.gif")
map58=PhotoImage(file="map58.gif")
map59=PhotoImage(file="map59.gif")
map60=PhotoImage(file="map60.gif")
droite1=PhotoImage(file="droite1.gif")
droite2=PhotoImage(file="droite2.gif")
gauche1=PhotoImage(file="gauche1.gif")
gauche2=PhotoImage(file="gauche2.gif")
monte1=PhotoImage(file="personnage1.gif")
monte2=PhotoImage(file="personnage2.gif")
avant=PhotoImage(file="avant.gif")
avant2=PhotoImage(file="avant2.gif")
avant3=PhotoImage(file="avant3.gif")
avantbonus=PhotoImage(file="avantbonus.gif")
coffreterre=PhotoImage(file="coffre_terre.gif")
borduredroite=PhotoImage(file="borduredroit.gif")
borduregauche=PhotoImage(file="borduregauche.gif")
papy=PhotoImage(file="papi.gif")
mur0=PhotoImage(file="mur0.gif")
mur1=PhotoImage(file="mur1.gif")
mur2=PhotoImage(file="mur2.gif")
sol=PhotoImage(file="sol.gif")
sortie=PhotoImage(file="sortie.gif")
herbetrou=PhotoImage(file="herbe_trou.gif")
fleur1=PhotoImage(file="fleur.gif")
lacbasdroit=PhotoImage(file="lac_bas_droit.gif")
lacbasgauche=PhotoImage(file="lac_bas_gauche.gif")
lacdroit=PhotoImage(file="lac_droit.gif")
lacgauche=PhotoImage(file="lac_gauche.gif")
lachautdroit=PhotoImage(file="lac_haut_droit.gif")
lachautgauche=PhotoImage(file="lac_haut_gauche.gif")
tab_droite=[droite1,droite2]
tab_gauche=[gauche1,gauche2]
tab_haut=[monte1,monte2]
tab_bas=[avant,avant2,avant3]
compteur_de_pas=0
coffre=0

#NIVEAU 1
def niveau1():
    global can1,text_pnj,perso,ma_matrice,posX,posY,ma_matrice,dico
    ma_matrice=[]
    can1=Canvas(Mafenetre,bg="white",width=750,height=700)
    can1.place(x=0,y=0)    
    #creation de la matrice
    L0=["HG","M1","M2","M3","M4","M5","HG","HD","HG","HD","HG","HD","HG"]
    L1=["BD","M6","M30","M31","M32","M7","E","E","E","E","E","E","BG"]
    L2=["BD","M42","M43","M44","M45","M46","E","E","E","E","F","E","BG"]
    L3=["BD","M49","M50","M51","M52","M53","E","E","E","VC2","P2","P2","BG"]
    L4=["BD","M56","V","M58","M59","M60","E","F","E","P","E","E","BG"]
    L5=["BD","E","P","E","E","E","VC2","P2","P2","VC4","E","E","BG"]
    L6=["BD","E","P","E","E","E","P","E","E","E","E","E","BG"]
    L7=["BD","E","P","P2","P2","P2","VC4","E","LHG","LHD","E","E","BG"]
    L8=["BD","F","P","E","E","E","E","E","LBG","LBD","E","E","BG"]
    L9=["BD","E","P","E","E","F","E","E","E","E","E","E","BG"]
    L10=["BD","E","P","E","E","E","E","E","E","E","F","E","BG"]
    L11=["BD","E","P","E","E","E","E","E","E","E","E","E","BG"]
    L12=["BD","E","P","E","E","E","E","F","E","E","E","E","BG"]
    L13=["BD","E","P","E","F","E","E","E","E","E","E","E","BG"]
    L14=["BD","E","P","E","E","E","E","E","E","E","E","E","BG"]
    ma_matrice=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14]
    #creation de la map                                                            
    dico={"E":herbe,"P":chemin,"V":casevillage,"A":coffreterre,"BD":borduredroite,"BG":borduregauche,"P2":chemin2,
          "VC":viragechemin,"VC2":viragechemin2,"VC3":viragechemin3,"VC4":viragechemin4,"BRD":barrieredroite, 
          "BRG":barrieregauche,"HD":hautdroit,"HG":hautgauche,"M1":map1,"M2":map2,"M3":map3,"M4":map4,"M5":map5,
          "M6":map6,"M7":map7,"M30":map30,"M31":map31,"M32":map32,"M42":map42,"M43":map43,"M44":map44,"M45":map45,
          "M46":map46,"M49":map49,"M50":map50,"M51":map51,"M52":map52,"M53":map53,"M56":map56,"M58":map58,"M59":map59,
          "M60":map60,"CT":coffreterre,"HT":herbetrou,"LBD":lacbasdroit,"LBG":lacbasgauche,"LD":lacdroit,"LG":lacgauche,
          "LHD":lachautdroit,"LHG":lachautgauche,"F":fleur1}
    for i in range(15):
        for j in range(13):
            can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
    #position du personnage
    posX=100 #abscisse de départ
    posY=650 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=monte2,anchor="nw")
    
def start():
    """écran de début"""
    can1=Canvas(Mafenetre,bg="black",width=750,height=700)
    can1.place(x=0,y=0)
    can1.create_text(375,100,text="CHASSE AU TRESOR",font=("Blader",43),fill="white")
    can1.create_text(375,300,text="Bienvenue",font=("Herculanum",28),fill="yellow")
    Button(can1,text="Nouvelle partie",font=("Herculanum",16),anchor=CENTER,command=niveau1).place(relx=0.5,y=435, anchor=CENTER)
    Button(can1,text="Quitter",font=("Herculanum",16),anchor=CENTER,command=Mafenetre.destroy).place(relx=0.5,y=475,anchor=CENTER)
    
def end():
    """écran de fin"""
    global compteur_fleur
    can1=Canvas(Mafenetre,bg="#AED4D7",width=750,height=700)
    can1.place(x=0,y=0)
    can1.create_text(375,100,text="CHASSE AU TRESOR",font=("Blader",43),fill="white")
    can1.create_text(375,200,text="Fin",font=("Herculanum",28),fill="yellow")
    can1.create_text(375,300,text="Merci d'avoir joué",font=("Herculanum",18),fill="red")
    Button(can1,text="Nouvelle partie",font=("Herculanum",16),anchor=CENTER,command=niveau1).place(relx=0.5,y=435, anchor=CENTER)
    Button(can1,text="Quitter",font=("Herculanum",16),anchor=CENTER,command=Mafenetre.destroy).place(relx=0.5,y=475,anchor=CENTER)
    print("vous avez rammassé ",compteur_fleur," fleur")

def Clavier(event):
    #event recupère l'information tapéee sur le clavier
    global posX,posY,compteur_touche,Coffre1
    cases_interdites=["BG","BD","PY","M1","M2","M3","M4","M5","M6","M42","M49","M56","M58","M59","M60","M53","M46","M7","M50","LHG","LHD","LBG","LBD"]
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    if touche=='Up' and ma_matrice[ligne-1][colonne] not in cases_interdites:
        mvt_haut()
    if touche=="Right" and ma_matrice[ligne][colonne+1] not in cases_interdites:
        mvt_droite()
    if touche=="Left" and ma_matrice[ligne][colonne-1] not in cases_interdites :
        mvt_gauche()
    if touche=='Down' and ma_matrice[ligne+1][colonne] not in cases_interdites :
        mvt_bas()
    touche2=event.char
    if touche2=="C" or touche2=="c" :
        position()
    touche3=event.char
    if touche3=="T" or touche3=="t":
        dialogue()
    touche4=event.char
    if touche4=="E" or touche4=="e" and posX==450 and posY==450:
        Coffre1=True
        coffre()
        can1.itemconfig(perso,image=avantbonus)
    touche5=event.char
    if touche5=="T" or touche5=="t" and Coffre1==True:
        fin()
    touche6=event.char
    if touche6=="E" or touche6=="e":
        fleur()

def fleur():
    global posX,posY,compteur_fleur
    if posX==200 and posY==650:
        compteur_fleur=compteur_fleur+1
    if posX==350 and posY==600:
        compteur_fleur=compteur_fleur+1
    if posX==500 and posY==500:
        compteur_fleur=compteur_fleur+1
    if posX==250 and posY==450:
        compteur_fleur=compteur_fleur+1
    if posX==50 and posY==400:
        compteur_fleur=compteur_fleur+1
    if posX==350 and posY==200:
        compteur_fleur=compteur_fleur+1
    if posX==500 and posY==100:
        compteur_fleur=compteur_fleur+1
        
        

def fin(): 
    """rendre le coffre au papy"""
    global posX,posY,Coffre1,compteur_fleur
    if posX==300 and posY==350 and Coffre1==True:
        b=can1.create_text(150,475,text="Merci de m'avoir rendu le coffre !")
    can1.after(1000,end)


def dialogue():
    """dialogue avec le pnj"""
    global posX,posY,compteur_touche,a,grand_pere
    if posX==300 and posY==350 and compteur_touche==5 :
        a=can1.itemconfig(a,text="Il faut absolument que tu le retrouves et que tu me l'apportes")
        compteur_touche+=1
        grand_pere=True
    if posX==300 and posY==350 and compteur_touche==4 :
        a=can1.itemconfig(a,text="Je ne peux pas t'en dire plus pour le moment")
        compteur_touche+=1
    if posX==300 and posY==350 and compteur_touche==3 :
        can1.itemconfig(a,text="J'ai caché un coffre il y a des années dans le jardin")
        compteur_touche+=1
    if posX==300 and posY==350 and compteur_touche==2 :
        can1.itemconfig(a,text="Il faut que tu m'écoutes attentivement")
        compteur_touche+=1
    if posX==300 and posY==350 and compteur_touche==1 :
        a=can1.create_text(150,475,text="Ah ! Je t'attendais")
        compteur_touche+=1
   
       
def coffre():
    """interaction avec le coffre et changement de l'image"""
    global posX,posY,perso,texte_info
    if posX==450 and posY==450:
        L7=["BD","E","P","E","E","E","HT","E","BG"]
    can1.itemconfig(perso,image=herbetrou)
    perso=can1.create_image(posX,posY,image=monte2,anchor="nw")
    texte_info2=can1.create_text(450,555,text="donne le coffre au grand-père",font=("Arial",16),fill="blue")
    
    


def mvt_gauche():
    """deplace le perso à gauche"""    
    global perso,posX,posY,compteur_de_pas,texte_pnj,grand_pere
    posX=posX-50
    if posX<0 :
        posX=00
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY) 
    if posX==50 and posY==350 : 
        if grand_pere==True :
            can1.after(1000,niveau3)
            posX=100
            posY=200
        else : 
            can1.after(1000,niveau1)
            posX=100 
            posY=200
        
def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,grand_pere
    posY=posY-50
    if posY<0 :
        posY=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==100 and posY==200 :
        can1.after(1000,maison)
    
def mvt_droite():
    """deplace le perso à droite"""    
    global perso,posX,posY,compteur_de_pas,grand_pere
    posX=posX+50
    if posX>650 :
        posX=650
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==50 and posY==350 : 
        if grand_pere==True :
            can1.after(1000,niveau3)
            posX=100
            posY=200
    
        else : 
            can1.after(1000,niveau1)
            posX=100 
            posY=200
   
def mvt_bas():
    """deplace le perso vers le bas"""
    global perso,posX,posY,compteur_de_pas,grand_pere
    posY=posY+50
    if posY>650:
        posY=650
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==50 and posY==350 : 
        if grand_pere==True :
            can1.after(1000,niveau3)
            posX=100 
            posY=200
            
        else : 
            can1.after(1000,niveau1)
            posX=100 
            posY=200
        


#NIVEAU 2 
def maison():
    global can1,text_pnj,perso,ma_matrice,posX,posY,dico
    can1.destroy()
    ma_matrice=[]
    can1=Canvas(Mafenetre,bg="white",width=1000,height=1000)
    can1.place(x=0,y=0)
    #creation de la matrice
    L0=["M2","M2","M2","M2","M2","M2","M2","M2","M2"]
    L1=["M1","M1","M1","M1","M1","M1","M1","M1","M1"]
    L2=["S","S","S","S","S","S","S","S","M0"]
    L3=["S","S","S","S","S","S","S","S","M0"]
    L4=["S","S","S","S","S","S","S","S","M0"]
    L5=["S","S","S","S","S","S","S","S","M0"]
    L6=["S","S","S","S","S","S","S","S","M0"]
    L7=["S","P","S","S","S","S","S","PY","M0"]
    L8=["M1","M1","M1","M1","M1","M1","M1","M1","M1"]
    ma_matrice=[L0,L1,L2,L3,L4,L5,L6,L7,L8]
    dico={"M0":mur0,"M1":mur1,"M2":mur2,"S":sol,"P":sortie,"PY":papy}
    for i in range(9):
        for j in range(9):
            can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
    #position du personnage
    posX=50 #abscisse de départ
    posY=350 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=monte2,anchor="nw")
    can1.focus_set()
    can1.bind('<Key>',Clavier)
    #zones de textes
    texte_pnj=can1.create_text(200,500,text="appuyer sur T pour parler au grand-père",font=("Arial",14),fill="red")
 
    
#NIVEAU 3
def niveau3():
    global can1,text_pnj,perso,ma_matrice,posX,posY,texte_info,dico
    can1.destroy()
    ma_matrice=[]
    can1=Canvas(Mafenetre,bg="white",width=1000,height=1000)
    can1.place(x=0,y=0)
    #creation de la matrice
    L0=["HG","M1","M2","M3","M4","M5","HG","HD","HG","HD","HG","HD","HG"]
    L1=["BD","M6","M30","M31","M32","M7","E","E","E","E","E","E","BG"]
    L2=["BD","M42","M43","M44","M45","M46","E","E","E","E","F","E","BG"]
    L3=["BD","M49","M50","M51","M52","M53","E","E","E","VC2","P2","P2","BG"]
    L4=["BD","M56","V","M58","M59","M60","E","F","E","P","E","E","BG"]
    L5=["BD","E","P","E","E","E","VC2","P2","P2","VC4","E","E","BG"]
    L6=["BD","E","P","E","E","E","P","E","E","E","E","E","BG"]
    L7=["BD","E","P","P2","P2","P2","VC4","E","LHG","LHD","E","E","BG"]
    L8=["BD","F","P","E","E","E","E","E","LBG","LBD","E","E","BG"]
    L9=["BD","E","P","E","E","F","E","E","E","CT","E","E","BG"]
    L10=["BD","E","P","E","E","E","E","E","E","E","F","E","BG"]
    L11=["BD","E","P","E","E","E","E","E","E","E","E","E","BG"]
    L12=["BD","E","P","E","E","E","E","F","E","E","E","E","BG"]
    L13=["BD","E","P","E","F","E","E","E","E","E","E","E","BG"]
    L14=["BD","E","P","E","E","E","E","E","E","E","E","E","BG"]
    ma_matrice=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14]
    #creation de la map                                                            
    dico={"E":herbe,"P":chemin,"V":casevillage,"A":coffreterre,"BD":borduredroite,"BG":borduregauche,"P2":chemin2,
          "VC":viragechemin,"VC2":viragechemin2,"VC3":viragechemin3,"VC4":viragechemin4,"BRD":barrieredroite, 
          "BRG":barrieregauche,"HD":hautdroit,"HG":hautgauche,"M1":map1,"M2":map2,"M3":map3,"M4":map4,"M5":map5,
          "M6":map6,"M7":map7,"M30":map30,"M31":map31,"M32":map32,"M42":map42,"M43":map43,"M44":map44,"M45":map45,
          "M46":map46,"M49":map49,"M50":map50,"M51":map51,"M52":map52,"M53":map53,"M56":map56,"M58":map58,"M59":map59,
          "M60":map60,"CT":coffreterre,"HT":herbetrou,"LBD":lacbasdroit,"LBG":lacbasgauche,"LD":lacdroit,"LG":lacgauche,
          "LHD":lachautdroit,"LHG":lachautgauche,"F":fleur1}
    for i in range(15):
        for j in range(13):
            can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
    #position du personnage
    posX=50 #abscisse de départ
    posY=350 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=monte2,anchor="nw")
    can1.focus_set()
    can1.bind('<Key>',Clavier)
    #zones de textes
    texte_info=can1.create_text(450,525,text="appuyer sur E pour deterrer le coffre",font=("Arial",16),fill="red")

#programme principal
start()
compteur_touche=1
compteur_fleur=0
grand_pere=False
Coffre1=False
can1.focus_set()    
can1.bind('<Key>',Clavier)
Mafenetre.mainloop()













