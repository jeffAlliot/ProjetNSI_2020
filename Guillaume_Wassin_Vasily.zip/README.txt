﻿Le présent programme : "principale.py" ne peux fonctionner correctement qu'avec l'installation du module pygame



Différents eater eggs (à ne lire que si on n'arrive pas à les trouver, c'est mieux):

-Un menu spécial apparaît si l'on reste 1min30s sur le menu principal

-L'inscription sur le dessus de la stèle est écrite en alphabet basic star wars, nous vous laissons le plaisir de le déchiffrer

-Si l'on meurt plus de 3 fois dans la même partie, un son spécial se lance

-Si l'on tape les lettres "wtf" sur son clavier, plusieurs éléments sont remplacés:
	-Lorsque les ennemis apparaissent, un son est joué.
	-Lorsque l'on touche les ennemis avec l'arc, c'est un autre son qui est joué
	-Lorsque l'on touche le boss final, son cri est aussi modifié.
