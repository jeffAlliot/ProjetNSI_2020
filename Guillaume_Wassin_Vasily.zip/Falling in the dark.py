#INITIALISATION-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------INITIALISATION

# BIEN LIRE LE FICHIER README.txt JOINT


#creation d'une bitmap
#modules
import time
from tkinter import *
import pygame

#creation de la fenetre
Mafenetre=Tk()
hauteur_fenetre=600
largeur_fenetre=1100
largeur_ecran = Mafenetre.winfo_screenwidth() # Largeur de l'écran
hauteur_ecran = Mafenetre.winfo_screenheight() # Hauteur de l'ecran
posX_fenetre = (largeur_ecran/2) - (largeur_fenetre/2)
posY_fenetre = (hauteur_ecran/2) - (hauteur_fenetre/2)
Mafenetre.geometry('%dx%d+%d+%d' % ( largeur_fenetre,hauteur_fenetre,posX_fenetre,posY_fenetre))
Mafenetre.title('Falling in the Dark')
Mafenetre.resizable(width=False, height=False)
temps_debut=time.time()
pygame.init()
Mafenetre.iconbitmap("icone.ico")

#zone de dessin
can0=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)
can1=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)
can2=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)
can3=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)
can4=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)
can5=Canvas(Mafenetre,bg="black",width=largeur_fenetre,height=hauteur_fenetre)

#images plus grande que les cases
HUD=PhotoImage(file="HUD.gif")
HUD_mort=PhotoImage(file="HUD_mort.gif")
transition1=PhotoImage(file="transition1.png")
transition2=PhotoImage(file="transition2.png")
transition3=PhotoImage(file="transition3.gif")
transition1_V=PhotoImage(file="transition1_V.png")
transition2_V=PhotoImage(file="transition2_V.png")
transition3_V=PhotoImage(file="transition3_V.gif")
tete_jade_mouvement=PhotoImage(file="tete_jade_cinematic2_salle1.png")
tuto_rotation=PhotoImage(file="tuto_rotation.gif")
ecran_titre_1=PhotoImage(file="ecran_titre_1.png")
ecran_titre_2=PhotoImage(file="ecran_titre_2.png")
ecran_titre_1_troll=PhotoImage(file="ecran_titre_1_troll.gif")
ecran_titre_2_troll=PhotoImage(file="ecran_titre_2_troll.gif")
ecran_titre_menu=PhotoImage(file="ecran_titre_menu.gif")
ecran_titre_niveau_dif=PhotoImage(file="ecran_titre_niveau_dif.gif")
mort_flamme=PhotoImage(file="mort_flamme.gif")
mort_chute=PhotoImage(file="mort_chute.gif")
mort_ennemi=PhotoImage(file="mort_ennemi.gif")
victoire=PhotoImage(file="victoire.gif")



#textes des cinématiques
text_4_autel_premiere_interaction=PhotoImage(file="text_4_autel_premiere_interaction.gif")
text_3_autel_premiere_interaction=PhotoImage(file="text_3_autel_premiere_interaction.gif")
text_2_autel_premiere_interaction=PhotoImage(file="text_2_autel_premiere_interaction.gif")
text_1_autel_premiere_interaction=PhotoImage(file="text_1_autel_premiere_interaction.gif")

text_2_autel_seconde_interaction=PhotoImage(file="text_2_autel_seconde_interaction.gif")
text_1_autel_seconde_interaction=PhotoImage(file="text_1_autel_seconde_interaction.gif")

text_2_arme_epee_devant_piedestale_epee=PhotoImage(file="text_2_arme_epee_devant_piedestale_epee.gif")
text_1_arme_epee_devant_piedestale_epee=PhotoImage(file="text_1_arme_epee_devant_piedestale_epee.gif")

text_2_arme_epee_devant_piedestale_arc=PhotoImage(file="text_2_arme_epee_devant_piedestale_arc.gif")
text_1_arme_epee_devant_piedestale_arc=PhotoImage(file="text_1_arme_epee_devant_piedestale_arc.gif")

text_1_arme_arc_devant_piedestale_epee=PhotoImage(file="text_1_arme_arc_devant_piedestale_epee.gif")

text_2_arme_arc_devant_piedestale_arc=PhotoImage(file="text_2_arme_arc_devant_piedestale_arc.gif")
text_1_arme_arc_devant_piedestale_arc=PhotoImage(file="text_1_arme_arc_devant_piedestale_arc.gif")

text_1_arc_premiere_interaction=PhotoImage(file="text_1_arc_premiere_interaction.gif")
text_1_epee_premiere_interaction=PhotoImage(file="text_1_epee_premiere_interaction.gif")
text_2_arme_premiere_interaction=PhotoImage(file="text_2_arme_premiere_interaction.gif")

reponse_positive_epee=PhotoImage(file="reponse_positive_epee.gif")
reponse_positive_arc=PhotoImage(file="reponse_positive_arc.gif")

texte_1_mage=PhotoImage(file="texte_1_mage.gif")
texte_2_mage=PhotoImage(file="texte_2_mage.gif")
texte_3_mage=PhotoImage(file="texte_3_mage.gif")
texte_4_mage=PhotoImage(file="texte_4_mage.gif")

texte_1_boss=PhotoImage(file="texte_1_boss.gif")
texte_2_boss=PhotoImage(file="texte_2_boss.gif")
texte_3_boss=PhotoImage(file="texte_3_boss.gif")
texte_4_boss=PhotoImage(file="texte_4_boss.gif")
texte_5_boss=PhotoImage(file="texte_5_boss.gif")
texte_6_boss=PhotoImage(file="texte_6_boss.gif")

non=PhotoImage(file="non.gif")

# cinematique du boss
cinematique_vague3_1=PhotoImage(file="cinematique_vague3_1.png")
cinematique_vague3_2=PhotoImage(file="cinematique_vague3_2.png")
cinematique_vague3_3=PhotoImage(file="cinematique_vague3_3.png")
cinematique_vague3_4=PhotoImage(file="cinematique_vague3_4.png")
cinematique_vague3_5=PhotoImage(file="cinematique_vague3_5.png")
cinematique_vague3_6=PhotoImage(file="cinematique_vague3_6.png")
cinematique_vague3_7=PhotoImage(file="cinematique_vague3_7.gif")
cinematique_vague3_8=PhotoImage(file="cinematique_vague3_8.gif")
cinematique_vague3_9=PhotoImage(file="cinematique_vague3_9.gif")
cinematique_vague3_10=PhotoImage(file="cinematique_vague3_10.gif")

#creation des cases images

#0%
coinG=PhotoImage(file="coin_gauche.gif")
coinD=PhotoImage(file="coin_droit.gif")
murG=PhotoImage(file="mur_gauche.gif")
murD=PhotoImage(file="mur_droit.gif")
murfondDI=PhotoImage(file="mur_fond_droit_interne.gif")
murfondGI=PhotoImage(file="mur_fond_gauche_interne.gif")
sol=PhotoImage(file="sol.gif")
murfondDE=PhotoImage(file="mur_fond_droit_externe.gif")
murfondGE=PhotoImage(file="mur_fond_gauche_externe.gif")
murfondM=PhotoImage(file="mur_fond_milieu.gif")
gravat=PhotoImage(file="gravat.gif")
piedestal_epee=PhotoImage(file="piedestal_epee.gif")
piedestal_arc=PhotoImage(file="piedestal_arc.gif")
piedestal_epee_vide=PhotoImage(file="piedestal_epee_vide.gif")
piedestal_arc_vide=PhotoImage(file="piedestal_arc_vide.gif")


#25%
coinG_25=PhotoImage(file="coin_gauche_25.gif")
coinD_25=PhotoImage(file="coin_droit_25.gif")
murG_25=PhotoImage(file="mur_gauche_25.gif")
murD_25=PhotoImage(file="mur_droit_25.gif")
murfondDI_25=PhotoImage(file="mur_fond_droit_interne_25.gif")
murfondGI_25=PhotoImage(file="mur_fond_gauche_interne_25.gif")
sol_25=PhotoImage(file="sol_25.gif")
murfondDE_25=PhotoImage(file="mur_fond_droit_externe_25.gif")
murfondGE_25=PhotoImage(file="mur_fond_gauche_externe_25.gif")
murfondM_25=PhotoImage(file="mur_fond_milieu_25.gif")
gravat_25=PhotoImage(file="gravat_25.gif")
piedestal_epee_25=PhotoImage(file="piedestal_epee_25.gif")
piedestal_arc_25=PhotoImage(file="piedestal_arc_25.gif")
porte_droite_fermee_25=PhotoImage(file="mur_droit_porte_fermee_25.gif")
porte_droite_ouverte_25=PhotoImage(file="mur_droit_porte_ouverte_25.gif")

#50%
coinG_50=PhotoImage(file="coin_gauche_50.gif")
coinD_50=PhotoImage(file="coin_droit_50.gif")
murG_50=PhotoImage(file="mur_gauche_50.gif")
murD_50=PhotoImage(file="mur_droit_50.gif")
murfondDI_50=PhotoImage(file="mur_fond_droit_interne_50.gif")
murfondGI_50=PhotoImage(file="mur_fond_gauche_interne_50.gif")
sol_50=PhotoImage(file="sol_50.gif")
murfondDE_50=PhotoImage(file="mur_fond_droit_externe_50.gif")
murfondGE_50=PhotoImage(file="mur_fond_gauche_externe_50.gif")
murfondM_50=PhotoImage(file="mur_fond_milieu_50.gif")
gravat_50=PhotoImage(file="gravat_50.gif")
piedestal_epee_50=PhotoImage(file="piedestal_epee_50.gif")
piedestal_arc_50=PhotoImage(file="piedestal_arc_50.gif")
porte_droite_fermee_50=PhotoImage(file="mur_droit_porte_fermee_50.gif")
porte_droite_ouverte_50=PhotoImage(file="mur_droit_porte_ouverte_50.gif")

#75%
coinG_75=PhotoImage(file="coin_gauche_75.gif")
coinD_75=PhotoImage(file="coin_droit_75.gif")
murG_75=PhotoImage(file="mur_gauche_75.gif")
murD_75=PhotoImage(file="mur_droit_75.gif")
murfondDI_75=PhotoImage(file="mur_fond_droit_interne_75.gif")
murfondGI_75=PhotoImage(file="mur_fond_gauche_interne_75.gif")
sol_75=PhotoImage(file="sol_75.gif")
murfondDE_75=PhotoImage(file="mur_fond_droit_externe_75.gif")
murfondGE_75=PhotoImage(file="mur_fond_gauche_externe_75.gif")
murfondM_75=PhotoImage(file="mur_fond_milieu_75.gif")
gravat_75=PhotoImage(file="gravat_75.gif")
piedestal_epee_75=PhotoImage(file="piedestal_epee_75.gif")
piedestal_arc_75=PhotoImage(file="piedestal_arc_75.gif")
porte_droite_fermee_75=PhotoImage(file="mur_droit_porte_fermee_75.gif")
porte_droite_ouverte_75=PhotoImage(file="mur_droit_porte_ouverte_75.gif")

#coeur du HUD
cote_coeur_gauche=PhotoImage(file="demi_coeur_gauche.gif")
cote_coeur_droit=PhotoImage(file="demi_coeur_droit.gif")
coeur_plein=PhotoImage(file="coeur_plein.gif")
coeur_vide=PhotoImage(file="coeur_vide.gif")

#ennemis
orc_massue_dos_static=PhotoImage(file="orc_massue_dos_static.gif")
orc_massue_dos_mouvement=PhotoImage(file="orc_massue_dos_mouvement.gif")
orc_massue_face_static=PhotoImage(file="orc_massue_face_static.gif")
orc_massue_face_mouvement=PhotoImage(file="orc_massue_face_mouvement.gif")
orc_massue_droite_static=PhotoImage(file="orc_massue_droite_static.gif")
orc_massue_droite_mouvement=PhotoImage(file="orc_massue_droite_mouvement.gif")
orc_massue_gauche_static=PhotoImage(file="orc_massue_gauche_static.gif")
orc_massue_gauche_mouvement=PhotoImage(file="orc_massue_gauche_mouvement.gif")

orc_massue_gauche_frappe=PhotoImage(file="orc_massue_gauche_frappe.gif")
orc_massue_droite_frappe=PhotoImage(file="orc_massue_droite_frappe.gif")
orc_massue_dos_frappe=PhotoImage(file="orc_massue_dos_frappe.png")
orc_massue_face_frappe=PhotoImage(file="orc_massue_face_frappe.gif")

orc_arc_dos_static=PhotoImage(file="orc_arc_dos_static.gif")
orc_arc_dos_mouvement1=PhotoImage(file="orc_arc_dos_mouvement1.gif")
orc_arc_face_static=PhotoImage(file="orc_arc_face_static.gif")
orc_arc_face_mouvement1=PhotoImage(file="orc_arc_face_mouvement1.gif")
orc_arc_droite_static=PhotoImage(file="orc_arc_droite_static.gif")
orc_arc_droite_mouvement=PhotoImage(file="orc_arc_droite_mouvement.gif")
orc_arc_gauche_static=PhotoImage(file="orc_arc_gauche_static.gif")
orc_arc_gauche_mouvement=PhotoImage(file="orc_arc_gauche_mouvement.gif")

orc_arc_gauche_tir1=PhotoImage(file="orc_arc_gauche_tir1.gif")
orc_arc_gauche_tir2=PhotoImage(file="orc_arc_gauche_tir2.gif")
orc_arc_gauche_tir3=PhotoImage(file="orc_arc_gauche_tir3.gif")
orc_arc_droite_tir1=PhotoImage(file="orc_arc_droite_tir1.gif")
orc_arc_droite_tir2=PhotoImage(file="orc_arc_droite_tir2.gif")
orc_arc_droite_tir3=PhotoImage(file="orc_arc_droite_tir3.gif")
orc_arc_face_tir1=PhotoImage(file="orc_arc_face_tir1.gif")
orc_arc_face_tir2=PhotoImage(file="orc_arc_face_tir2.gif")
orc_arc_face_tir3=PhotoImage(file="orc_arc_face_tir3.gif")
orc_arc_dos_tir1=PhotoImage(file="orc_arc_dos_tir1.gif")
orc_arc_dos_tir2=PhotoImage(file="orc_arc_dos_tir2.gif")
orc_arc_dos_tir3=PhotoImage(file="orc_arc_dos_tir3.gif")

orc_boss=PhotoImage(file="orc_boss.gif")
orc_boss_pointe=PhotoImage(file="orc_boss_pointe.gif")
orc_boss_bouclier=PhotoImage(file="orc_boss_bouclier.gif")
orc_boss_bouclier2=PhotoImage(file="orc_boss_bouclier2.gif")
orc_boss_cible=PhotoImage(file="orc_boss_cible.gif")
orc_boss_cible2=PhotoImage(file="orc_boss_cible2.gif")

boss_fleche=PhotoImage(file="boss_fleche.gif")

cible=PhotoImage(file="cible.png")
cible2=PhotoImage(file="cible2.png")

# autres cases
Autel=PhotoImage(file="autel.gif")
coeur_plein=PhotoImage(file="coeur_plein.gif")
coeur_vide=PhotoImage(file="coeur_vide.gif")
coinD=PhotoImage(file="coin_droit.gif")
coinG=PhotoImage(file="coin_gauche.gif")
cote_coeur_droit=PhotoImage(file="demi_coeur_droit.gif")
cote_coeur_gauche=PhotoImage(file="demi_coeur_gauche.gif")
D=PhotoImage(file="Dark.gif")
fissure_1=PhotoImage(file="mur_gauche_fissure1.gif")
fissure_2=PhotoImage(file="mur_gauche_fissure2.gif")
fissure_3=PhotoImage(file="mur_gauche_fissure3.gif")
inscription1=PhotoImage(file="inscription1_salle1.gif")
inscription2=PhotoImage(file="inscription2_salle1.gif")
inscription3=PhotoImage(file="inscription3_salle1.gif")
inscription4=PhotoImage(file="inscription4_salle1.gif")
inscription5=PhotoImage(file="inscription5_salle1.gif")
inscription6=PhotoImage(file="inscription6_salle1.gif")
murD=PhotoImage(file="mur_droit.gif")
murfondDE=PhotoImage(file="mur_fond_droit_externe.gif")
murfondDI_inscription=PhotoImage(file="mur_fond_droit_interne_inscription.gif")
murfondDI=PhotoImage(file="mur_fond_droit_interne.gif")
murfondGE=PhotoImage(file="mur_fond_gauche_externe.gif")
murfondGI=PhotoImage(file="mur_fond_gauche_interne.gif")
murfondM=PhotoImage(file="mur_fond_milieu.gif")
murG=PhotoImage(file="mur_gauche.gif")
mur_fond_lave=PhotoImage(file="mur_fond_lave.gif")
piedestal_cinematic=PhotoImage(file="piedestal_cinematic_salle1.gif")
piedestal=PhotoImage(file="piedestal_salle1.gif")
sol=PhotoImage(file="sol.gif")
tete_jade_flash=PhotoImage(file="tete_jade_cinematic3_salle1.png")
tete_jade=PhotoImage(file="tete_jade_cinematic_salle1.png")
tete_jade_explosion1=PhotoImage(file="tete_jade_explosion1.png")
tete_jade_explosion2=PhotoImage(file="tete_jade_explosion2.png")
trou_long_mur_fond=PhotoImage(file="trou_long_mur_fond.gif")
trou_long=PhotoImage(file="trou_long.gif")
trou=PhotoImage(file="trou.gif")
tuto1=PhotoImage(file="tuto_mouvement1_salle1.gif")
tuto2=PhotoImage(file="tuto_mouvement2_salle1.gif")
tuto_esquive=PhotoImage(file="tuto_esquive_salle1.gif")
tuto_interaction1=PhotoImage(file="tuto_interaction1_salle1.gif")
tuto_interaction2=PhotoImage(file="tuto_interaction2_salle1.gif")
tuto_arme_salle2=PhotoImage(file="tuto_arme_salle2.gif")
porte_droite_fermee=PhotoImage(file="mur_droit_porte_fermee.gif")
porte_droite_ouverte=PhotoImage(file="mur_droit_porte_ouverte.gif")
porte_gauche_fermee=PhotoImage(file="mur_gauche_porte_fermee.gif")
porte_gauche_ouverte=PhotoImage(file="mur_gauche_porte_ouverte.gif")
porte_mur_fond=PhotoImage(file="mur_fond_porte.gif")
lave=PhotoImage(file="lave.gif")
ile=PhotoImage(file="lave_sol.gif")
contour_lave=PhotoImage(file="contour_lave.png")
flamme=PhotoImage(file="flamme.gif")
PNJ=PhotoImage(file="PNJ.gif")
PNJ_2=PhotoImage(file="PNJ_2.gif")
PNJ_3=PhotoImage(file="PNJ_3.gif")
PNJ_4=PhotoImage(file="PNJ_4.gif")
invisible=PhotoImage(file="rien.gif")

#création des skin du héros
face_static=PhotoImage(file="face_static.gif")
face_mouvement1=PhotoImage(file="face_mouvement1.gif")
face_mouvement2=PhotoImage(file="face_mouvement2.gif")
dos_static=PhotoImage(file="dos_static.gif")
dos_mouvement1=PhotoImage(file="dos_mouvement1.gif")
dos_mouvement2=PhotoImage(file="dos_mouvement2.gif")
droite_static=PhotoImage(file="droite_static.gif")
droite_mouvement1=PhotoImage(file="droite_mouvement1.gif")
gauche_static=PhotoImage(file="gauche_static.gif")
gauche_mouvement1=PhotoImage(file="gauche_mouvement1.gif")
droite_saisit=PhotoImage(file="droite_saisit_cinematic_salle1.gif")
chute1=PhotoImage(file="chute1.gif")
chute2=PhotoImage(file="chute2.gif")

face_static_epee=PhotoImage(file="face_static_epee.gif")
face_mouvement1_epee=PhotoImage(file="face_mouvement1_epee.gif")
face_mouvement2_epee=PhotoImage(file="face_mouvement2_epee.gif")
dos_static_epee=PhotoImage(file="dos_static_epee.gif")
dos_mouvement1_epee=PhotoImage(file="dos_mouvement1_epee.gif")
dos_mouvement2_epee=PhotoImage(file="dos_mouvement2_epee.gif")
droite_static_epee=PhotoImage(file="droite_static_epee.gif")
droite_mouvement1_epee=PhotoImage(file="droite_mouvement1_epee.gif")
gauche_static_epee=PhotoImage(file="gauche_static_epee.gif")
gauche_mouvement1_epee=PhotoImage(file="gauche_mouvement1_epee.gif")

face_static_arc=PhotoImage(file="face_static_arc.gif")
face_mouvement1_arc=PhotoImage(file="face_mouvement1_arc.gif")
face_mouvement2_arc=PhotoImage(file="face_mouvement2_arc.gif")
dos_static_arc=PhotoImage(file="dos_static_arc.gif")
dos_mouvement1_arc=PhotoImage(file="dos_mouvement1_arc.gif")
dos_mouvement2_arc=PhotoImage(file="dos_mouvement2_arc.gif")
droite_static_arc=PhotoImage(file="droite_static_arc.gif")
droite_mouvement1_arc=PhotoImage(file="droite_mouvement1_arc.gif")
gauche_static_arc=PhotoImage(file="gauche_static_arc.gif")
gauche_mouvement1_arc=PhotoImage(file="gauche_mouvement1_arc.gif")

face_static_T=PhotoImage(file="face_static_T.gif")
face_mouvement1_T=PhotoImage(file="face_mouvement1_T.gif")
face_mouvement2_T=PhotoImage(file="face_mouvement2_T.gif")
dos_static_T=PhotoImage(file="dos_static_T.gif")
dos_mouvement1_T=PhotoImage(file="dos_mouvement1_T.gif")
dos_mouvement2_T=PhotoImage(file="dos_mouvement2_T.gif")
droite_static_T=PhotoImage(file="droite_static_T.gif")
droite_mouvement1_T=PhotoImage(file="droite_mouvement1_T.gif")
gauche_static_T=PhotoImage(file="gauche_static_T.gif")
gauche_mouvement1_T=PhotoImage(file="gauche_mouvement1_T.gif")
chute1T=PhotoImage(file="chute1_T.gif")
chute2T=PhotoImage(file="chute2_T.gif")

tir_gauche=PhotoImage(file="gauche_tir.gif")
tir_droite=PhotoImage(file="droite_tir.gif")
tir_face=PhotoImage(file="face_tir.gif")
tir_dos=PhotoImage(file="dos_tir.gif")

fleche_droite=PhotoImage(file="fleche_droite.gif")
fleche_gauche=PhotoImage(file="fleche_gauche.gif")
fleche_haut=PhotoImage(file="fleche_haut.gif")
fleche_bas=PhotoImage(file="fleche_bas.gif")

frappe_droite=PhotoImage(file="droite_frappe.gif")
frappe_gauche=PhotoImage(file="gauche_frappe.gif")
frappe_face=PhotoImage(file="face_frappe.png")
frappe_dos=PhotoImage(file="dos_frappe.png")


esquive_gauche=PhotoImage(file="esquive_gauche.png")
esquive_droite=PhotoImage(file="esquive_droite.png")
esquive_haut=PhotoImage(file="esquive_haut.png")
esquive_bas=PhotoImage(file="esquive_bas.png")

#initialisation des variables GLOBALES UTILISABLE À TOUS OU PARTI DES NIVEAUX/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// initialisation des variables GLOBALES UTILISABLE À TOUS OU PARTI DES NIVEAUX (celle ci sont défini dans une fonction) et des variables LOCALES le niveau est alors spécifié

#musique
musique_menu=pygame.mixer.Sound("Menu.ogg")
musique_jeu=pygame.mixer.Sound("musique_jeu.ogg")
cri=pygame.mixer.Sound("cri.ogg")
game_over=pygame.mixer.Sound("game_over.ogg")
boss_theme=pygame.mixer.Sound("boss_theme.ogg")
fin=pygame.mixer.Sound("fin.ogg")

#effet sonores
confirmation=pygame.mixer.Sound("confirmation.ogg")
coup_trou=pygame.mixer.Sound("coup_trou.ogg")
ecroulement=pygame.mixer.Sound("ecroulement.ogg")
ecroulement_court=pygame.mixer.Sound("ecroulement_court.ogg")
chute=pygame.mixer.Sound("chute.ogg")
son_epee=pygame.mixer.Sound("son_epee.ogg")
hello=pygame.mixer.Sound("hello.ogg")
headshot=pygame.mixer.Sound("headshot.ogg")
damage=pygame.mixer.Sound("damage.ogg")
cri_boss=pygame.mixer.Sound("cri_boss.ogg")
cri_boss_aigu=pygame.mixer.Sound("cri_boss_aigu.ogg")

mort=0
chaine=""
troll=0
lave_special=["MFGIS","MFGES","MFMS"]

#liste de skin des ennemis
orc_massue=[orc_massue_face_static,orc_massue_face_mouvement,orc_massue_dos_static,orc_massue_dos_mouvement,orc_massue_droite_static,orc_massue_droite_mouvement,orc_massue_gauche_static,orc_massue_gauche_mouvement,orc_massue_gauche_frappe,orc_massue_droite_frappe,orc_massue_dos_frappe,orc_massue_face_frappe]
orc_arc=[orc_arc_face_static,orc_arc_face_mouvement1,orc_arc_dos_static,orc_arc_dos_mouvement1,orc_arc_droite_static,orc_arc_droite_mouvement,orc_arc_gauche_static,orc_arc_gauche_mouvement,orc_arc_gauche_tir1,orc_arc_gauche_tir2,orc_arc_gauche_tir3,orc_arc_droite_tir1,orc_arc_droite_tir2,orc_arc_droite_tir3,orc_arc_face_tir1,orc_arc_face_tir2,orc_arc_face_tir3,orc_arc_dos_tir1,orc_arc_dos_tir2,orc_arc_dos_tir3]

#dictionnaire de la totalité des objets avec lequels le joeur peut interagir
objets_interractifs={"trou":("niveau1",100,300),"statuette":("niveau1",900,300),"symbole":("niveau1",900,0),"Aut":("niveau2",500,100), "PA":("niveau2",700,100), "PE":("niveau2",300,100), "porte":("niveau2",1000,200), "suite":("niveau3",1000,200),"PNJ":("niveau4",500,300),"suivant":("niveau4",1000,100)} # syntaxe d'un élément interactif : "nom de l'objet":(numéro du niveau,position X de l'objet,position Y de l'objet)

#toutes les variables dont la valuer peut être modifié sont misnet a None et sont initialisé dans initialisation_depart
musique_lancée=vie=choix_dif=difficulte=porte=posX_fleche=apocalypse=posY_fleche=image_boss=fleche=initialisation=faible=text_cinematic_boss=texte_boss=cible_actuelle=texte_pnj=sombre=lumiere=autel=reponse=text_cinematic_piedestal_arme=question=cinematic_autel_arme=text_cinematic_autel_2=text_cinematic_autel_1=texte_ligne_2=texte_ligne_1=tuto3=une_fois=fin_tuto=lecture_symbole=text_cinematic_symbole=effondrement=utilise=switch=validation=dangereux=possible=sens=current_level=current_canvas=cinematic=nb_mort=surcharge=affichage_ennemi_restant=ennemis_restant=action=temps_Daction=moment=posX=posY=skin_apparition=reapparition=pouvoir_esquive=arme=ennemi1_stat=ennemi1=ennemi1_stat=ennemi2=ennemi2_stat=ennemi3=ennemi3_stat=ennemi4=ennemi4_stat=eteindre=text_cinematic_mage=porte_fin=text_cinematic_mage=None

#fonction réinitialisant toutes les variables dont les valeurs sont changé (utile pour redémarrer le jeu sans relancer le programme)
def initialisation_depart():
	"""initialise toutes les variables au valeur de début de jeu"""
	global musique_lancée, vie,apocalypse,initialisation,porte,sombre,faible,text_cinematic_boss,lumiere,autel,reponse,text_cinematic_piedestal_arme,question,cinematic_autel_arme,text_cinematic_autel_2,text_cinematic_autel_1,texte_ligne_2,texte_ligne_1,tuto3,une_fois,fin_tuto,lecture_symbole,text_cinematic_symbole,effondrement,utilise,switch,validation,dangereux,possible,sens,current_level,current_canvas,cinematic,nb_mort,surcharge,affichage_ennemi_restant,ennemis_restant,action,temps_Daction,moment,posX,posY,skin_apparition,reapparition,pouvoir_esquive,arme,ennemi1_stat,ennemi1,ennemi1_stat,ennemi2,ennemi2_stat,ennemi3,ennemi3_stat,ennemi4,ennemi4_stat,eteindre,text_cinematic_mage,porte_fin,text_cinematic_mage
	#variable du personnage
	initialisation=0
	vie=6
	action = False
	temps_Daction=time.time()
	moment=[face_static,face_mouvement1,face_mouvement2,dos_static,dos_mouvement1,dos_mouvement2,droite_static,droite_mouvement1,gauche_static,gauche_mouvement1]
	posX=22
	posY=300
	skin_apparition=droite_static
	reapparition=True
	pouvoir_esquive=False
	arme=False
	#variable des ennemis
	ennemi1_stat={}
	ennemi1=None
	ennemi2_stat={}
	ennemi1=None
	ennemi3_stat={}
	ennemi3=None
	ennemi4_stat={}
	ennemi4=None
	ennemis_restant=[]
	affichage_ennemi_restant=[]
	surcharge=0
	nb_mort=0
	#variable de l'environnement
	difficulte=False
	musique_lancée=False
	cinematic = False
	current_canvas=can0
	current_level="niveau0"
	sens="droite"
	possible=["MFDI","MFGI","S","MFDE","MFGE","P","TU","TO","S/T","MFM/T","T","MFM","L","I","TD","MFGIS","MFGES","MFMS"]
	dangereux=["T","L","TD","MFGIS","MFGES","MFMS"]
	#variable de l'écran titre
	validation=False
	switch=0
	#variable du NIVEAU 1
	utilise=0
	effondrement=0
	text_cinematic_symbole=5
	lecture_symbole=False
	fin_tuto=False
	une_fois=False
	tuto3=can1.create_image(100,100,image=tuto_esquive,anchor="nw")
	#variable du NIVEAU 2
	#zone de texte
	texte_ligne_1=can2.create_image(550, 550, image=invisible)
	texte_ligne_2=can2.create_image(550, 570, image=invisible)
	#variable de cinematiques
	text_cinematic_autel_1=4
	text_cinematic_autel_2=2
	cinematic_autel_arme=0
	question=False
	text_cinematic_piedestal_arme=1
	reponse=None
	autel=0
	lumiere=100
	sombre=True
	porte=False
	#variable du NIVEAU 4
	porte_fin=False
	text_cinematic_mage=0
	eteindre=100
	#variable du NIVEAU 5
	text_cinematic_boss=0
	faible=False
	apocalypse=None

# GÉNÉRATION DES NIVEAUX ET MATRICES CORRESPONDANTES ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// GÉNÉRATION DES NIVEAUX ET MATRICES CORRESPONDANTES

#matrice du NIVEAU 1
L0_lvl1=["CG","MFGI","MFGE","MFGE","MFGE","MFM/T","MFDE","MFDE","MFDE","MFDI","CD"]
L1_lvl1=["MG","S","S","S","S","S/T","S","S","S","S","MD"]
L2_lvl1=["MG","S","S","S","S","S/T","S","S","S","T","MD"]
L3_lvl1=["MG","S","S","S","S","S/T","S","S","S","P","MD"]
L4_lvl1=["MG","S","S","S","S","S/T","S","S","S","T","MD"]
L5_lvl1=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau1=[L0_lvl1,L1_lvl1,L2_lvl1,L3_lvl1,L4_lvl1,L5_lvl1]

#matrice du NIVEAU 2
L0_lvl2=["CG","MFGI","MFGE","MFGE","MFGE","MFM","MFDE","MFDE","MFDE","MFDI","CD"]
L1_lvl2=["MG","S","S","PE","S","Aut","S","PA","S","S","MD"]
L2_lvl2=["MG","S","S","S","S","S","S","S","S","S","PD"]
L3_lvl2=["MG","S","S","S","S","S","S","S","S","S","MD"]
L4_lvl2=["MG","S","S","S","G","S","G","S","S","S","MD"]
L5_lvl2=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau2=[L0_lvl2,L1_lvl2,L2_lvl2,L3_lvl2,L4_lvl2,L5_lvl2]

#matrice du NIVEAU 3
L0_lvl3=["CG","MFGIS","MFGES","MFGES","MFGES","MFMS","MFDE","MFDE","MFDE","MFDI","CD"]
L1_lvl3=["MG","L","L","L","L","L","I","L","L","I","MD"]
L2_lvl3=["PG","I","L","I","L","I","L","L","L","I","PD"]
L3_lvl3=["MG","I","L","I","L","L","I","L","L","I","MD"]
L4_lvl3=["MG","L","L","L","L","I","I","L","L","L","MD"]
L5_lvl3=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau3=[L0_lvl3,L1_lvl3,L2_lvl3,L3_lvl3,L4_lvl3,L5_lvl3]

#matrice du NIVEAU 4
L0_lvl4_L=["CG","MFGI","MFGE","MFGE","MFGE","MFM","MFDE","MFDE","MFDE","MFDI","CD"]
L1_lvl4_L=["MG","S","TD","TD","TD","TD","TD","S","TD","S","PDO"]
L2_lvl4_L=["MG","TD","TD","TD","TD","TD","TD","TD","TD","TD","MD"]
L3_lvl4_L=["MG","S","TD","S","S","PNJ","S","TD","S","TD","MD"]
L4_lvl4_L=["MG","TD","TD","TD","TD","S","TD","TD","TD","TD","MD"]
L5_lvl4_L=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau4_L=[L0_lvl4_L,L1_lvl4_L,L2_lvl4_L,L3_lvl4_L,L4_lvl4_L,L5_lvl4_L]

#matrice du NIVEAU 5
L0_lvl5=["CG","MFGI","MFGE","MFGE","MFGE","SPE","MFDE","MFDE","MFDE","MFDI","CD"]
L1_lvl5=["PG","S","S","S","S","S","S","S","S","S","PD"]
L2_lvl5=["MG","S","S","S","S","S","S","S","S","S","MD"]
L3_lvl5=["MG","S","S","S","S","S","S","S","S","S","MD"]
L4_lvl5=["PG","S","S","S","S","S","S","S","S","S","PD"]
L5_lvl5=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau5=[L0_lvl5,L1_lvl5,L2_lvl5,L3_lvl5,L4_lvl5,L5_lvl5]

L0_lvl5_A=["CG","MFGI","MFGE","MFGE","MFGE","SPE","MFGES","MFDE","MFDE","MFDI","CD"]
L1_lvl5_A=["PG","S","T","T","S","L","L","S","S","S","PD"]
L2_lvl5_A=["MG","T","T","T","S","T","S","S","S","S","MD"]
L3_lvl5_A=["MG","S","S","S","T","S","S","L","L","S","MD"]
L4_lvl5_A=["PG","S","S","S","S","S","S","L","L","S","PD"]
L5_lvl5_A=["CG","CG","CG","CG","CG","CG","CG","CG","CG","CG","CG"]
niveau5_A=[L0_lvl5_A,L1_lvl5_A,L2_lvl5_A,L3_lvl5_A,L4_lvl5_A,L5_lvl5_A]

#dictionnaire de la map
dico_niveau1={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGI":murfondGI,"S":sol,"MFDE":murfondDE,"MFGE":murfondGE, "MFM/T":murfondM,"P":piedestal,"T":trou,"TU":tuto1,"TO":tuto2,"S/T":sol}
dico2_niveau1={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGI":murfondGI,"S":sol,"MFDE":murfondDE,"MFGE":murfondGE, "MFM/T":trou_long_mur_fond,"P":piedestal_cinematic,"T":trou,"TU":sol,"TO":sol,"S/T":trou_long}
dico_niveau2={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGI":murfondGI,"S":sol,"MFDE":murfondDE,"MFGE":murfondGE, "MFM":murfondM, "G":gravat, "PE":piedestal_epee, "PA":piedestal_arc, "Aut":Autel,"PD":porte_droite_fermee}
dico_D_niveau24={"CG":D,"CD":D,"MG":D,"MD":D,"MFDI":D,"MFGI":D,"S":D,"MFDE":D,"MFGE":D, "MFM":D, "G":D, "PE":D, "PA":D,  "Aut":Autel,"PD":D,"PDO":D,"PNJ":D,"TD":D}
dico_75_niveau24={"CG":coinG_75,"CD":coinD_75,"MG":murG_75,"MD":murD_75,"MFDI":murfondDI_75,"MFGI":murfondGI_75,"S":sol_75,"MFDE":murfondDE_75,"MFGE":murfondGE_75, "MFM":murfondM_75, "G":gravat_75, "PE":piedestal_epee_75, "PA":piedestal_arc_75,  "Aut":Autel,"PD":porte_droite_fermee_75,"TD":D,"PDO":porte_droite_ouverte_75, "PNJ":PNJ_4}
dico_50_niveau24={"CG":coinG_50,"CD":coinD_50,"MG":murG_50,"MD":murD_50,"MFDI":murfondDI_50,"MFGI":murfondGI_50,"S":sol_50,"MFDE":murfondDE_50,"MFGE":murfondGE_50, "MFM":murfondM_50, "G":gravat_50, "PE":piedestal_epee_50, "PA":piedestal_arc_50,  "Aut":Autel,"PD":porte_droite_fermee_50,"TD":D,"PDO":porte_droite_ouverte_50, "PNJ":PNJ_3}
dico_25_niveau24={"CG":coinG_25,"CD":coinD_25,"MG":murG_25,"MD":murD_25,"MFDI":murfondDI_25,"MFGI":murfondGI_25,"S":sol_25,"MFDE":murfondDE_25,"MFGE":murfondGE_25, "MFM":murfondM_25, "G":gravat_25, "PE":piedestal_epee_25, "PA":piedestal_arc_25,  "Aut":Autel,"PD":porte_droite_fermee_25,"TD":D,"PDO":porte_droite_ouverte_25, "PNJ":PNJ_2}
dico_niveau3={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGIS":murfondGI,"S":sol,"MFDE":murfondDE,"MFGES":murfondGE, "MFMS":murfondM,"T":trou,"L":lave,"I":ile,"PD":porte_droite_ouverte,"PG":porte_gauche_fermee}
dico_niveau4={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGI":murfondGI,"MFDE":murfondDE,"MFGE":murfondGE, "MFM":murfondM, "S":sol, "TD":D, "PNJ":PNJ,"PDO":porte_droite_ouverte}
dico_niveau5={"CG":coinG,"CD":coinD,"MG":murG,"MD":murD,"MFDI":murfondDI,"MFGI":murfondGI,"MFDE":murfondDE,"MFGE":murfondGE, "SPE":murfondM, "S":sol,"PG":porte_gauche_ouverte,"PD":porte_droite_ouverte,"T":trou,"L":lave,"MFGES":murfondDE}

#FONCTION UTILISABLE À TOUS LES NIVEAUX////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// FONCTION UTILISABLE À TOUS LES NIVEAUX

#création de la map celle ci fait 11 par 5 cases + 1 ligne laissé pour le HUD
def creation_map():
	"""affiche le niveau à l'écran"""
	global lumiere,image_boss, sombre, cinematic, autel, cinematic_autel_arme,current_canvas,matrice,lave_special,perso,posX,posY,skin_apparition,reapparition,sens,current_level,eteindre,possible,apocalypse, musique_lancée
	if current_level=="niveau1":
		can1.place(x=0,y=0)
		Misc.lift(can1)
		current_canvas=can1
		matrice=niveau1
		can1.focus_set()
		for i in range(5):
			for j in range(11):
				if effondrement==1 and apocalypse==None:
					can1.create_image(100*j,100*i,image=dico2_niveau1[matrice[i][j]],anchor="nw")
				else:
					can1.create_image(100*j,100*i,image=dico_niveau1[matrice[i][j]],anchor="nw")
		if apocalypse ==1:
			can1.create_image(0,300,image=fissure_3,anchor="nw")

	elif current_level=="niveau2":
		can1.delete('ALL')
		can2.place(x=0,y=0)
		Misc.lift(can2)
		current_canvas=can2
		matrice=niveau2
		sens="haut"
		if reapparition==True:
			posX=500
			posY=400
		can2.focus_set()
		if cinematic=="autel":
			lumiere-=25
		for i in range(5):
			for j in range(11):
				if cinematic=="autel":
					if lumiere==75:
						can2.create_image(100*j,100*i,image=dico_75_niveau24[matrice[i][j]],anchor="nw")
					elif lumiere==50:
						can2.create_image(100*j,100*i,image=dico_50_niveau24[matrice[i][j]],anchor="nw")
					elif lumiere==25:
						can2.create_image(100*j,100*i,image=dico_25_niveau24[matrice[i][j]],anchor="nw")
					elif lumiere==0:
						can2.create_image(100*j,100*i,image=dico_niveau2[matrice[i][j]],anchor="nw")
						if i==4 and j==10:
							lumiere=True
							cinematic=False
							cinematic_autel_arme=1
							can1.tag_raise(perso)
							autel=1
							sombre=False
				else:
					can2.create_image(100*j,100*i,image=dico_D_niveau24[matrice[i][j]],anchor="nw")
					if i==4 and j==10:
						if musique_lancée==False:
							musique_jeu.play(25)
							musique_lancée=True
		if cinematic=="autel":
			can2.tag_raise(perso)
			can2.after(500, creation_map)
	
	elif current_level=="niveau3":
		can2.delete('ALL')
		can3.place(x=0,y=0)
		Misc.lift(can3)
		current_canvas=can3
		matrice=niveau3
		sens="droite"
		posX=100
		posY=200
		can3.focus_set()
		for i in range(5):
			for j in range(11):
				if matrice[i][j] in lave_special:
					can3.create_image(100*j,100*i,image=dico_niveau3[matrice[i][j]],anchor="nw")
					can3.create_image(100*j,100*i,image=mur_fond_lave,anchor="nw")
				else:
					can3.create_image(100*j,100*i,image=dico_niveau3[matrice[i][j]],anchor="nw")
		current_canvas.create_image(0,0,image=contour_lave,anchor="nw")
		apparition_ennemis(None)

	elif current_level=="niveau4":
		can3.delete('ALL')
		can4.place(x=0,y=0)
		Misc.lift(can4)
		current_canvas=can4
		matrice=niveau4_L
		can4.focus_set()
		if reapparition==True:
			sens="haut"
			posX=500
			posY=400
		if porte_fin==False:
			for i in range(5):
				for j in range(11):
					can4.create_image(100*j,100*i,image=dico_niveau4[niveau4_L[i][j]],anchor="nw")
					if i==4 and j==10:
						reapparition==False
		else:
			eteindre-=25
			for i in range(5):
				for j in range(11):
					if eteindre==75:
						can4.create_image(100*j,100*i,image=dico_25_niveau24[niveau4_L[i][j]], anchor="nw")
					elif eteindre==50:
						can4.create_image(100*j,100*i,image=dico_50_niveau24[niveau4_L[i][j]], anchor="nw")
					elif eteindre==25:
						can4.create_image(100*j,100*i,image=dico_75_niveau24[niveau4_L[i][j]], anchor="nw")
					elif eteindre==0:
						can4.create_image(100*j,100*i,image=dico_D_niveau24[niveau4_L[i][j]], anchor="nw")
						if i==4 and j==10:
							matrice=niveau4_L
							cinematic=False
			if eteindre>0:
					can4.after(500,creation_map)
			possible.append("PNJ")

	elif current_level=="niveau5":
		can4.delete('ALL')
		if apocalypse!=1:
			can5.place(x=0,y=0)
			Misc.lift(can5)
			current_canvas=can5
			matrice=niveau5
			sens="haut"
			posX=500
			posY=400
			can5.focus_set()
			for i in range(5):
				for j in range(11):
					can5.create_image(100*j,100*i,image=dico_niveau5[matrice[i][j]],anchor="nw")
			image_boss=can5.create_image(500,0,image=orc_boss,anchor="nw")
			cinematic="boss"
		else:
			can5.delete('ALL')
			matrice=niveau5_A
			for i in range(5):
				for j in range(11):
					can5.create_image(100*j,100*i,image=dico_niveau5[matrice[i][j]],anchor="nw")
			image_boss=can5.create_image(500,0,image=orc_boss_bouclier2,anchor="nw")
			can5.create_image(600,0,image=mur_fond_lave,anchor="nw")

	current_canvas.create_image(0,500,image=HUD,anchor="nw")
	compteur_vies()
	if current_level=="niveau5":
		cinematic_boss()
	if current_level=="niveau1" and apocalypse==1:
		cinematic_fin()	
	elif reapparition==True:
		perso=current_canvas.create_image(posX,posY,image=skin_apparition,anchor="nw")
	else:
		current_canvas.lift(perso)

def near_object():
	"""détecte si un joueur est proche d'un objet et si il est tourné vers lui"""
	global posX,posY,objets_interractifs,sens
	for elt in objets_interractifs:
		if objets_interractifs[elt][0]==current_level:
			if posX==objets_interractifs[elt][1] and posY==objets_interractifs[elt][2]:
				return (elt)
			if posX==objets_interractifs[elt][1]-100 and posY==objets_interractifs[elt][2] and sens=="droite":
				return (elt)
			if posX==objets_interractifs[elt][1]+100 and posY==objets_interractifs[elt][2] and sens=="gauche":
				return (elt)
			if posX==objets_interractifs[elt][1] and posY==objets_interractifs[elt][2]+100 and sens=="haut":
				return (elt)
			if posX==objets_interractifs[elt][1] and posY==objets_interractifs[elt][2]-100 and sens=="bas":
				return (elt)
	return False

def launch_cinematic(objet):
	""" lance la bonne cinématique en fonction de objet qui est en face du joueur"""
	global cinematic,effondrement,utilise,sens,current_level,apocalypse
	if current_level=="niveau1":
		if objet=="statuette" and utilise==0 and sens=="droite":
			cinematic_statuette()
		elif objet=="symbole" and effondrement==1 and sens=="haut" and lecture_symbole==False:
			cinematic_symbole()
		elif (objet=="trou" and effondrement==1 and sens=="gauche") or (objet=="trou" and apocalypse==1 and sens=="gauche"):
			cinematic_trou()
	elif current_level=="niveau2":
		if objet=="Aut":
			cinematic="autel"
			cinematic_autel()
		elif objet=="PE" or objet=="PA":
			if sombre==False:
				if objet=="PE":
					cinematic="épée"
				if objet=="PA":
					cinematic="arc"
				cinematic_piedestal_arme()
		elif objet=="porte":
			cinematic_porte()
	elif current_level=="niveau3":
		if objet=="suite":
			cinematic="porte"
			cinematic_porte()
	elif current_level=="niveau4":
		if objet=="PNJ":
			cinematic="mage"
			cinematic_mage()
		if objet=="suivant":
			cinematic="porte"
			cinematic_porte()

def cinematic_porte():
	"""permet de faire le fondu au noir et d'afficher le niveau suivant uniquement pour les niveaux utilisant des portes"""
	global porte,reapparition,current_level,skin_apparition,current_canvas,cinematic
	if porte==True:
		cessez_le_feu()
		current_canvas.unbind('<Key>')
		transition=current_canvas.create_image(0,0,image=transition1,anchor="nw")
		Mafenetre.update()
		current_canvas.after(500)
		current_canvas.itemconfig(transition,image=transition2)
		Mafenetre.update()
		current_canvas.after(500)
		current_canvas.itemconfig(transition,image=transition3)
		Mafenetre.update()
		current_canvas.after(500)
		if current_level == "niveau2":
			current_level="niveau3" #passage au niveau 3 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////passage au niveau 3
			skin_apparition=moment[6]
			reapparition=True
			can3.bind('<Key>',clavier)
		elif current_level == "niveau3":
			current_level="niveau4" #passage au niveau 4 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////passage au niveau 4
			skin_apparition=moment[3]
			reapparition=True
			can4.bind('<Key>',clavier)
		elif current_level == "niveau4":
			current_level="niveau5" #passage au niveau 5 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////passage au niveau 4
			skin_apparition=moment[3]
			reapparition=True
			can5.bind('<Key>',clavier)
		cinematic=False
		creation_map()
	
#FONCTIONS De L'ECRAN TITRE ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FONCTIONS De L'ECRAN TITRE

def ecran_titre():
	"""affiche et gère l'écran titre"""
	global validation,switch,musique_lancée, current_canvas
	can0.place(x=0,y=0)
	Misc.lift(can0)
	if musique_lancée==False and current_level=="niveau0" and validation==0:
		pygame.mixer.stop()
		musique_menu.play(25)
		musique_lancée=True
	can0.focus_set()
	current_canvas=can0
	if time.time()-temps_debut<90:
		if validation==False and switch ==0:
			switch=1
			can0.create_image(0,0,image=ecran_titre_1,anchor="nw")
			Mafenetre.update()
			can0.after(500)
		if validation==False and switch ==1:
			switch=0
			can0.create_image(0,0,image=ecran_titre_2,anchor="nw")
			Mafenetre.update()
			can0.after(500)
		if validation==1:
			ecran_2()
		else:
			can0.after(100,ecran_titre)
	else:
		if validation==False and switch ==0:
			switch=1
			can0.create_image(0,0,image=ecran_titre_1_troll,anchor="nw")
			Mafenetre.update()
			can0.after(500)
		if validation==False and switch ==1:
			switch=0
			can0.create_image(0,0,image=ecran_titre_2_troll,anchor="nw")
			Mafenetre.update()
			can0.after(500)
		if validation==1:
			ecran_2()
		else:
			can0.after(100,ecran_titre)

def ecran_2():
	"""affiche le menu"""
	can0.create_image(0,0,image=ecran_titre_menu,anchor="nw")
	
def ecran_3():
	"""affiche l'écran de choix du niveau de difficulté"""
	global choix_dif
	can0.create_image(0,0,image=ecran_titre_niveau_dif,anchor="nw")
	choix_dif=True
	

#FONCTIONS DU NIVEAU 1 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FONCTIONS DU NIVEAU 1

def debut_jeu():
	"""lance la cinématique de début de jeu"""
	global cinematic,perso,posX,posY,current_level,difficulte,musique_lancée
	musique_menu.stop()
	confirmation.play()
	musique_lancée=False
	can0.unbind('<Key>')
	current_level="niveau1"
	creation_map()
	can1.lower(perso)
	cinematic="debut"
	Mafenetre.update()
	can1.after(1500)
	coup_trou.play()
	can1.create_image(0,300,image=fissure_1,anchor="nw")
	Mafenetre.update()
	can1.after(1500)
	Mafenetre.update()
	coup_trou.play()
	can1.create_image(0,300,image=fissure_2,anchor="nw")
	Mafenetre.update()
	can1.after(1500)
	Mafenetre.update()
	can1.create_image(0,300,image=fissure_3,anchor="nw")
	coup_trou.play()
	Mafenetre.update()
	can1.after(1500)
	can1.lift(perso)
	posX+=26
	can1.itemconfig(perso,image=moment[6])
	can1.coords(perso,posX,posY)
	Mafenetre.update()
	can1.after(100)
	posX+=26
	can1.itemconfig(perso,image=moment[7])
	can1.coords(perso,posX,posY)
	Mafenetre.update()
	can1.after(100)
	posX+=26
	can1.itemconfig(perso,image=moment[6])
	can1.coords(perso,posX,posY)
	tutoriel(0)
	cinematic=False
	can1.bind('<Key>',clavier)

def tutoriel(temps):
	""" gère l'apparition et la disparition des textes du tutoriel """
	global posX,posY,cinematic,utilise,lecture_symbole,pouvoir_esquive,tuto3,fin_tuto,une_fois
	if vie>0:
		if temps==0:
			can1.create_image(100,200,image=tuto1,anchor="nw")
			can1.create_image(200,200,image=tuto2,anchor="nw")
			can1.create_image(100,400,image=tuto_rotation,anchor="nw")
		else:
			can1.create_image(100,200,image=sol,anchor="nw")
			can1.create_image(200,200,image=sol,anchor="nw")
			can1.create_image(100,400,image=sol,anchor="nw")
			can1.create_image(200,400,image=sol,anchor="nw")
			can1.create_image(700,200,image=sol,anchor="nw")
			can1.create_image(800,200,image=sol,anchor="nw")
			if posX==800 and posY==300 and utilise==0:
				can1.create_image(700,200,image=tuto_interaction1,anchor="nw")
				can1.create_image(800,200,image=tuto_interaction2,anchor="nw")
				Mafenetre.update()
			if posX>500 and posX<700 and lecture_symbole==True:
				pouvoir_esquive=True
				can1.lift(tuto3)
				can1.coords(tuto3,400,posY)
			elif lecture_symbole==True and posX<700:
				can1.lower(tuto3)
		if pouvoir_esquive==True and posX<=500:
			fin_tuto=True
		can1.lift(perso)

def cinematic_trou():
	"""lance la cinématique de transition entre le niveau 1 et 2"""
	global perso,posX,posY,current_level,skin_apparition,reapparition,cinematic,apocalypse,vie
	if posX==100 and posY==300:
		if apocalypse==None:
			cinematic="trou"
			can1.unbind('<Key>')
			ecroulement_court.play()
			can1.create_image(100,300,image=trou,anchor="nw")
			can1.lift(perso)
			Mafenetre.update()
			can1.after(600)
			chute.play()
			can1.itemconfig(perso,image=chute1T)
			Mafenetre.update()
			can1.after(1000)
			can1.itemconfig(perso,image=chute2T)
			Mafenetre.update()
			can1.after(1000)
			transition=can1.create_image(0,0,image=transition1,anchor="nw")
			Mafenetre.update()
			can1.after(500)
			can1.itemconfig(transition,image=transition2)
			Mafenetre.update()
			can1.after(500)
			chute.stop()
			can1.itemconfig(transition,image=transition3)
			Mafenetre.update()
			can1.after(500)
			current_level="niveau2" #passage au niveau 2 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////passage au niveau 2
			skin_apparition=dos_static_T
			reapparition=True
			creation_map()
			can2.bind('<Key>',clavier)
			cinematic=False
		if apocalypse==1:
			cinematic="victoire"
			transition=current_canvas.create_image(0,0,image=transition1,anchor="nw")
			Mafenetre.update()
			current_canvas.after(500)
			current_canvas.itemconfig(transition,image=transition2)
			Mafenetre.update()
			current_canvas.after(500)
			current_canvas.itemconfig(transition,image=transition3)
			Mafenetre.update()
			current_canvas.after(500)
			vie=0
			compteur_vies()

def cinematic_symbole():
	"""lance la cinématique des textes de la salle 1"""
	global text_cinematic_symbole,cinematic,lecture_symbole,perso,texte
	if posX==900 and posY==0:
		cinematic="symbole"
		if text_cinematic_symbole==0:
			texte=can1.create_image(300,500,image=inscription6,anchor="nw")
			text_cinematic_symbole-=1
			cinematic=False
			lecture_symbole=True
			can1.create_image(900,0,image=murfondDI,anchor="nw")
			can1.lift(perso)
		if text_cinematic_symbole!=-1:
			dico={5:inscription1,4:inscription2,3:inscription3,2:inscription4,1:inscription5}
			texte=can1.create_image(300,500,image=dico[text_cinematic_symbole],anchor="nw")
			text_cinematic_symbole-=1

def cinematic_statuette():
	"""lance la cinématique de la salle 1 qui provoque l'effondrement d'une partie du plancher"""
	global perso,moment, utilise,effondrement,possible,cinematic,skin_apparition,reapparition
	if posX==900 and posY==300:
		cinematic="statuette"
		utilise=1
		can1.after(200)
		can1.create_image(900,300,image=piedestal_cinematic,anchor="nw")
		can1.itemconfig(perso,image=droite_saisit,anchor="nw")
		can1.lift(perso)
		tete = can1.create_image(955,310,image=tete_jade,anchor="nw")
		Mafenetre.update()
		can1.after(700)
		can1.coords(tete,955,300)
		can1.coords(perso,posX-20,posY)
		can1.itemconfig(perso,image=droite_mouvement1)
		Mafenetre.update()
		can1.after(700)
		can1.coords(tete,955,300)
		Mafenetre.update()
		can1.coords(tete,925,300)
		can1.itemconfig(tete,image=tete_jade_mouvement)
		can1.after(700)
		can1.coords(tete,900,300)
		Mafenetre.update()
		can1.after(300)
		can1.itemconfig(tete,image=tete_jade)
		Mafenetre.update()
		can1.after(300)
		can1.itemconfig(tete,image=tete_jade_flash)
		can1.coords(tete,725,125)
		Mafenetre.update()
		can1.after(300)
		inscription=can1.create_image(900,0,image=murfondDI_inscription,anchor="nw")
		can1.lift(perso)
		can1.delete(tete)
		moment=[face_static_T,face_mouvement1_T,face_mouvement2_T,dos_static_T,dos_mouvement1_T,dos_mouvement2_T,droite_static_T,droite_mouvement1_T,gauche_static_T,gauche_mouvement1_T]
		can1.itemconfig(perso,image=droite_mouvement1_T)
		ecroulement.play()
		can1.create_image(500,200,image=trou_long,anchor="nw")
		Mafenetre.update()
		can1.after(200)
		can1.create_image(500,100,image=trou_long,anchor="nw")
		Mafenetre.update()
		can1.after(200)
		can1.create_image(500,300,image=trou_long,anchor="nw")
		Mafenetre.update()
		can1.after(200)
		can1.create_image(500,400,image=trou_long,anchor="nw")
		can1.after(200)
		can1.create_image(500,0,image=trou_long_mur_fond,anchor="nw")
		effondrement=1
		dangereux.append("S/T")
		dangereux.append("MFM/T")
		skin_apparition=droite_static_T
		reapparition=False
		creation_map()
		can1.create_image(0,300,image=fissure_3,anchor="nw")
		can1.lift(inscription)
		can1.lift(perso)
		cinematic=False

#FONCTIONS DU NIVEAU 2 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FONCTIONS DU NIVEAU 2

def cinematic_piedestal_arme():
	"""lance la cinématique pour prendre les armes au niveau 2"""
	global arme, question, text_cinematic_piedestal_arme, reponse, cinematic,moment
	can2.lift(texte_ligne_2)
	can2.lift(texte_ligne_1)
	if arme==False:
		if question==True or text_cinematic_piedestal_arme==2 and reponse!=None:
			if reponse=="positive" or text_cinematic_piedestal_arme==2:
				if text_cinematic_piedestal_arme==1:
					if cinematic=="arc":
						can2.itemconfig(texte_ligne_1,image=reponse_positive_arc)
					if cinematic=="épée":
						can2.itemconfig(texte_ligne_1,image=reponse_positive_epee)
					text_cinematic_piedestal_arme+=1
					question=False
				else:
					can2.itemconfig(texte_ligne_1,image=invisible)
					arme=cinematic
					text_cinematic_piedestal_arme+=1
					if arme=="épée":
						can2.create_image(300,100, image=piedestal_epee_vide, anchor="nw")
						if sens=="haut":
							can2.itemconfig(perso, image=dos_static_epee)
						elif sens=="bas":
							can2.itemconfig(perso, image=face_static_epee)
						elif sens=="droite":
							can2.itemconfig(perso, image=droite_static_epee)
						elif sens=="gauche":
							can2.itemconfig(perso, image=gauche_static_epee)
						moment=[face_static_epee,face_mouvement1_epee,face_mouvement2_epee,dos_static_epee,dos_mouvement1_epee,dos_mouvement2_epee,droite_static_epee,droite_mouvement1_epee,gauche_static_epee,gauche_mouvement1_epee]
					else:
						can2.create_image(700, 100, image=piedestal_arc_vide, anchor="nw")
						if sens=="haut":
							can2.itemconfig(perso, image=dos_static_arc)
						elif sens=="bas":
							can2.itemconfig(perso, image=face_static_arc)
						elif sens=="droite":
							can2.itemconfig(perso, image=droite_static_arc)
						elif sens=="gauche":
							can2.itemconfig(perso, image=gauche_static_arc)
						moment=[face_static_arc,face_mouvement1_arc,face_mouvement2_arc,dos_static_arc,dos_mouvement1_arc,dos_mouvement2_arc,droite_static_arc,droite_mouvement1_arc,gauche_static_arc,gauche_mouvement1_arc]
					reponse=None
					explication = can2.create_image(550,100,image=tuto_arme_salle2)
					Mafenetre.update()
					can2.after(3000)
					can2.delete(explication)
					apparition_ennemis(None)
			elif reponse=="negative":
				can2.itemconfig(texte_ligne_1, image=invisible)
				can2.itemconfig(texte_ligne_2, image=invisible)
				question=False
				cinematic=False
				reponse=None
		else:
			if text_cinematic_piedestal_arme==1:
				if cinematic=="arc":
					can2.itemconfig(texte_ligne_1,image=text_1_arc_premiere_interaction)
				if cinematic=="épée":
					can2.itemconfig(texte_ligne_1,image=text_1_epee_premiere_interaction)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==2:
				can2.itemconfig(texte_ligne_1,image=text_2_arme_premiere_interaction)
				can2.itemconfig(texte_ligne_2,image=invisible)
				text_cinematic_piedestal_arme=1
				question=True

	else:
		if arme=="arc" and cinematic=="arc":
			if text_cinematic_piedestal_arme==3:
				can2.itemconfig(texte_ligne_1,image=text_1_arme_arc_devant_piedestale_arc)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==4:
				can2.itemconfig(texte_ligne_1,image=text_2_arme_arc_devant_piedestale_arc)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==5:
				can2.itemconfig(texte_ligne_1, image=invisible)
				text_cinematic_piedestal_arme=3
				cinematic=False

		elif arme=="arc" and cinematic=="épée":
			if text_cinematic_piedestal_arme==3:
				can2.itemconfig(texte_ligne_1,image=text_1_arme_arc_devant_piedestale_epee)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==4:
				can2.itemconfig(texte_ligne_1, image=invisible)
				text_cinematic_piedestal_arme=3
				cinematic=False

		elif arme=="épée" and cinematic=="arc":
			if text_cinematic_piedestal_arme==3:
				can2.itemconfig(texte_ligne_1,image=text_1_arme_epee_devant_piedestale_arc)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==4:
				can2.itemconfig(texte_ligne_1,image=text_2_arme_epee_devant_piedestale_arc)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==5:
				can2.itemconfig(texte_ligne_1, image=invisible)
				text_cinematic_piedestal_arme=3
				cinematic=False

		elif arme=="épée" and cinematic=="épée":
			if text_cinematic_piedestal_arme==3:
				can2.itemconfig(texte_ligne_1,image=text_1_arme_epee_devant_piedestale_epee)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==4:
				can2.itemconfig(texte_ligne_1,image=text_2_arme_epee_devant_piedestale_epee)
				text_cinematic_piedestal_arme+=1
			elif text_cinematic_piedestal_arme==5:
				can2.itemconfig(texte_ligne_1, image=invisible)
				text_cinematic_piedestal_arme=3
				cinematic=False

def cinematic_autel():
	"""joue la cinematique de la stèle"""
	global text_cinematic_autel_1, text_cinematic_autel_2, cinematic_autel_arme, cinematic,reapparition
	can2.lift(texte_ligne_1)
	if cinematic_autel_arme==0:
		if text_cinematic_autel_1==4:
			can2.itemconfig(texte_ligne_1,image=text_1_autel_premiere_interaction)
			text_cinematic_autel_1-=1
		elif text_cinematic_autel_1==3:
			can2.itemconfig(texte_ligne_1,image=text_2_autel_premiere_interaction)
			text_cinematic_autel_1-=1
		elif text_cinematic_autel_1==2:
			can2.itemconfig(texte_ligne_1,image=text_3_autel_premiere_interaction)
			text_cinematic_autel_1-=1
		elif text_cinematic_autel_1==1:
			can2.itemconfig(texte_ligne_1,image=text_4_autel_premiere_interaction)
			text_cinematic_autel_1-=1
		elif text_cinematic_autel_1==0:
			can2.itemconfig(texte_ligne_1,image=invisible)
			reapparition=False
			creation_map()
			text_cinematic_autel_1-=1
	else:
		if text_cinematic_autel_2==2:
			can2.itemconfig(texte_ligne_1,image=text_1_autel_seconde_interaction)
			text_cinematic_autel_2-=1
		elif text_cinematic_autel_2==1:
			can2.itemconfig(texte_ligne_1,image=text_2_autel_seconde_interaction)
			text_cinematic_autel_2-=1
		else:
			can2.itemconfig(texte_ligne_1,image=invisible)
			text_cinematic_autel_2=2
			cinematic=False


#FONCTIONS DU NIVEAU 3 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FONCTIONS DU NIVEAU 3

#FONCTIONS

#aucune fonction spécifique à ce niveau

#FONCTIONS DU NIVEAU 4 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////ET FONCTIONS DU NIVEAU 4

def cinematic_mage():
	"""lance les lignes de dialogue avec le mage"""
	global text_cinematic_mage, porte_fin,texte_pnj
	if text_cinematic_mage==0:
		texte_pnj=can4.create_image(500,560,image=texte_1_mage)
		text_cinematic_mage+=1
	
	elif text_cinematic_mage==1:
		can4.itemconfig(texte_pnj, image=texte_2_mage)
		text_cinematic_mage+=1
	
	elif text_cinematic_mage==2:
		can4.itemconfig(texte_pnj, image=texte_3_mage)
		text_cinematic_mage+=1
		
	elif text_cinematic_mage==3:
		can4.itemconfig(texte_pnj, image=texte_4_mage)
		text_cinematic_mage+=1
		
	elif text_cinematic_mage==4:
		can4.itemconfig(texte_pnj, image=invisible)
		text_cinematic_mage+=1
		porte_fin=True
		cinematic=False
		creation_map()

#FONCTIONS DU NIVEAU 5 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FONCTIONS DU NIVEAU 5

def cinematic_boss():
	"""lance les lignes de dialogue avec le boss"""
	global text_cinematic_boss,texte_boss,image_boss,perso,cinematic,posX,posY,apocalypse,reapparition,current_level,skin_apparition,reapparition,dangereux
	if text_cinematic_boss==0:
		texte_boss=current_canvas.create_image(0,505,image=texte_1_boss,anchor="nw")
		text_cinematic_boss+=1
	
	elif text_cinematic_boss==1:
		current_canvas.itemconfig(texte_boss, image=texte_2_boss)
		text_cinematic_boss+=1
	
	elif text_cinematic_boss==2:
		current_canvas.itemconfig(texte_boss, image=texte_3_boss)
		text_cinematic_boss+=1
		
	elif text_cinematic_boss==3:
		current_canvas.itemconfig(texte_boss, image=texte_4_boss)
		text_cinematic_boss+=1
		
	elif text_cinematic_boss==4:
		can5.itemconfig(texte_boss, image=invisible)
		Mafenetre.update()
		text_cinematic_boss+=1
		can5.itemconfig(image_boss,image=orc_boss_pointe)
		Mafenetre.update()
		cinematic=False
		current_canvas.after(750)
		current_canvas.itemconfig(image_boss,image=orc_boss_bouclier)
		apparition_ennemis(None)
	elif text_cinematic_boss==6:
		current_canvas.itemconfig(image_boss,image=orc_boss)
		current_canvas.itemconfig(texte_boss, image=texte_5_boss)
		text_cinematic_boss+=1
	elif text_cinematic_boss==7:
		current_canvas.itemconfig(texte_boss, image=texte_6_boss)
		current_canvas.itemconfig(image_boss,image=orc_boss_pointe)
		text_cinematic_boss+=1
	elif text_cinematic_boss==8:	
		text_cinematic_boss+=1
		esquive=current_canvas.create_image(500,200,image=esquive_bas,anchor="nw")
		current_canvas.itemconfig(perso,image=moment[3])
		current_canvas.coords(perso,500,300)
		posX=500
		posY=300
		Mafenetre.update()
		current_canvas.after(200)
		current_canvas.itemconfig(esquive,image=invisible)
		current_canvas.itemconfig(texte_boss, image=invisible)
		current_canvas.coords(image_boss,0,0)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_1)
		Mafenetre.update()
		current_canvas.after(700)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_2)
		Mafenetre.update()
		current_canvas.after(700)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_3)
		Mafenetre.update()
		current_canvas.after(700)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_4)
		Mafenetre.update()
		current_canvas.after(700)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_5)
		Mafenetre.update()
		current_canvas.after(700)
		current_canvas.itemconfig(image_boss,image=cinematique_vague3_6)
		Mafenetre.update()
		current_canvas.after(700)
		apocalypse=1
		reapparition=False
		creation_map()
		apparition_ennemis("vague3")
	elif text_cinematic_boss==10:
		current_canvas.unbind('<Key>')
		if arme=="épée":
			current_canvas.lower(perso)
			current_canvas.coords(image_boss,400,0)
			current_canvas.itemconfig(image_boss,image=cinematique_vague3_7)
			Mafenetre.update()
			current_canvas.after(700)
			current_canvas.itemconfig(image_boss,image=cinematique_vague3_8)
			Mafenetre.update()
			current_canvas.after(700)
			current_canvas.itemconfig(image_boss,image=cinematique_vague3_9)
			Mafenetre.update()
			current_canvas.after(700)
			current_canvas.itemconfig(image_boss,image=cinematique_vague3_10)
			Mafenetre.update()
		else:
			current_canvas.itemconfig(image_boss,image=boss_fleche)
			Mafenetre.update()
		current_canvas.lift(texte_boss)
		current_canvas.itemconfig(texte_boss, image=non)
		transition=current_canvas.create_image(0,0,image=transition1_V,anchor="nw")
		Mafenetre.update()
		current_canvas.after(500)
		current_canvas.itemconfig(transition,image=transition2_V)
		Mafenetre.update()
		current_canvas.after(500)
		current_canvas.itemconfig(transition,image=transition3_V)
		Mafenetre.update()
		current_canvas.after(500)
		text_cinematic_boss+=1
		posX=900
		posY=300
		dangereux.remove("S/T")
		dangereux.remove("MFM/T")
		current_level="niveau1"
		creation_map()
		
def cinematic_fin():
	"""lance la cinématique juste après le combat de boss"""
	global perso,moment,cinematic,arme,pouvoir_esquive
	cinematic="statuette"
	perso=current_canvas.create_image(900,300,image=droite_mouvement1,anchor="nw")
	moment=[face_static,face_mouvement1,face_mouvement2,dos_static,dos_mouvement1,dos_mouvement2,droite_static,droite_mouvement1,gauche_static,gauche_mouvement1]
	can1.create_image(900,300,image=piedestal_cinematic,anchor="nw")
	can1.lift(perso)
	boss_theme.stop()
	tete = can1.create_image(955,310,image=tete_jade,anchor="nw")
	Mafenetre.update()
	can1.after(700)
	can1.lift(perso)
	can1.coords(perso,posX-20,posY)
	can1.itemconfig(perso,image=droite_mouvement1)
	Mafenetre.update()
	can1.after(700)
	can1.coords(tete,955,300)
	Mafenetre.update()
	can1.coords(tete,925,300)
	can1.itemconfig(tete,image=tete_jade_explosion1)
	Mafenetre.update()
	can1.after(700)
	can1.itemconfig(tete,image=tete_jade_explosion2)
	Mafenetre.update()
	can1.after(700)
	can1.delete(tete)
	can1.bind('<Key>',clavier)
	cinematic=False
	arme=False
	pouvoir_esquive=False

#FONCTION DU HÉROS ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// FONCTION DU HÉROS

def blessure(origine,case_precedente,esquive):
	""" affiche une trace de sang si le joueur a été blessé par un ennemi, le fait réaparaitre si il est tombé dans un trou """
	global perso,cinematic,effondrement,posX,posY,possible,lave_special,apocalypse,vie,current_level
	cinematic="piege"
	skin=[[chute1,chute2],[chute1T,chute2T]]
	print(effondrement)
	if origine == "T" or origine == "MFM/T" or origine == "S/T" or origine == "TD":
		if difficulte==2:
			vie-=1
		if apocalypse == 1:
			effondrement=0
		cinematic="Vous avez fait une chute qui s'est avéré mortelle"
		current_canvas.lower(perso)
		if current_level=="niveau5":
			chute_perso=current_canvas.create_image(posX,posY,image=skin[1][0],anchor="nw")
		else:
			chute_perso=current_canvas.create_image(posX,posY,image=skin[effondrement][0],anchor="nw")
		chute.play()
		Mafenetre.update()
		current_canvas.after(200)
		current_canvas.itemconfig(chute_perso,image=skin[effondrement][1])
		Mafenetre.update()
		current_canvas.after(200)
		current_canvas.delete(chute_perso)
		if case_precedente == "gauche":
			posX+=100
			if esquive== True:
				posX+=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "droite":
			posX-=100
			if esquive== True:
				posX-=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "haut":
			posY+=100
			if esquive== True:
				posY+=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "bas":
			posY-=100
			if esquive== True:
				posY-=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		chute.stop()
	elif origine == "L" or origine in lave_special:
		if difficulte==2:
			vie-=1
		cinematic="Vous avez été carbonisé par les flammes"
		current_canvas.lower(perso)
		brule_perso=current_canvas.create_image(posX,posY,image=flamme,anchor="nw")
		Mafenetre.update()
		current_canvas.after(200)
		current_canvas.delete(brule_perso)
		if case_precedente == "gauche":
			posX+=100
			if esquive== True:
				posX+=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "droite":
			posX-=100
			if esquive== True:
				posX-=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "haut":
			posY+=100
			if esquive== True:
				posY+=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
		if case_precedente == "bas":
			posY-=100
			if esquive== True:
				posY-=100
			current_canvas.coords(perso,posX,posY)
			Mafenetre.update()
	elif origine == "ennemi":
		cinematic="Vous avez subie une attaque qui a causé votre perte"
	current_canvas.lift(perso)
	compteur_vies()
	cinematic=False

def compteur_vies():
	global vie, cinematic,mort
	""" affiche le nombre de vie restantes au joueur """
	current_canvas.create_image(55,530,image=coeur_vide,anchor="nw")
	current_canvas.create_image(107,530,image=coeur_vide,anchor="nw")
	current_canvas.create_image(159,530,image=coeur_vide,anchor="nw")
	Mafenetre.update()
	if vie == 0:
		mort+=1
		pygame.mixer.stop()
		if mort>=3:
			cri.play()
		else:
			game_over.play()
		current_canvas.create_image(0,500, image=HUD_mort,anchor="nw")
		if cinematic == "Vous avez été carbonisé par les flammes":
			current_canvas.create_image(0,0, image=mort_flamme,anchor="nw")
		elif cinematic == "Vous avez subie une attaque qui a causé votre perte":
			current_canvas.create_image(0,0, image=mort_ennemi,anchor="nw")
		elif cinematic == "Vous avez fait une chute qui s'est avéré mortelle":
			current_canvas.create_image(0,0, image=mort_chute,anchor="nw")
		if cinematic == "victoire":
			current_canvas.create_image(0,0, image=victoire,anchor="nw")
			pygame.mixer.stop()
			fin.play()
			#current_canvas.bind('<Key>',clavier)
	else:
		for i in range (1,vie+1):
			if i%2==0:
				current_canvas.create_image(55+(26*(i-1)),530,image=cote_coeur_droit,anchor="nw")
			else:
				current_canvas.create_image(55+(26*(i-1)),530,image=cote_coeur_gauche,anchor="nw")
			Mafenetre.update()


def clavier(event):
	#event récupère l'information tapé sur le clavier
	"""gère l'appuie du joueur sur le clavier"""
	global posX,posY,current_level,current_canvas,pouvoir_esquive, temps_appuie, temps_Daction,choix_dif,reapparition,difficulte,skin_apparition,cinematic,sens,perso,disparition,moment, utilise,action,effondrement,validation,possible,vie,fin_tuto,question,reponse,ennemis_restant,arme, chaine, musique_lancée, troll, mort, temps_debut
	colonne=posX//100
	ligne=posY//100
	touche_char=event.char
	touche_autre=event.keysym
	if vie>0:	
		if current_level!="niveau0":
			bloquage=0
			if (touche_char=='z' or touche_char=='Z' ) and (cinematic==False):
				for i in range (len(ennemis_restant)):
						if posX == ennemis_restant[i]["positionX"] and posY-100 == ennemis_restant[i]["positionY"]:
							bloquage=1
				if action==False:
					current_canvas.itemconfig(perso,image=moment[3])
					sens="haut"
				if bloquage==0:
					if matrice[ligne-1][colonne] in possible:
						mvt_haut()
			elif (touche_char=='d' or touche_char=='D') and (cinematic==False):
				for i in range (len(ennemis_restant)):
						if posX+100 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
							bloquage=1
				if action==False:
					current_canvas.itemconfig(perso,image=moment[6])
					sens="droite"
				if bloquage==0:
					if matrice[ligne][colonne+1] in possible:
						mvt_droite()
			elif (touche_char=='q' or touche_char=='Q') and (cinematic==False):
				for i in range (len(ennemis_restant)):
						if posX-100 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
							bloquage=1
				if action==False:
					current_canvas.itemconfig(perso,image=moment[8])
					sens="gauche"
				if bloquage==0:
					if matrice[ligne][colonne-1] in possible:
						mvt_gauche()
			elif (touche_char=='s' or touche_char=='S') and (cinematic==False):
				for i in range (len(ennemis_restant)):
						if posX == ennemis_restant[i]["positionX"] and posY+100 == ennemis_restant[i]["positionY"]:
							bloquage=1
				if action==False:
					current_canvas.itemconfig(perso,image=moment[0])
					sens="bas"
				if bloquage==0:
					if matrice[ligne+1][colonne] in possible:
						mvt_bas()
			elif touche_char=='e' or touche_char=='E':
				if cinematic==False and near_object()!=False:
					launch_cinematic(near_object())
				elif cinematic!=False:
					if cinematic=="autel":
						cinematic_autel()
					if cinematic=="épée" or cinematic=="arc":
						cinematic_piedestal_arme()
					if cinematic=="symbole":
						cinematic_symbole()
					if cinematic=="mage":
						cinematic_mage()		
					if cinematic=="boss":
						cinematic_boss()		
			elif touche_autre=='space' and pouvoir_esquive==True and cinematic==False and action==False:
				esquive()
			elif touche_autre=='Return' and arme != False and action==False and cinematic==False and initialisation==0:
				if arme =="épée":
					frappe_epee(sens)
				if arme =="arc":
					tir_arc(sens)
			elif touche_autre=='Left'and cinematic==False and action==False:
				current_canvas.itemconfig(perso,image=moment[8])
				sens="gauche"
			elif touche_autre=='Right'and cinematic==False and action==False:
				current_canvas.itemconfig(perso,image=moment[6])
				sens="droite"
			elif touche_autre=='Down'and cinematic==False and action==False:
				current_canvas.itemconfig(perso,image=moment[0])
				sens="bas"
			elif touche_autre=='Up'and cinematic==False and action==False:
				current_canvas.itemconfig(perso,image=moment[3])
				sens="haut"
			elif (touche_char=="o" or touche_char=='O') and (question==True):
				reponse="positive"
				if cinematic=="épée" or cinematic=="arc":
					cinematic_piedestal_arme()
			elif (touche_char=="n" or touche_char=='N') and (question==True):
				reponse="negative"
				if cinematic=="épée" or cinematic=="arc":
					cinematic_piedestal_arme()			
			if current_level=="niveau1" and cinematic==False and fin_tuto==False:
				tutoriel(1)
		else:
			if (touche_autre=='KP_1' or touche_autre=='ampersand' or touche_autre=='1') and validation==1:
				if choix_dif==True:
					difficulte = 0
					debut_jeu()
				else:
					ecran_3()
			elif (touche_autre=='KP_2' or touche_autre=='eacute' or touche_autre=='Eacute'or touche_autre=='2') and validation==1:
				if choix_dif==None:
					exit()
				if choix_dif==True:
					difficulte = 1
					debut_jeu()
			elif (touche_autre=='KP_3' or touche_autre=='quotedbl'or touche_autre=='3') and validation==1:
				if choix_dif==True:
					difficulte = 2
					debut_jeu()
			elif touche_autre=='Return' and validation==0:
				chaine.replace(" ","")
				validation=1
			elif (chaine!="wtf" or chaine!="WTF") and troll!=1:
				if touche_char!=" " or touche_char!="Space":
					chaine+=touche_char
					chaine.replace(" ","")
					if len(chaine)>3:
						chaine=""
				if chaine=="wtf" or chaine=="WTF":
					troll=1
	else:
		if (touche_autre=='KP_1' or touche_autre=='ampersand' or touche_autre=='1') and vie==0:
			current_canvas.unbind('<Key>')
			can1.bind('<Key>',clavier)
			pygame.mixer.stop()
			initialisation_depart()
			musique_lancée=False
			debut_jeu()
		elif (touche_autre=='KP_2' or touche_autre=='eacute' or touche_autre=='Eacute'or touche_autre=='2') and vie==0:
			current_canvas.unbind('<Key>')
			can0.bind('<Key>',clavier)
			pygame.mixer.stop()
			initialisation_depart()
			musique_lancée=False
			mort=0
			temps_debut=time.time()
			ecran_titre()

def frappe_epee(direction):
	"""le personnage va frapper avec son épée"""
	global ennemis_restant,posX,posY,perso,temps_Daction,faible
	colonne=posX//100
	ligne=posY//100
	current_canvas.lift(perso)
	if time.time()-temps_Daction>=0.5:
		action=True
		temps_Daction=time.time()
		if direction=="gauche" and (matrice[ligne][colonne-1] in possible and not (matrice[ligne][colonne-1] in dangereux) or matrice[ligne][colonne-1]=="SPE"):
			son_epee.play()
			if matrice[ligne][colonne-1]=="SPE" and faible==1:
				faible=0
				blessure_boss()
			current_canvas.itemconfig(perso,image=frappe_gauche,anchor="ne")
			Mafenetre.update()
			for i in range (len(ennemis_restant)):
				if posX-100 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
					damage.play()
					ennemis_restant[i]["vie"]-=1
					mort_ennemis(ennemis_restant[i],i)
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=gauche_static_epee,anchor="nw")
			Mafenetre.update()
		
		elif direction=="droite" and (matrice[ligne][colonne+1] in possible and not (matrice[ligne][colonne+1] in dangereux) or matrice[ligne][colonne+1]=="SPE"):
			son_epee.play()
			if matrice[ligne][colonne+1]=="SPE" and faible==1:
				faible=0
				blessure_boss()
			if current_level!="niveau1":	
				current_canvas.itemconfig(perso,image=frappe_droite,anchor="nw")
				Mafenetre.update()
				for i in range (len(ennemis_restant)):
					if posX+100 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
						damage.play()						
						ennemis_restant[i]["vie"]-=1
						mort_ennemis(ennemis_restant[i],i)
				current_canvas.after(300)
				current_canvas.itemconfig(perso,image=droite_static_epee,anchor="nw")
				Mafenetre.update()
		
		elif direction=="haut" and (matrice[ligne-1][colonne] in possible and not (matrice[ligne-1][colonne] in dangereux) or matrice[ligne-1][colonne]=="SPE"):
			son_epee.play()
			if matrice[ligne-1][colonne]=="SPE" and faible==1:
				faible=0
				blessure_boss()
			current_canvas.itemconfig(perso,image=frappe_dos,anchor="center")
			Mafenetre.update()
			for i in range (len(ennemis_restant)):
				if posX == ennemis_restant[i]["positionX"] and posY-100 == ennemis_restant[i]["positionY"]:
					damage.play()
					ennemis_restant[i]["vie"]-=1
					mort_ennemis(ennemis_restant[i],i)
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=dos_static_epee,anchor="nw")
			Mafenetre.update()
		
		elif direction=="bas" and (matrice[ligne+1][colonne] in possible and not (matrice[ligne+1][colonne] in dangereux) or matrice[ligne+1][colonne]=="SPE"):
			son_epee.play()
			current_canvas.itemconfig(perso,image=frappe_face,anchor="nw")
			Mafenetre.update()
			for i in range (len(ennemis_restant)):
				if posX == ennemis_restant[i]["positionX"] and posY+100 == ennemis_restant[i]["positionY"]:
					damage.play()
					ennemis_restant[i]["vie"]-=1
					mort_ennemis(ennemis_restant[i],i)
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=face_static_epee,anchor="nw")
			Mafenetre.update()

def tir_arc(direction):
	"""le personnage va bander son arc (la fonction gérant la flèche sera aussi lancé)"""
	global perso,action,temps_Daction,posX_fleche,posY_fleche
	posX_fleche=posX
	posY_fleche=posY
	if time.time()-temps_Daction>=0.5:
		temps_Daction=time.time()
		action=True
		if direction=="gauche":
			current_canvas.itemconfig(perso,image=tir_gauche)
			Mafenetre.update()
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=gauche_static_arc)
			Mafenetre.update()
		elif direction=="droite":
			current_canvas.itemconfig(perso,image=tir_droite)
			Mafenetre.update()
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=droite_static_arc)
			Mafenetre.update()
		elif direction=="haut":
			current_canvas.itemconfig(perso,image=tir_dos)
			Mafenetre.update()
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=dos_static_arc)
			Mafenetre.update()
		else:
			current_canvas.itemconfig(perso,image=tir_face)
			Mafenetre.update()
			current_canvas.after(300)
			current_canvas.itemconfig(perso,image=face_static_arc)
			Mafenetre.update()
		action=False
		fleche_lance(direction)

def fleche_lance(direction):
	"""la flèche du perso va filer en ligne droite"""
	global ennemi_restant,posX,posY,faible,initialisation,fleche,posX_fleche,posY_fleche
	colonne=posX_fleche//100
	ligne=posY_fleche//100
	bloque=0
	if direction=="gauche":
		for i in range (len(ennemis_restant)):
			if posX_fleche == ennemis_restant[i]["positionX"] and posY_fleche == ennemis_restant[i]["positionY"]:
				if troll==1:
					headshot.play()
				else:
					damage.play()
				ennemis_restant[i]["vie"]-=0.75
				mort_ennemis(ennemis_restant[i],i)
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
				bloque=1
		if not (matrice[ligne][colonne-1] in possible):
			if matrice[ligne][colonne-1] == "SPE" and faible==1:
				faible=0
				blessure_boss()

			if initialisation==1:
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
		elif bloque==0:
			if initialisation==0:
				fleche=current_canvas.create_image(posX_fleche-100,posY_fleche,image=fleche_gauche,anchor="nw")
				initialisation=1
				fleche_lance(direction)

			elif initialisation==1:
				posX_fleche-=100
				current_canvas.coords(fleche,posX_fleche,posY_fleche)
				Mafenetre.update()
				current_canvas.after(100)
				fleche_lance(direction)
				

	elif direction=="droite":
		for i in range (len(ennemis_restant)):
			if posX_fleche == ennemis_restant[i]["positionX"] and posY_fleche == ennemis_restant[i]["positionY"]:
				if troll==1:
					headshot.play()
				else:
					damage.play()				
				ennemis_restant[i]["vie"]-=0.75
				mort_ennemis(ennemis_restant[i],i)
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
				bloque=1

		if not (matrice[ligne][colonne+1] in possible):
			if matrice[ligne][colonne+1] == "SPE" and faible==1:
				faible=0
				blessure_boss()

			if initialisation==1:
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
		elif bloque==0:
			if initialisation==0:
				fleche=current_canvas.create_image(posX_fleche+100,posY_fleche,image=fleche_droite,anchor="nw")
				initialisation=1
				fleche_lance(direction)

			elif initialisation==1:
				posX_fleche+=100
				current_canvas.coords(fleche,posX_fleche,posY_fleche)
				Mafenetre.update()
				current_canvas.after(100)
				fleche_lance(direction)

	elif direction=="haut":
		for i in range (len(ennemis_restant)):
			if posX_fleche == ennemis_restant[i]["positionX"] and posY_fleche == ennemis_restant[i]["positionY"]:
				if troll==1:
					headshot.play()
				else:
					damage.play()				
				ennemis_restant[i]["vie"]-=0.75
				mort_ennemis(ennemis_restant[i],i)
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
				bloque=1

		if not (matrice[ligne-1][colonne] in possible):
			if matrice[ligne-1][colonne] == "SPE" and faible==1:
				faible=0
				blessure_boss()

			if initialisation==1:
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
		elif bloque==0:
			if initialisation==0:
				fleche=current_canvas.create_image(posX_fleche,posY_fleche-100,image=fleche_haut,anchor="nw")
				initialisation=1
				fleche_lance(direction)

			elif initialisation==1:
				posY_fleche-=100
				current_canvas.coords(fleche,posX_fleche,posY_fleche)
				Mafenetre.update()
				current_canvas.after(100)
				fleche_lance(direction)
	else:
		for i in range (len(ennemis_restant)):
			if posX_fleche == ennemis_restant[i]["positionX"] and posY_fleche == ennemis_restant[i]["positionY"]:
				if troll==1:
					headshot.play()
				else:
					damage.play()				
				ennemis_restant[i]["vie"]-=0.75
				mort_ennemis(ennemis_restant[i],i)
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
				initialisation=0
				bloque=1

		if not (matrice[ligne+1][colonne] in possible):
			if initialisation==1:
				current_canvas.after(100)
				current_canvas.itemconfig(fleche,image=invisible)
			initialisation=0
		elif bloque==0:
			if initialisation==0:
				fleche=current_canvas.create_image(posX_fleche,posY_fleche+100,image=fleche_bas,anchor="nw")
				initialisation=1
				fleche_lance(direction)

			elif initialisation==1:
				posY_fleche+=100
				current_canvas.coords(fleche,posX_fleche,posY_fleche)
				Mafenetre.update()
				current_canvas.after(100)
				fleche_lance(direction)
	initialisation=0

def esquive():
	""" le personnage esquive dans sa direction actuel """
	global perso,sens,matrice,possible,posX,posY,matrice,vie,dangereux,ennemis_restant
	colonne=posX//100
	ligne=posY//100
	action=True
	fumee=0
	bloquage=0
	if posX+200 < 1100:
		if sens== "droite" and matrice[ligne][colonne+2] in possible:
			for i in range (len(ennemis_restant)):
				if posX+200 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
					bloquage=1
			if bloquage==0:
				posX+=200
				current_canvas.coords(perso,posX,posY)
				fumee = current_canvas.create_image(posX+-100,posY,image=esquive_droite,anchor="nw")
				Mafenetre.update()
				action=False
				current_canvas.after(300)
	if posX-200 >= 0:
		if sens== "gauche" and matrice[ligne][colonne-2] in possible:
			for i in range (len(ennemis_restant)):
				if posX-200 == ennemis_restant[i]["positionX"] and posY == ennemis_restant[i]["positionY"]:
					bloquage=1
			if bloquage==0:
				posX-=200
				current_canvas.coords(perso,posX,posY)
				fumee = current_canvas.create_image(posX,posY,image=esquive_gauche,anchor="nw")
				Mafenetre.update()
				action=False
				current_canvas.after(300)
	if posY-200 >= 0:
		if sens== "haut" and matrice[ligne-2][colonne] in possible:
			if posY-200>=0:
				for i in range (len(ennemis_restant)):
					if posX == ennemis_restant[i]["positionX"] and posY-200 == ennemis_restant[i]["positionY"]:
						bloquage=1
				if bloquage==0:
						posY-=200
						current_canvas.coords(perso,posX,posY)
						fumee = current_canvas.create_image(posX,posY,image=esquive_haut,anchor="nw")
						Mafenetre.update()
						action=False
						current_canvas.after(300)
	if posY+200 < 600:
		if sens== "bas" and matrice[ligne+2][colonne] in possible :
			for i in range (len(ennemis_restant)):
				if posX == ennemis_restant[i]["positionX"] and posY+200 == ennemis_restant[i]["positionY"]:
					bloquage=1
			if bloquage==0:
				posY+=200
				current_canvas.coords(perso,posX,posY)
				fumee = current_canvas.create_image(posX,posY-100,image=esquive_bas,anchor="nw")
				Mafenetre.update()
				action=False
				current_canvas.after(300)
	current_canvas.delete(fumee)
	if matrice[posY//100][posX//100] in dangereux:
		vie-=1
		blessure(matrice[posY//100][posX//100],sens,True)

def mvt_haut():
	global perso,posY,posX,temps_Daction,cinematic, autel,action,sens,matrice,vie,dangereux,sens
	"""déplace le personnage vers le haut"""
	if time.time()-temps_Daction>=0.4:
		action=True
		bloquage=0
		temps_Daction=time.time()
		if posY-100 ==-100:
			bloquage=1
		if bloquage == 0:
			posY-=100
		#mise à jour de l'image
			current_canvas.itemconfig(perso,image=moment[4])
		#mise à jour des coordonnées
			current_canvas.coords(perso,posX,posY+67)
			Mafenetre.update()
			current_canvas.after(100)
		#mise à jour de l'image
			current_canvas.itemconfig(perso,image=moment[5])
		#mise à jour des coordonnées
			current_canvas.coords(perso,posX,posY+34)
			Mafenetre.update()
			current_canvas.after(100)
		#mise à jour de l'image
			current_canvas.itemconfig(perso,image=moment[3])
			action=False
		#mise à jour des coordonnées
			current_canvas.coords(perso,posX,posY)
			if matrice[posY//100][posX//100] in dangereux:
				vie-=1
				blessure(matrice[posY//100][posX//100],sens,False)

def mvt_bas():
	global perso,posY,posX,temps_Daction,cinematic, autel,action,sens,matrice,vie,dangereux,sens
	"""déplace le personnage vers le bas"""
	if time.time()-temps_Daction>=0.4:
		posY+=100
		action=True
		temps_Daction=time.time()
		#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[2])
		#mise à jour des coordonnées
		current_canvas.coords(perso,posX,posY-67)
		Mafenetre.update()
		current_canvas.after(100)
		#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[1])
		#mise à jour des coordonnées
		current_canvas.coords(perso,posX,posY+-34)
		Mafenetre.update()
		current_canvas.after(100)
		#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[0])
		action=False
		#mise à jour des coordonnées
		current_canvas.coords(perso,posX,posY)
		if matrice[posY//100][posX//100] in dangereux:
			vie-=1
			blessure(matrice[posY//100][posX//100],sens,False)

def mvt_droite():
	global perso,posX,PosY,temps_Daction,cinematic, autel,action,sens,matrice,vie,dangereux,sens
	"""déplace le personnage vers la droite"""
	if time.time()-temps_Daction>=0.4:
		posX+=100
		action=True
		temps_Daction=time.time()
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[6])
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX-67,posY)
		Mafenetre.update()
		current_canvas.after(100)
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[7])
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX-34,posY)
		Mafenetre.update()
		current_canvas.after(100)
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[6])
		action=False
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX,posY)
		if matrice[posY//100][posX//100] in dangereux:
			vie-=1
			blessure(matrice[posY//100][posX//100],sens,False)

def mvt_gauche():
	global perso,posX,posY, temps_Daction,cinematic, autel,action,sens,matrice,vie,dangereux,sens
	"""déplace le personnage vers la gauche"""
	if time.time()-temps_Daction>=0.4:
		posX-=100
		action=True
		temps_Daction=time.time()
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[8])
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX+67,posY)
		Mafenetre.update()
		current_canvas.after(100)
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[9])
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX+34,posY)
		Mafenetre.update()
		current_canvas.after(100)
	#mise à jour de l'image
		current_canvas.itemconfig(perso,image=moment[8])
		action=False
	#mise à jour des coordonnées
		current_canvas.coords(perso,posX,posY)
		if matrice[posY//100][posX//100] in dangereux:
			vie-=1
			blessure(matrice[posY//100][posX//100],sens,False)

#FONCTION DES ENNEMIS ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// FONCTION DES ENNEMIS

def action_ennemi(X,Y,mvt_anterieur,PV):
	"""décide ce que l'ennemi doit accomplir comme action en fonction de la position du personnage"""
	global posX,posY
	if PV <=0:
		return (("mort","rien"))
	else:
		if X==posX+100 and Y==posY:
			return (("attaque","gauche"))
		elif X==posX-100 and Y==posY:
			return (("attaque","droite"))
		elif X==posX and Y==posY-100:
			return (("attaque","bas"))
		elif X==posX and Y==posY+100:
			return (("attaque","haut"))
		elif X>posX and mvt_anterieur !="droite":
			return (("mouvement","gauche"))
		elif Y<posY and mvt_anterieur !="haut":
			return (("mouvement","bas"))
		elif X<posX and mvt_anterieur !="gauche":
			return (("mouvement","droite"))
		elif Y>posY and mvt_anterieur !="bas":
			return (("mouvement","haut"))
		else:
			return (("mouvement","haut"))

def apparition_ennemis(vague):
	"""initialise les variables des ennemis en fonction du niveau"""
	global current_level, ennemi1_stat, ennemi2_stat, ennemi3_stat,ennemi4_stat, ennemi1,ennemi2,ennemi3,ennemi4,difficulte,cinematic,ennemis_restant,affichage_ennemi_restant,nb_mort
	if troll==1:
		hello.play()
	if current_level=="niveau2":
		ennemi1_stat={"type":"orc_massue","positionX":100,"positionY":100,"image":orc_massue_face_static,"temps_Daction":time.time(),"orientation":"bas","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi2_stat={"type":"orc_massue","positionX":900,"positionY":100,"image":orc_massue_face_static,"temps_Daction":time.time(),"orientation":"bas","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi1=current_canvas.create_image(ennemi1_stat["positionX"],ennemi1_stat["positionY"],image=ennemi1_stat["image"],anchor=ennemi1_stat["ancre"])
		ennemi2=current_canvas.create_image(ennemi2_stat["positionX"],ennemi2_stat["positionY"],image=ennemi2_stat["image"],anchor=ennemi2_stat["ancre"])
		ennemis_restant=[ennemi1_stat,ennemi2_stat]
		affichage_ennemi_restant=[ennemi1,ennemi2]
		cinematic=False
		nb_mort=0
		comportement_ennemis_cible()
	elif current_level=="niveau3":
		ennemi1_stat={"type":"orc_arc","positionX":900,"positionY":100,"image":orc_arc_gauche_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+1,"ancre":"nw","cibleX":None,"cibleY":None,"cible":None}
		ennemi1=current_canvas.create_image(ennemi1_stat["positionX"],ennemi1_stat["positionY"],image=ennemi1_stat["image"],anchor=ennemi1_stat["ancre"])
		ennemis_restant=[ennemi1_stat]
		affichage_ennemi_restant=[ennemi1]
		cinematic=False
		nb_mort=0
		comportement_ennemis()
	elif current_level=="niveau5" and vague == None:
		pygame.mixer.stop()
		boss_theme.play()
		ennemi1_stat={"type":"orc_massue","positionX":100,"positionY":100,"image":orc_massue_droite_static,"temps_Daction":time.time(),"orientation":"droite","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi2_stat={"type":"orc_massue","positionX":900,"positionY":100,"image":orc_massue_gauche_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi1=current_canvas.create_image(ennemi1_stat["positionX"],ennemi1_stat["positionY"],image=ennemi1_stat["image"],anchor=ennemi1_stat["ancre"])
		ennemi2=current_canvas.create_image(ennemi2_stat["positionX"],ennemi2_stat["positionY"],image=ennemi2_stat["image"],anchor=ennemi2_stat["ancre"])
		ennemis_restant=[ennemi1_stat,ennemi2_stat]
		affichage_ennemi_restant=[ennemi1,ennemi2]
		cinematic=False
		nb_mort=0
		comportement_ennemis()
	elif current_level=="niveau5" and vague == "vague2":
		ennemi1_stat={"type":"orc_massue","positionX":100,"positionY":100,"image":orc_massue_droite_static,"temps_Daction":time.time(),"orientation":"droite","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi2_stat={"type":"orc_massue","positionX":900,"positionY":100,"image":orc_massue_gauche_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi3_stat={"type":"orc_arc","positionX":100,"positionY":400,"image":orc_arc_face_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+1,"ancre":"nw","cibleX":None,"cibleY":None,"cible":None}
		ennemi1=current_canvas.create_image(ennemi1_stat["positionX"],ennemi1_stat["positionY"],image=ennemi1_stat["image"],anchor=ennemi1_stat["ancre"])
		ennemi2=current_canvas.create_image(ennemi2_stat["positionX"],ennemi2_stat["positionY"],image=ennemi2_stat["image"],anchor=ennemi2_stat["ancre"])
		ennemi3=current_canvas.create_image(ennemi3_stat["positionX"],ennemi3_stat["positionY"],image=ennemi3_stat["image"],anchor=ennemi3_stat["ancre"])
		ennemis_restant=[ennemi1_stat,ennemi2_stat,ennemi3_stat]
		affichage_ennemi_restant=[ennemi1,ennemi2,ennemi3]
		cinematic=False
		nb_mort=-1
		comportement_ennemis()
	elif current_level=="niveau5" and vague == "vague3":
		ennemi1_stat={"type":"orc_arc","positionX":100,"positionY":100,"image":orc_arc_droite_static,"temps_Daction":time.time(),"orientation":"droite","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+1,"ancre":"nw","cibleX":None,"cibleY":None,"cible":None}
		ennemi2_stat={"type":"orc_arc","positionX":900,"positionY":400,"image":orc_arc_gauche_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+1,"ancre":"nw","cibleX":None,"cibleY":None,"cible":None}
		ennemi3_stat={"type":"orc_massue","positionX":100,"positionY":400,"image":orc_massue_gauche_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi4_stat={"type":"orc_massue","positionX":900,"positionY":100,"image":orc_massue_droite_static,"temps_Daction":time.time(),"orientation":"gauche","prepare_attaque":0,"mvt_anterieur":"Rien","vie":difficulte+2,"ancre":"nw"}
		ennemi1=current_canvas.create_image(ennemi1_stat["positionX"],ennemi1_stat["positionY"],image=ennemi1_stat["image"],anchor=ennemi1_stat["ancre"])
		ennemi2=current_canvas.create_image(ennemi2_stat["positionX"],ennemi2_stat["positionY"],image=ennemi2_stat["image"],anchor=ennemi2_stat["ancre"])
		ennemi3=current_canvas.create_image(ennemi3_stat["positionX"],ennemi3_stat["positionY"],image=ennemi3_stat["image"],anchor=ennemi3_stat["ancre"])
		ennemi4=current_canvas.create_image(ennemi4_stat["positionX"],ennemi4_stat["positionY"],image=ennemi4_stat["image"],anchor=ennemi4_stat["ancre"])
		ennemis_restant=[ennemi3_stat,ennemi4_stat,ennemi1_stat,ennemi2_stat]
		affichage_ennemi_restant=[ennemi3,ennemi4,ennemi1,ennemi2]
		cinematic=False
		nb_mort=-2
		comportement_ennemis()

def cessez_le_feu():
	"""bloque le comportement ennemi"""
	global nb_mort
	nb_mort=42
	
def blessure_boss():
	"""gère les blessures infligés au boss"""
	global ennemi3,text_cinematic_boss,cinematic
	if troll==0:
		cri_boss.play()
	else:
		cri_boss_aigu.play()
	cessez_le_feu()
	if ennemi3==None:
		apparition_ennemis("vague2")
		current_canvas.itemconfig(image_boss,image=orc_boss_bouclier)
	elif text_cinematic_boss==5:
		text_cinematic_boss+=1
		cinematic="boss"
		cinematic_boss()
	elif text_cinematic_boss==9:
		text_cinematic_boss+=1
		cinematic="boss"
		cinematic_boss()
	
def comportement_ennemis():
	"""fonction maitre qui s'occupe de gérer toutes les fonctions aillant attrait au comportement des ennemis"""
	global ennemis_restant,vie,surcharge,nb_mort,cinematic
	if vie>0 and cinematic==False:
		for i in range (len(ennemis_restant)):
			prochaine_action=action_ennemi(ennemis_restant[i]["positionX"],ennemis_restant[i]["positionY"],ennemis_restant[i]["mvt_anterieur"],ennemis_restant[i]["vie"])
			if ennemis_restant[i]["type"]=="orc_massue":
				if prochaine_action[0]=="mouvement":
					if time.time() - ennemis_restant[i]["temps_Daction"]>=0.4:
						ennemis_restant[i]["temps_Daction"]=time.time()
						ennemis_restant[i]=mouvement_ennemis(ennemis_restant[i],prochaine_action[1],i)
						surcharge=0
				elif prochaine_action[0]=="attaque":
					if time.time() - ennemis_restant[i]["temps_Daction"]>=0.4:
						ennemis_restant[i]["temps_Daction"]=time.time()
						ennemis_restant[i]=attaque_ennemis(ennemis_restant[i],prochaine_action[1],i)
			elif ennemis_restant[i]["type"]=="orc_arc":
				if time.time() - ennemis_restant[i]["temps_Daction"]>=0.4:
					ennemis_restant[i]["temps_Daction"]=time.time()
					ennemis_restant[i]=attaque_ennemis(ennemis_restant[i],prochaine_action[1],i)
	if nb_mort<len(ennemis_restant):
		current_canvas.after(200, comportement_ennemis)
	else:
		nb_mort=0

def comportement_ennemis_cible():
	"""fonction maitre qui s'occupe de gérer toutes les fonctions aillant attrait au comportement des ennemis (cette fonction sert pour des ennemis au action limitée"""
	global ennemis_restant,vie,surcharge,nb_mort,difficulte
	if vie>0:
		for i in range (len(ennemis_restant)):
			prochaine_action=action_ennemi(ennemis_restant[i]["positionX"],ennemis_restant[i]["positionY"],ennemis_restant[i]["mvt_anterieur"],ennemis_restant[i]["vie"])
			if prochaine_action[0]=="mouvement":
				if time.time() - ennemis_restant[i]["temps_Daction"]>=0.4:
					ennemis_restant[i]["temps_Daction"]=time.time()
					ennemis_restant[i]=mouvement_ennemis_programee(ennemis_restant[i],prochaine_action[1],i)
					surcharge=0
			elif prochaine_action[0]=="attaque":
				if time.time() - ennemis_restant[i]["temps_Daction"]>=0.4:
					ennemis_restant[i]["temps_Daction"]=time.time()
					ennemis_restant[i]=attaque_ennemis(ennemis_restant[i],prochaine_action[1],i)
	if nb_mort<len(ennemis_restant):
		current_canvas.after(200, comportement_ennemis_cible)
	else:
		nb_mort=0

def mouvement_ennemis_programee(ennemi,sens,numero):
	"""fait déplacer les ennemis selon un panel de mouvement limitée"""
	global ennemi_restant,affichage_ennemi_restant,orc_massue,cinematic
	if cinematic==False:
		if ennemi["positionY"] == 400:
			ennemi["mvt_anterieur"]="haut"
		elif ennemi["positionY"] == 100:
			ennemi["mvt_anterieur"]="bas"
		if ennemi["mvt_anterieur"]=="bas":
			ennemi["image"]=orc_massue[1]
			current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
			current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"]+50)
			Mafenetre.update()
			can1.after(100)
			ennemi["positionY"]+=100
			ennemi["image"]=orc_massue[0]
			current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
			Mafenetre.update()
			current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
		else:
			ennemi["image"]=orc_massue[3]
			current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
			current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"]-50)
			Mafenetre.update()
			can1.after(100)
			ennemi["positionY"]-=100
			ennemi["image"]=orc_massue[2]
			current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
			Mafenetre.update()
			current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
			ennemi["mvt_anterieur"]="haut"
		return(ennemi)

def mort_ennemis(ennemi,numero):
	"""vérifie que l'ennemi rentré en argument n'a pas été tué"""
	global affichage_ennemi_restant,ennemis_restant,porte,nb_mort,image_boss,faible,ennemi4
	if ennemi["vie"]<=0:
		if ennemi["type"]=="orc_arc":
			current_canvas.itemconfig(ennemi["cible"],image=invisible)
			Mafenetre.update()
		ennemi["type"]="rien"
		current_canvas.itemconfig(affichage_ennemi_restant[numero],image=invisible)
		ennemi["positionX"]=2000
		ennemi["positionY"]=2000
		nb_mort+=1
	if current_level=="niveau2":
		if nb_mort==2:
			current_canvas.create_image(1000,200,image=porte_droite_ouverte,anchor="nw")
			porte=True		
	if current_level=="niveau5":
		if nb_mort==2 and ennemi4==None:
			current_canvas.itemconfig(image_boss,image=orc_boss_cible)
			faible=True
		elif nb_mort==2:
			current_canvas.itemconfig(image_boss,image=orc_boss_cible2)
			faible=True			

def attaque_ennemis(ennemi,sens,numero):
	"""fait attaquer les ennemis en fonction de leur type"""
	global vie,affichage_ennemi_restant,perso,posX,posY,cible_actuelle,cinematic
	if cinematic==False:
		if ennemi["type"]=="orc_massue":
			if sens!=ennemi["orientation"]:
				ennemi["prepare_attaque"]=0
			if sens=="haut":
				ennemi["image"]=orc_massue[2]
				ennemi["orientation"]="haut"
			elif sens=="bas":
				ennemi["image"]=orc_massue[0]
				ennemi["orientation"]="bas"
			elif sens=="droite":
				ennemi["image"]=orc_massue[4]
				ennemi["orientation"]="droite"
			elif sens=="gauche":
				ennemi["image"]=orc_massue[6]
				ennemi["orientation"]="gauche"
			if ennemi["vie"]>0:	
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
			Mafenetre.update()
			if ennemi["mvt_anterieur"]=="attaque":
				ennemi["prepare_attaque"]+=1
			else:
				ennemi["prepare_attaque"]=2
			if ennemi["prepare_attaque"]==3:
				if sens=="haut":
					ennemi["image"]=orc_massue[10]
					ennemi["ancre"]="center"
				elif sens=="bas":
					ennemi["image"]=orc_massue[11]
					ennemi["ancre"]="nw"
				elif sens=="droite":
					ennemi["image"]=orc_massue[9]
					ennemi["ancre"]="nw"
				elif sens=="gauche":
					ennemi["image"]=orc_massue[8]
					ennemi["ancre"]="ne"
				if ennemi["vie"]>0:
					current_canvas.lift(affichage_ennemi_restant[numero])
					current_canvas.itemconfig(affichage_ennemi_restant[numero], image=ennemi["image"],anchor=ennemi["ancre"])
				ennemi["ancre"]="nw"
				Mafenetre.update()
				validation=action_ennemi(ennemi["positionX"],ennemi["positionY"],ennemi["mvt_anterieur"],ennemi["vie"])
				if validation[0]=="attaque" and validation[1]==sens:
					vie-=1
					blessure("ennemi",None,False)
				ennemi["prepare_attaque"]=0
			ennemi["mvt_anterieur"]="attaque"
		elif ennemi["type"]=="orc_arc":
			if ennemi["prepare_attaque"]==0:
				for j in range(1,4):
					can1.after(200)
					if sens!=ennemi["orientation"]:
						ennemi["prepare_attaque"]=0
						current_canvas.itemconfig(ennemi["cible"],image=invisible)
						Mafenetre.update()
						ennemi["orientation"]=sens
						return(ennemi)
					if sens=="haut":
						ennemi["image"]=orc_arc[16+j]
						ennemi["orientation"]="haut"
					elif sens=="bas":
						ennemi["image"]=orc_arc[13+j]
						ennemi["orientation"]="bas"
					elif sens=="droite":
						ennemi["image"]=orc_arc[10+j]
						ennemi["orientation"]="droite"
					elif sens=="gauche":
						ennemi["image"]=orc_arc[7+j]
						ennemi["orientation"]="gauche"
					if cinematic==False and ennemi["vie"]>0:
						current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
						Mafenetre.update()
					if j == 1 and cinematic==False:
						ennemi["cibleX"]=posX
						ennemi["cibleY"]=posY
						ennemi["cible"]=current_canvas.create_image(posX,posY,image=cible,anchor="nw")
						Mafenetre.update()
						current_canvas.lift(perso)
			ennemi["prepare_attaque"]+=1
			if ennemi["prepare_attaque"]==4:
				current_canvas.itemconfig(ennemi["cible"],image=cible2)
				Mafenetre.update()
				if ennemi["cibleX"]==posX and ennemi["cibleY"]==posY:
					vie-=1
					blessure("ennemi",None,False)
				current_canvas.itemconfig(ennemi["cible"],image=invisible)
				Mafenetre.update()
				ennemi["prepare_attaque"]=0
		return(ennemi)

def mouvement_ennemis(ennemi,sens,numero):
	"""fait bouger les ennemis en fonction du sens donné en entrée"""
	global ennemi_restant,affichage_ennemi_restant,surcharge,cinematic
	stop=0
	colonne=ennemi["positionX"]//100
	ligne=ennemi["positionY"]//100
	if cinematic==False:
		if sens=="bas" and matrice[ligne+1][colonne] in possible and not(matrice[ligne+1][colonne] in dangereux):
			for i in range (len(ennemis_restant)):
				if ennemi["positionX"] == ennemis_restant[i]["positionX"] and ennemi["positionY"]+100 == ennemis_restant[i]["positionY"]:
					stop="droite"
			if stop==0:
				ennemi["image"]=orc_massue[1]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"]+50)
				Mafenetre.update()
				can1.after(100)
				ennemi["positionY"]+=100
				ennemi["image"]=orc_massue[0]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				Mafenetre.update()
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
				ennemi["mvt_anterieur"]="bas"
	
		elif sens=="droite" and matrice[ligne][colonne+1] in possible and not(matrice[ligne][colonne+1] in dangereux):
			for i in range (len(ennemis_restant)):
				if ennemi["positionX"]+100 == ennemis_restant[i]["positionX"] and ennemi["positionY"] == ennemis_restant[i]["positionY"]:
					stop="haut"
			if stop==0:
				ennemi["image"]=orc_massue[5]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"]+50,ennemi["positionY"])
				Mafenetre.update()
				can1.after(100)
				ennemi["positionX"]+=100
				ennemi["image"]=orc_massue[4]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				Mafenetre.update()
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
				ennemi["mvt_anterieur"]="droite"
	
		elif sens=="gauche" and matrice[ligne][colonne-1] in possible and not(matrice[ligne][colonne-1] in dangereux):
			for i in range (len(ennemis_restant)):
				if ennemi["positionX"]-100 == ennemis_restant[i]["positionX"] and ennemi["positionY"] == ennemis_restant[i]["positionY"]:
					stop="bas"
			if stop==0:
				ennemi["image"]=orc_massue[7]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"]-50,ennemi["positionY"])
				Mafenetre.update()
				can1.after(100)
				ennemi["positionX"]-=100
				ennemi["image"]=orc_massue[6]
				current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
				Mafenetre.update()
				current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
				ennemi["mvt_anterieur"]="gauche"
	
		elif sens=="haut" and matrice[ligne-1][colonne] in possible and not(matrice[ligne-1][colonne] in dangereux):
			if ennemi["positionY"]-100 >= 0:
				for i in range (len(ennemis_restant)):
					if ennemi["positionX"] == ennemis_restant[i]["positionX"] and ennemi["positionY"]-100 == ennemis_restant[i]["positionY"]:
						stop="gauche"
				if stop==0:
					ennemi["image"]=orc_massue[3]
					current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
					current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"]-50)
					Mafenetre.update()
					can1.after(100)
					ennemi["positionY"]-=100
					ennemi["image"]=orc_massue[2]
					current_canvas.itemconfig(affichage_ennemi_restant[numero],image=ennemi["image"],anchor=ennemi["ancre"])
					Mafenetre.update()
					current_canvas.coords(affichage_ennemi_restant[numero],ennemi["positionX"],ennemi["positionY"])
					ennemi["mvt_anterieur"]="haut"
	
		elif sens=="gauche" and stop == 0:
			stop="bas"
		elif sens=="bas" and stop == 0:
			stop="droite"
		elif sens=="droite" and stop == 0:
			stop="haut"
		elif sens=="haut" and stop == 0:
			stop="gauche"
		if surcharge<100:
			if stop != 0:
				surcharge+=1
				ennemi=mouvement_ennemis(ennemi,stop,numero)
		return(ennemi)

#PROGRAMME PRINCIPAL-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------PROGRAMME PRINCIPAL
initialisation_depart()
ecran_titre()
can0.bind('<Key>',clavier)
Mafenetre.protocol("WM_DELETE_WINDOW",exit())
Mafenetre.mainloop()
