# -*- coding: utf-8 -*-
from tkinter import *

Mafenetre=Tk()
Mafenetre.title('START')
Mafenetre.geometry('800x800')
#zone de dessin

can0=Canvas(Mafenetre,bg="white",width=800,height=900)
can0.place(x=0,y=0)



#creation des cases images
casecerisier=PhotoImage(file="cerisier.gif")
casesolj=PhotoImage(file="soljapon.gif")
casesoljG=PhotoImage(file="soljaponG.gif")
casesoljD=PhotoImage(file="soljaponD.gif")
casesoljH=PhotoImage(file="soljaponH.gif")
casesoljB=PhotoImage(file="soljaponB.gif")
casesoljY=PhotoImage(file="soljaponY.gif")
casesolejaponchatg=PhotoImage(file="soljaponchatg.gif")
casesolejaponchatd=PhotoImage(file="soljaponchatd.gif")
caseeau=PhotoImage(file="eau.gif")
caseeaupoisson=PhotoImage(file="eaupoisson.gif")
caseaeroNO=PhotoImage(file="aeroport NO.gif")
caseaeroNE=PhotoImage(file="aeroport NE.gif")
caseaeroSO=PhotoImage(file="aeroport SO.gif")
caseaeroSE=PhotoImage(file="aeroport SE.gif")
casemaisonhkNO=PhotoImage(file="maisonhk NO.gif")
casemaisonhkNE=PhotoImage(file="maisonhk NE.gif")
casemaisonhkSO=PhotoImage(file="maisonhk SO.gif")
casemaisonhkSE=PhotoImage(file="maisonhk SE.gif")
casemaisonNO=PhotoImage(file="maisonNO.gif")
casemaisonNE=PhotoImage(file="maisonNE.gif")
casemaisonSO=PhotoImage(file="maisonSO.gif")
casemaisonSE=PhotoImage(file="maisonSE.gif")
casepagodeNO=PhotoImage(file="pagodeNO.gif")
casepagodeNE=PhotoImage(file="pagodeNE.gif")
casepagodeSO=PhotoImage(file="pagodeSO.gif")
casepagodeSE=PhotoImage(file="pagodeSE.gif")
casesushiNO=PhotoImage(file="sushiNO.gif")
casesushiNE=PhotoImage(file="sushiNE.gif")
casesushiSO=PhotoImage(file="sushiSO.gif")
casesushiSE=PhotoImage(file="sushiSE.gif")
casepagodejNO=PhotoImage(file="pagodejNO.gif")
casepagodejNE=PhotoImage(file="pagodejNE.gif")
casepagodejSO=PhotoImage(file="pagodejSO.gif")
casepagodejSE=PhotoImage(file="pagodejSE.gif")
caseyoshi=PhotoImage(file="yoshi2.gif")
caseherbe=PhotoImage(file="herbe.gif")
persoD1=PhotoImage(file="bonhommeD1.gif")
persoD2=PhotoImage(file="bonhommeD2.gif")
persoD3=PhotoImage(file="bonhommeD3.gif")
persoG1=PhotoImage(file="bonhommeG1.gif")
persoG2=PhotoImage(file="bonhommeG2.gif")
persoG3=PhotoImage(file="bonhommeG3.gif")
persoH1=PhotoImage(file="bonhommeH1.gif")
persoH2=PhotoImage(file="bonhommeH2.gif")
persoB1=PhotoImage(file="bonhommeB1.gif")
persoB2=PhotoImage(file="bonhommeB2.gif")
caseeau=PhotoImage(file="eau.gif")
caseparquet=PhotoImage(file="parquet.gif")
caseparquetp=PhotoImage(file="parquetp.gif")
casemur=PhotoImage(file="mur.gif")
casefenetreh=PhotoImage(file="fenetreh.gif")
casefenetreb=PhotoImage(file="fenetreb.gif")
casechatNO=PhotoImage(file="chatNO.gif")
casechatNE=PhotoImage(file="chatNE.gif")
casechatSO=PhotoImage(file="chatSO.gif")
casechatSE=PhotoImage(file="chatSE.gif")
caselith=PhotoImage(file="lith.gif")
caselitb=PhotoImage(file="litb.gif")
casetableNO=PhotoImage(file="tableNO.gif")
casetableNE=PhotoImage(file="tableNE.gif")
casetableSO=PhotoImage(file="tableSO.gif")
casetableSE=PhotoImage(file="tableSE.gif")
casemaisonsparisNO=PhotoImage(file="maisonparisNO.gif")
casemaisonsparisNE=PhotoImage(file="maisonparisNE.gif")
casemaisonsparisSO=PhotoImage(file="maisonparisSO.gif")
casemaisonsparisSE=PhotoImage(file="maisonparisSE.gif")
casemaisonsparisjNO=PhotoImage(file="maisonparisjNO.gif")
casemaisonsparisjNE=PhotoImage(file="maisonparisjNE.gif")
casemaisonsparisjSO=PhotoImage(file="maisonparisjSO.gif")
casemaisonsparisjSE=PhotoImage(file="maisonparisjSE.gif")
caseparisien=PhotoImage(file="parisien.gif")
casesolparis=PhotoImage(file="solparis.gif")
casesolparisG=PhotoImage(file="solparisG.gif")
casesolparisD=PhotoImage(file="solparisD.gif")
casesolparisH=PhotoImage(file="solparisH.gif")
casesolparisB=PhotoImage(file="solparisB.gif")
casesolparisP=PhotoImage(file="solparisP.gif")
casetourNE=PhotoImage(file="tourNE.gif")
casetourNO=PhotoImage(file="tourNO.gif")
casetourSE=PhotoImage(file="tourSE.gif")
casetourSO=PhotoImage(file="tourSO.gif")
casefleur1=PhotoImage(file="fleur1.gif")
casefleur2=PhotoImage(file="fleur2.gif")
casefleur3=PhotoImage(file="fleur3.gif")
casefleur4=PhotoImage(file="fleur4.gif")
casefleur4exit=PhotoImage(file="fleur4.gif")
casefleur2exit=PhotoImage(file="fleur2.gif")
casefleur1exit=PhotoImage(file="fleur1.gif")
caseaerofNO=PhotoImage(file="aeroportfNO.gif")
caseaeroNE=PhotoImage(file="aeroport NE.gif")
caseaeroSO=PhotoImage(file="aeroport SO.gif")
caseaeroSE=PhotoImage(file="aeroport SE.gif")
caseeau=PhotoImage(file="eau.gif")
caseeaupoisson=PhotoImage(file="eaupoisson.gif")
caselocoNO=PhotoImage(file="locomotiveNO.gif")
caselocoN=PhotoImage(file="locomotiveN.gif")
caselocoNE=PhotoImage(file="locomotiveNE.gif")
caselocoSO=PhotoImage(file="locomotiveSO.gif")
caselocoS=PhotoImage(file="locomotiveS.gif")
caselocoSE=PhotoImage(file="locomotiveSE.gif")
image_objet1=PhotoImage(file="parchemin.gif")
casenoir=PhotoImage(file="noir.gif")
casenoir2=PhotoImage(file="noir2.gif")
casenoirexit=PhotoImage(file="noirexit.gif")
avion=PhotoImage("file=avion.gif")
casecp1=PhotoImage(file="cp1.gif")
casecp2=PhotoImage(file="cp2.gif")
casecp3=PhotoImage(file="cp3.gif")
casecp4=PhotoImage(file="cp4.gif")
casecp5=PhotoImage(file="cp5.gif")
casecp6=PhotoImage(file="cp6.gif")
casecp7=PhotoImage(file="cp7.gif")
casecp8=PhotoImage(file="cp8.gif")
casee1=PhotoImage(file="e1.gif")
casee2=PhotoImage(file="e2.gif")
casee3=PhotoImage(file="e3.gif")
casee4=PhotoImage(file="e4.gif")
casee5=PhotoImage(file="e5.gif")
casee6=PhotoImage(file="e6.gif")
casesl1=PhotoImage(file="sl1.gif")
casesl2=PhotoImage(file="sl2.gif")
casesl3=PhotoImage(file="sl3.gif")
casesl4=PhotoImage(file="sl4.gif")
casesl5=PhotoImage(file="sl5.gif")
casesl6=PhotoImage(file="sl6.gif")
casesl7=PhotoImage(file="sl7.gif")
casesl8=PhotoImage(file="sl8.gif")
casesl9=PhotoImage(file="sl9.gif")
casesl10=PhotoImage(file="sl10.gif")
casesolusa=PhotoImage(file="sulusa.gif")
casetaxi1=PhotoImage(file="taxi1.gif")
casetaxi2=PhotoImage(file="taxi2.gif")
casetaxi3=PhotoImage(file="taxi3.gif")
casetaxi4=PhotoImage(file="taxi4.gif")
pngtrump=PhotoImage(file="trump.gif")
caseb1=PhotoImage(file="b1.gif")
caseb2=PhotoImage(file="b2.gif")
caseb3=PhotoImage(file="b4.gif")
caseb4=PhotoImage(file="b5.gif")
aerousa1=PhotoImage(file="aerousa1.gif")
aerousa2=PhotoImage(file="aerousa2.gif")
aerousa3=PhotoImage(file="aerousa3.gif")
aerousa4=PhotoImage(file="aerousa4.gif")
caseherbe2=PhotoImage(file="herbe2.gif")
arbreus=PhotoImage(file="arbreusa.gif")
caseinv1=PhotoImage(file="inv1.gif")
caseinv2=PhotoImage(file="inv2.gif")
caseinv3=PhotoImage(file="inv3.gif")
caseinv4=PhotoImage(file="inv4.gif")
caseinv5=PhotoImage(file="inv5.gif")
caseinv6=PhotoImage(file="inv6.gif")
caseinv7=PhotoImage(file="inv7.gif")
caseinv8=PhotoImage(file="inv8.gif")
casearbreusa=PhotoImage(file="arbreusa.gif")
casemessage1=PhotoImage(file="message1.gif")
casemessage2=PhotoImage(file="message2.gif")
caseblanc=PhotoImage(file="blanc.gif")
objetcroissant=PhotoImage(file="croissant.gif")
objetparchemin=PhotoImage(file="parchemin2.gif")
objethotdog=PhotoImage(file="hotdog.gif")
casenoir=PhotoImage(file="noir.gif")
casenoirexit=PhotoImage(file="noirexit.gif")
casenoirexit2=PhotoImage(file="noirexit2.gif")
avion=PhotoImage(file="avion.gif")
caseaeroregleNO=PhotoImage(file="aerorNO.gif")
caseaeroregleNE=PhotoImage(file="aerorNE.gif")
caseaeroregleSO=PhotoImage(file="aerorSO.gif")
caseaeroregleSE=PhotoImage(file="aerorSE.gif")
caseporteNO=PhotoImage(file="porteNO.gif")
caseporteNE=PhotoImage(file="porteNE.gif")
caseporteSO=PhotoImage(file="porteSO.gif")
caseporteSE=PhotoImage(file="porteSE.gif")
casesolfinal=PhotoImage(file="solfinal.gif")
casefinal1=PhotoImage(file="solfinal.gif")
casefinal2=PhotoImage(file="solfinal.gif")
casefinal3=PhotoImage(file="solfinal.gif")
casetapis=PhotoImage(file="tapis.gif")
casetapis2=PhotoImage(file="tapis2.gif")
casetapis5=PhotoImage(file="tapis5.gif")
caseflecheh=PhotoImage(file="flecheh.gif")
caseflecheg=PhotoImage(file="flecheg.gif")
casefleched=PhotoImage(file="fleched.gif")
aerofinalNO=PhotoImage(file="aerofinalNO.gif")
aerofinalNE=PhotoImage(file="aerofinalNE.gif")
aerofinalSO=PhotoImage(file="aerofinalSO.gif")
aerofinalSE=PhotoImage(file="aerofinalSE.gif")
yoshiperso1=PhotoImage(file="yoshiperso.gif")
parisienperso2=PhotoImage(file="parisienperso.gif")
trumpperso3=PhotoImage(file="trumpperso.gif")
backgroundfinal=PhotoImage(file="bgfinal.gif")
caseflechebleu=PhotoImage(file="flechbleu.gif")
tab_droite=[persoD3,persoD2,persoD1]
tab_gauche=[persoG3,persoG1,persoG2]
tab_haut=[persoH1,persoH2]
tab_bas=[persoB1,persoB2]
compteur_de_pas=0

#creation de la matrice
L0=["ANO","ANE","SH","T","T","T","T","T","PNO","PNE","JNO","JNE","PNO","PNE","JNO","JNE"]
L1=["ASO","ASE","SB","T","T","T","T","T","PSO","PSE","JSO","JSE","PSO","PSE","JSO","JSE"]
L2=["C","C","C","C","C","C","T","T","C","E","E","E","E","E","PO","E"]
L3=["C","C","C","C","C","C","T","T","C","C","C","C","C","C","C","E"]
L4=["T","T","T","T","T","T","T","T","T","T","T","T","T","T","C","H"]
L5=["T","T","T","T","T","T","T","T","SG","SD","T","T","T","T","C","H"]
L6=["T","T","C","C","C","C","T","SY","SNO","SNE","C","C","T","T","C","H"]
L7=["T","T","C","JNO","JNE","C","T","T","SSO","SSE","C","C","T","T","C","H"]
L8=["T","T","C","JSO","JSE","C","T","T","C","C","C","C","SG","SD","C","H"]
L9=["T","SY","Y","C","C","C","T","T","C","PNO","PNE","C","MNO","MNE","C","H"]
L10=["C","C","C","C","C","C","T","T","C","PSO","PSE","C","MSO","MSE","C","H"]
L11=["H","H","H","H","H","H","T","T","C","C","C","C","C","C","C","H"]
L12=["H","E","E","E","E","H","T","T","T","T","T","T","C","E","C","H"]
L13=["H","E","E","E","PO","H","T","T","T","T","SG","SD","C","PO","C","H"]
L14=["H","H","H","H","H","H","C","C","C","C","HNO","HNE","C","E","C","H",]
L15=["C","C","C","C","C","C","C","C","C","C","HSO","HSE","C","C","C","H",]
L16=["MESS1","MESS2","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I1","I2","I3","I4"]
L17=["BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I5","I6","I7","I8"]

L0P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L1P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L2P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L3P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L4P=["N2","N2","N2","M","M","FH1","M","FH1","FH1","M","FH1","M","M","N2","N2","N2"]
L5P=["N2","N2","N2","M","M","FB","M","FB","FB","M","FB","M","M","N2","N2","N2"]
L6P=["N2","N2","N2","PA","LH","LH","PA","PA","PA","PA","CNO","CNE","PA","N2","N2","N2"]
L7P=["N2","N2","N2","PA","LB","LB","PA","PA","PA","PA","CSO","CSE","PA","N2","N2","N2"]
L8P=["N2","N2","N2","PA","PA","PA","PA","PA","PA","PA","SJCG","SJCD","PA","N2","N2","N2"]
L9P=["N2","N2","N2","PA","PA","TTNO","TTNE","PA","PA","PA","PA","PA","PA","N2","N2","N2"]
L10P=["N2","N2","N2","PA","PA","TTSO","TTSE","PA","PA","PA","PA","PA","PA","N2","N2","N2"]
L11P=["N2","N2","NE2","PAP","PA","PA","PA","PA","PA","PA","PA","PA","PA","N2","N2","N2"]
L12P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L13P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L14P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L15P=["N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2","N2"]
L16P=["MESS1","MESS2","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I1","I2","I3","I4"]
L17P=["BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I5","I6","I7","I8"]

L0F=["F1","F2","F3","F4","F1","F2","F3","F4","F1","F2","F3","F4","F1","TNO","TNE","F2"]
L1F=["F4","F3","F2","F1","F4","F3","F2","F1","F2","F3","F4","F1","F4","TSO","TSE","F3"]
L2F=["AFNO","ANE","SPH","SP","SP","SP","SP","SP","SP","SP","SP","SP","SP","SPG","SPD","F4"]
L3F=["ASO","ASE","SPB","SP","SP","SP","SP","SP","SP","SP","SP","SP","SP","SP","SP","F1"]
L4F=["F1","F2","F3","F4","F1","SP","SP","F4","F1","LNO","LN","LNE","F1","F2","F3","F4"]
L5F=["E","E","E","E","F4","SP","SP","F1","F4","LSO","LS","LSE","F4","F3","F2","F1"]
L6F=["E","E","PO","E","F1","SP","SP","F4","F1","E","PO","E","F1","F2","F3","F4"]
L7F=["E","PO","E","E","E","SP","SP","E","E","E","E","E","F2","F3","F4","F1"]
L8F=["F1","F2","F3","F4","F1","SP","SP","SP","SPP","P","F1","E","F3","MPNO","MPNE","F2"]
L9F=["F4","F3","MPNO","MPNE","F2","SP","SP","F1","F2","F1","F2","E","F2","MPSO","MPJSE","F3"]
L10F=["F4","F3","MPSO","MPJSE","F2","SP","SP","F4","F3","MPJNO","MPJNE","E","E","F2","F3","F4"]
L11F=["F1","F2","SPG","SPD","SP","SP","SP","F4","F1","MPJSO","MPJSE","E","E","F1","F2","F3"]
L12F=["F1","F2","F3","F4","F1","SP","SP","SP","SP","SPG","SPD","F4","E","E","E","E"]
L13F=["F4","MPJNO","MPJNE","F1","F4","SP","SP","SP","SP","SP","SP","F1","F4","PO","E","E"]
L14F=["F1","MPJSO","MPJSE","F4","F1","SP","SP","F2","F3","F4","F1","F4","F1","E","PO","E"]
L15F=["F4","F3","F2E","F1E","F4E","SP","SP","F1","F4","F3","F2","F1","F4","F3","F2","F1"]
L16F=["MESS1","MESS2","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I1","I2","I3","I4"]
L17F=["BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I5","I6","I7","I8"]

L0A=["E","SL2","SL1","SL2","SL2","SUSA","SUSA","B1","B2","SL2","SL2","SL2","CP1","CP2","CP3","CP4"]
L1A=["E","SL2","SL3","SL4","SL2","SUSA","SUSA","B3","B4","SL2","SL2","SL2","CP5","CP6","CP7","CP8"]
L2A=["E","SL2","SL5","SL6","SL2","SUSA","SUSA","SL2","SL2","SL2","SL2","SL2","SL2","SUSA","SUSA","SL2"]
L3A=["E","SL2","SL7","SL8","SL2","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SL2"]
L4A=["E","SL2","SL9","SL10","SL2","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SL2"]
L5A=["E","SL2","SUSA","SUSA","SL2","SUSA","SUSA","AU","AU","AU","B1","B2","AU","AU","AU","SL2"]
L6A=["E","SL2","SUSA","SUSA","SL2","SUSA","SUSA","AU","AU","AU","B3","B4","AU","AU","AU","SL2"]
L7A=["E","SL2","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA"]
L8A=["E","SL2","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA","SUSA"]
L9A=["E","SL2","SL2","SL2","AU","SUSA","SUSA","B1","B2","B1","B1","B1","B2","B1","B2","SUSA","SUSA"]
L10A=["E","SL2","E1","E2","AU","SUSA","SUSA","B3","B4","B3","B4","B3","B4","B3","B4","SUSA","SUSA"]
L11A=["E","SL2","E3","E4","SUSA","SUSA","SUSA","SL2","SL2","SL2","SL2","T1","SL2E","SUSA","SUSA","SUSA"]
L12A=["E","SL2","E5","E6","SUSA","SUSA","SUSA","SUSA","TR","SL2","T2","T3","T4","SUSA","SUSA","SUSA"]
L13A=["E","SL2","SL2","AU","AU","SUSA","SUSA","SL2","SL2","SL2","SL2","SL2","SL2","SL2","SL2","SL2"]
L14A=["E","AU1","AU2","SUSA","SUSA","SUSA","SUSA","SL2","B1","B2","B1","B2","B1","B2","B1","B2","B1","B2"]
L15A=["E","AU3","AU4","SUSA","SUSA","SUSA","SUSA","SL2","B3","B4","B3","B4","B3","B4","B3","B4","B3","B4"]
L16A=["MESS1","MESS2","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I1","I2","I3","I4"]
L17A=["BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I5","I6","I7","I8"]

L0R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L1R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L2R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L3R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L4R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L5R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L6R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L7R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L8R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L9R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L10R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L11R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L12R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L13R=["NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE","NE"]
L14R=["N","N","N","N","N","N","N","N","N","N","N","N","N","N","AERNO","AERNE"]
L15R=["NE","FLB","NE","NE","FLB","NE","NE","FLB","NE","NE","FLB","NE","NE","FLB","AERSO","AERSE"]

L0E=["PONO","PONE","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L1E=["POSO","POSE","SF","FG","SF","SF","FG","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L2E=["TE","TE","TE","T5","TE","CT2","TE","TE","TE","FH","TE","CT2","TE","TE","TE","CT2"]
L3E=["TE","CT2","TE","TE","T5","TE","TE","T5","TE","FINAL3","TE","CT2","T5","TE","TE","CT2"]
L4E=["SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L5E=["SF","SF","SF","SF","SF","FD","SF","SF","SF","FH","SF","SF","SF","SF","SF","SF"]
L6E=["SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L7E=["TE","CT2","TE","TE","FH","TE","TE","TE","T5","TE","TE","CT2","T5","TE","TE","CT2"]
L8E=["TE","TE","TE","T5","FINAL2","TE","CT2","TE","TE","TE","TE","T5","TE","TE","TE","TE"]
L9E=["SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L10E=["SF","SF","SF","SF","FH","SF","FG","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L11E=["SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L12E=["T5","TE","TE","CT2","TE","TE","FH","TE","T5","TE","TE","TE","CT2","T5","TE","TE"]
L13E=["TE","CT2","TE","TE","T5","TE","FINAL1","TE","TE","CT2","TE","TE","T5","TE","TE","TE"]
L14E=["AEFNO","AEFNE","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L15E=["AEFSO","AEFSE","SF","SF","FD","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF","SF"]
L16E=["MESS1","MESS2","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I1","I2","I3","I4"]
L17E=["BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","BL","I5","I6","I7","I8"]
japon=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17]
france=[L0F,L1F,L2F,L3F,L4F,L5F,L6F,L7F,L8F,L9F,L10F,L11F,L12F,L13F,L14F,L15F,L16F,L17F]
maison_interior=[L0P,L1P,L2P,L3P,L4P,L5P,L6P,L7P,L8P,L9P,L10P,L11P,L12P,L13P,L14P,L15P,L16P,L17P]
amerique=[L0A,L1A,L2A,L3A,L4A,L5A,L6A,L7A,L8A,L9A,L10A,L11A,L12A,L13A,L14A,L15A,L16A,L17A]
regle=[L0R,L1R,L2R,L3R,L4R,L5R,L6R,L7R,L8R,L9R,L10R,L11R,L12R,L13R,L14R,L15R]
final=[L0E,L1E,L2E,L3E,L4E,L5E,L6E,L7E,L8E,L9E,L10E,L11E,L12E,L13E,L14E,L15E,L16E,L17E]
#creation de la map
dico={"SG":casesoljG,"SY":casesoljY,"SD":casesoljD,"SH":casesoljH,"SB":casesoljB,"H":caseherbe,"C":casecerisier,"ANO":caseaeroNO,"ANE":caseaeroNE,"ASO":caseaeroSO,"ASE":caseaeroSE,"HNO":casemaisonhkNO,"HNE":casemaisonhkNE,"HSO":casemaisonhkSO,
"SNO":casesushiNO,"SNE":casesushiNE,"SSO":casesushiSO,"SSE":casesushiSE,"PNO":casepagodeNO,"PNE":casepagodeNE,"PSO":casepagodeSO,"PSE":casepagodeSE,
"MNO":casemaisonNO,"MNE":casemaisonNE,"MSO":casemaisonSO,"MSE":casemaisonSE,"HSE":casemaisonhkSE,"T":casesolj,"E":caseeau,"PO":caseeaupoisson,
"JNO":casepagodejNO,"JNE":casepagodejNE,"JSO":casepagodejSO,"JSE":casepagodejSE,"Y":caseyoshi,"PA":caseparquet,"PAP":caseparquetp,"M":casemur,"FH1":casefenetreh,"FB":casefenetreb,
"CNO":casechatNO,"CNE":casechatNE,"CSO":casechatSO,"CSE":casechatSE,"LH":caselith,"LB":caselitb,"TTNO":casetableNO,"TTNE":casetableNE,"TTSO":casetableSO,"TTSE":casetableSE,"MPNO":casemaisonsparisNO,"MPNE":casemaisonsparisNE,"MPSO":casemaisonsparisSO,"MPSE":casemaisonsparisSE,"F1":casefleur1
,"E":caseeau,"PO":caseeaupoisson,"F2":casefleur2,"F3":casefleur3,"F4":casefleur4,"MPJNO":casemaisonsparisjNO,"MPJNE":casemaisonsparisjNE,"MPJSO":casemaisonsparisjSO,"MPJSE":casemaisonsparisjSE,
"P":caseparisien,"SP":casesolparis,"SPG":casesolparisG,"SPD":casesolparisD,"SPH":casesolparisH,"SPB":casesolparisB,"SPP":casesolparisP,"TNO":casetourNO,"TNE":casetourNE,"TSO":casetourSO,"TSE":casetourSE,
"AFNO":caseaerofNO,"ANE":caseaeroNE,"ASO":caseaeroSO,"ASE":caseaeroSE,"LNO":caselocoNO,"LN":caselocoN,"LNE":caselocoNE,"LSO":caselocoSO,"LS":caselocoS,"LSE":caselocoSE,"N":casenoir,"NE":casenoirexit
,"CP1":casecp1,"CP2":casecp2,"CP3":casecp3,"CP4":casecp4,"CP5":casecp5,"CP6":casecp6,"CP7":casecp7,"CP8":casecp8,"E1":casee1,"E2":casee2,"E3":casee3,"E4":casee4,"E5":casee5,"E6":casee6,
"SL1":casesl1,"SL2":casesl2,"SL2E":casesl2,"SL3":casesl3,"SL4":casesl4,"SL5":casesl5,"SL6":casesl6,"SL7":casesl7,"SL8":casesl8,"SL9":casesl9,"SL10":casesl10,"SUSA":casesolusa,"T1":casetaxi1,"T2":casetaxi2,"T3":casetaxi3,"T4":casetaxi4,
"TR":pngtrump,"B1":caseb1,"B2":caseb2,"B3":caseb3,"B4":caseb4,"AU1":aerousa1,"AU2":aerousa2,"AU3":aerousa3,"AU4":aerousa4,"H2":caseherbe2,"F1E":casefleur1exit,"F2E":casefleur2exit,"F4E":casefleur4exit,
"I1":caseinv1,"I2":caseinv2,"I3":caseinv3,"I4":caseinv4,"I5":caseinv5,"I6":caseinv6,"I7":caseinv7,"I8":caseinv8,"MESS1":casemessage1,"MESS2":casemessage2,"BL":caseblanc,"SJCG":casesolejaponchatg,"SJCD":casesolejaponchatd,"AU":casearbreusa,"N":casenoir,"N2":casenoir2,"NE":casenoirexit,"NE2":casenoirexit2,
"AERNO":caseaeroregleNO,"AERNE":caseaeroregleNE,"AERSO":caseaeroregleSO,"AERSE":caseaeroregleSE,
"PONO":caseporteNO,"PONE":caseporteNE,"POSO":caseporteSO,"POSE":caseporteSE,"SF":casesolfinal,"TE":casetapis,"CT2":casetapis2,"T5":casetapis5,"FH":caseflecheh,"FD":casefleched,"FG":caseflecheg,
"AEFSE":aerofinalSE,"AEFNO":aerofinalNO,"AEFNE":aerofinalNE,"AEFSO":aerofinalSO,"FINAL1":casefinal1,"FINAL2":casefinal2,"FINAL3":casefinal3,"FLB":caseflechebleu}




can1=Canvas(Mafenetre,bg="white",width=800,height=900)
for i in range(18):
        for j in range(16):
            can1.create_image(50*j,50*i,image=dico[japon[i][j]],anchor="nw")


can2=Canvas(Mafenetre,bg="white",width=800,height=900)
for i in range(18):
        for j in range(16):
            can2.create_image(50*j,50*i,image=dico[maison_interior[i][j]],anchor="nw")

can3=Canvas(Mafenetre,bg="white",width=800,height=900)
for i in range(18):
        for j in range(16):
            can3.create_image(50*j,50*i,image=dico[france[i][j]],anchor="nw")

can4=Canvas(Mafenetre,bg="white",width=800,height=900)
for i in range(18):
        for j in range(16):
            can4.create_image(50*j,50*i,image=dico[amerique[i][j]],anchor="nw")
perso=can1.create_image(100,0,image=persoD2,anchor="nw")

can5=Canvas(Mafenetre,bg="white",width=800,height=800)
for i in range(16):
        for j in range(16):
            can5.create_image(50*j,50*i,image=dico[regle[i][j]],anchor="nw")

can6=Canvas(Mafenetre,bg="white",width=800,height=900)
for i in range(18):
        for j in range(16):
            can6.create_image(50*j,50*i,image=dico[final[i][j]],anchor="nw")

can7=Canvas(Mafenetre,bg="white",width=800,height=800)

compteur_objet1=0
compteur_objet2=0
compteur_objet3=0

def passage1():
    if posX==300 and posY==700:
        can6.itemconfig(texte_pnj,text="")
        L13E[6]="SF"
def passage2():
    if posX==200 and posY==450:
            can6.itemconfig(texte_pnj,text="")
            L8E[4]="SF"
def passage3():
    if posX==450 and posY==200:
        can6.itemconfig(texte_pnj,text="")
        L3E[9]="SF"


def regle_map():
    global perso,posX,posY,compteur_de_pas,dico,can5,numero,niveau
    liste_canvas[numero].delete(perso)
    numero=5
    posX=50
    posY=750
    w2.destroy()
    can0.destroy()

    button5.destroy()
    button4.destroy()
    Mafenetre.geometry('800x800')
    Mafenetre.title('BIENVENUE')
    can5.create_image(550,-50,image=avion,anchor="nw")
    can5.create_image(50,300,image=objetcroissant)
    can5.create_image(65,400,image=objetparchemin)
    can5.create_image(65,500,image=objethotdog)
    can5.pack()
    perso=can5.create_image(50,750,image=persoD2,anchor="nw")

    can5.create_text(370,50,fill='black',font="Times 20 italic bold",text="REGLES")
    can5.create_text(200,200,fill="black",font="Times 14 italic bold",text="Le but est simple"+"\n"+"vous devez récuperer"+"\n"+"trois objets dans trois pays différents"+"\n"+"comme montré ci-dessous")
    can5.create_text(150,310,fill="black",font="Times 14 italic bold",text=": FRANCE")
    can5.create_text(150,410,fill="black",font="Times 14 italic bold",text=": JAPON")
    can5.create_text(165,490,fill="black",font="Times 14 italic bold",text=": AMERIQUE")
    can5.create_text(600,190,fill='black',font="Times 14 italic bold",text="pour vous aider dans cette aventure"+"\n"+"les personnages et les endroits populaires du pays"+"\n"+"vous donneront des indices")
    can5.create_text(550,310,fill="black",font="Times 14 italic bold",text="vous pouvez voyager entre chaque pays"+"\n"+"en passant par l'aéroport"+"\n"+"comme celui en bas à droite de l'écran")
    can5.create_text(590,450,fill="black",font="Times 14 italic bold",text="une fois les trois objets récupérés"+"\n"+"il faudra vous rendre dans BAGGAGE"+"\n"+"qui se situe aussi dans l'aéroport"+"\n"+"pour ainsi donner les trois objets aux personnages"+"\n"+"pour enfin terminer le jeu ")
    can5.create_text(400,600,fill="black",font="Times 14 italic bold",text="maintenant vous n'avez plus qu'à vous rendre à l'aeroport pour choisir par quel pays commencer")
    can5.create_text(360,650,fill="black",font="Times 20 italic bold",text="BON JEU")

    can5.update
    can5.place(x=0,y=0)
    can5.focus_set()
    can5.bind('<Key>',Clavier)

    #zones de texte
    texte_pnj=can5.create_text(350,850,text="",font=("Arial",13),fill="black")

def japon_aero():
    Mafenetre2.destroy()
    japon_map()


def japon_map():
    global perso,posX,posY,compteur_de_pas,dico,can1,Mafenetre,texte_pnj,numero,niveau,can0,can3,Mafenetre2
    liste_canvas[numero].delete(perso)
    numero=1
    posX=100
    posY=0
    can3.place(x=1000,y=1000)
    can4.place(x=1000,y=1000)
    can5.place(x=1000,y=1000)
    can6.place(x=1000,y=1000)
    can2.place(x=1000,y=1000)
    w2.destroy()
    button4.destroy()
    button5.destroy()
    Mafenetre2.destroy()
    Mafenetre.geometry('800x900')
    Mafenetre.title('JAPON')
    can1.place(x=0,y=0)
    perso=can1.create_image(100,0,image=persoD2,anchor="nw")
    texte_pnj=can1.create_text(300,850,text="",font=("Arial",13),fill="black")
    can1.focus_set()
    can1.bind('<Key>',Clavier)

#position du personnage
liste_canvas=[can1,can1,can2,can3,can4,can5,can6]

photo2= PhotoImage(file = "accueil.gif")
w2 = Label(Mafenetre, image=photo2)
w2.pack()
bt4 = PhotoImage(file='demarrer.gif')
button4=Button(Mafenetre,image=bt4,command = regle_map)
button4.pack()
button4.place(x=280, y=200)

bt5 = PhotoImage(file='exit.gif')
button5=Button(Mafenetre,image=bt5,command = Mafenetre.destroy)
button5.pack()
button5.place(x=280, y=600)

def final_final():
    global can7,can6,Mafenetre,bt5,button5
    can6.place(x=1000,y=1000)
    Mafenetre.title('BRAVO')
    Mafenetre.geometry('800x800')
    can7.place(x=0,y=0)
    bg=can7.create_image(0,0,image=backgroundfinal,anchor="nw")

    bt5 = PhotoImage(file='exit2.gif')
    button10=Button(Mafenetre,image=bt5,command = Mafenetre.destroy)
    button10.pack()
    button10.place(x=650, y=700)
    can7.create_text(400,490,fill='black',font="Times 18 italic bold",text="Super tu as fini le jeu"+"\n"+"merci beaucoup d'avoir joué")
    can7.create_text(80,780,fill='black',text="Jeu crée par Max et Margaux")
def maison():
    global perso,posX,posY,compteur_de_pas,dico,can1,Mafenetre,texte_pnj,numero,niveau,can2,can3,objet1
    liste_canvas[numero].delete(perso)
    numero=2
    posX=200
    posY=550
    Mafenetre.geometry('800x900')
    Mafenetre.title('MAISON')
    can2.place(x=0,y=0)
    texte_pnj=can2.create_text(300,850,text="",font=("Arial",13),fill="black")
    perso=can2.create_image(200,550,image=persoD1,anchor="nw")
    can2.focus_set()
    can2.bind('<Key>',Clavier)
    X1=550
    Y1=300
    objet1=can2.create_image(X1,Y1,image=image_objet1,anchor="nw")


def retour():
    global perso,posX,posY,compteur_de_pas,dico,can1,Mafenetre,texte_pnj,numero,niveau
    can2.place(x=1000,y=1000)
    can2.itemconfig(texte_pnj,text="")
    liste_canvas[numero].delete(perso)
    numero=1
    posX=600
    posY=450
    can3.place(x=1000,y=1000)
    can4.place(x=1000,y=1000)
    can5.place(x=1000,y=1000)
    can6.place(x=1000,y=1000)
    can2.place(x=1000,y=1000)
    w2.destroy()
    button4.destroy()
    button5.destroy()
    Mafenetre2.destroy()
    Mafenetre.geometry('800x900')
    Mafenetre.title('JAPON')
    can1.place(x=0,y=0)
    perso=can1.create_image(600,450,image=persoD2,anchor="nw")
    texte_pnj=can1.create_text(300,850,text="",font=("Arial",13),fill="black")
    can1.focus_set()
    can1.bind('<Key>',Clavier)


def france_map():
    global perso,posX,posY,compteur_de_pas,dico,can3,numero,niveau,Mafenetre2,can1,texte_pnj
    liste_canvas[numero].delete(perso)
    numero=3
    posX=100
    posY=100
    Mafenetre2.destroy()
    can1.place(x=1000,y=1000)
    can4.place(x=1000,y=1000)
    can5.place(x=1000,y=1000)
    can6.place(x=1000,y=1000)
    Mafenetre.title('FRANCE')
    Mafenetre.geometry('800x900')
    perso=can3.create_image(100,100,image=persoD2,anchor="nw")
    can3.place(x=0,y=0)
    can3.focus_set()
    can3.bind('<Key>',Clavier)
    texte_pnj=can3.create_text(300,850,text="",font=("Arial",13),fill="black")


def final_map():
    global perso,posX,posY,compteur_de_pas,dico,can3,numero,niveau,Mafenetre2,can6,texte_pnj
    liste_canvas[numero].delete(perso)
    numero=6
    posX=0
    posY=750
    Mafenetre2.destroy()
    can1.place(x=1000,y=1000)
    can4.place(x=1000,y=1000)
    can5.place(x=1000,y=1000)
    Mafenetre.title('FINAL')
    Mafenetre.geometry('800x900')
    perso=can6.create_image(0,750,image=persoD2,anchor="nw")
    can6.place(x=0,y=0)
    can6.focus_set()
    can6.bind('<Key>',Clavier)
    texte_pnj=can6.create_text(300,850,text="",font=("Arial",13),fill="black")
    can6.create_image(225,415,image=yoshiperso1)
    can6.create_image(325,665,image=parisienperso2)
    can6.create_image(475,180,image=trumpperso3)



def amerique_map():
    global perso,posX,posY,compteur_de_pas,dico,can3,numero,niveau,Mafenetre2,can1,texte_pnj
    liste_canvas[numero].delete(perso)
    numero=4
    posX=300
    posY=0
    Mafenetre2.destroy()
    can1.place(x=1000,y=1000)
    can2.place(x=1000,y=1000)
    can5.place(x=1000,y=1000)
    can6.place(x=1000,y=1000)
    can4.place(x=0,y=0)
    Mafenetre.title('AMERIQUE')
    Mafenetre.geometry('800x900')
    perso=can4.create_image(300,0,image=persoD2,anchor="nw")
    can4.focus_set()
    can4.bind('<Key>',Clavier)
    texte_pnj=can4.create_text(300,850,text="",font=("Arial",13),fill="black")

def croissant():
    global compteur_objet1
    compteur_objet1=1
    can3.itemconfig(texte_pnj,text="")
    can3.create_text(350,850,fill="#f6d51b",font="Times 20 italic bold",text="BRAVO TU AS TROUVE LE CROISSANT")
    can3.create_image(685,850,image=objetcroissant)


def croissantdelete():
    can3.itemconfig(texte_pnj,text="")

def croissant2 ():
    can2.create_image(685,850,image=objetcroissant)
    can1.create_image(685,850,image=objetcroissant)
    can4.create_image(685,850,image=objetcroissant)
    can6.create_image(685,850,image=objetcroissant)



def parchemin_texte():
    global compteur_objet2
    compteur_objet2=1
    can2.itemconfig(texte_pnj,text="")
    can2.create_text(350,850,fill="#f6d51b",font="Times 20 italic bold",text="BRAVO TU AS TROUVE LE PARCHEMIN")
    can2.create_image(654,861,image=objetparchemin)

def parchemin():
    global objet1
    can2.after(2000,parchemin_texte)
    can2.delete(Mafenetre,objet1)


def parchemin2():
    can3.create_image(654,861,image=objetparchemin)
    can1.create_image(654,861,image=objetparchemin)
    can4.create_image(654,861,image=objetparchemin)
    can6.create_image(654,861,image=objetparchemin)


def hotdog_texte():
    global compteur_objet3
    compteur_objet3=1
    can4.itemconfig(texte_pnj,text="")
    can4.create_text(350,850,fill="#f6d51b",font="Times 20 italic bold",text="BRAVO TU AS TROUVE LE HOTDOG")
    can4.create_image(764,870,image=objethotdog)

def hotdog():
    can4.after(2000,hotdog_texte)



def hotdog2 ():
    can3.create_image(764,870,image=objethotdog)
    can1.create_image(764,870,image=objethotdog)
    can2.create_image(764,870,image=objethotdog)
    can6.create_image(764,870,image=objethotdog)

numero=0
deja_passe=True
deja_passe2=True
deja_passe3=True
deja_passe3bis=True
deja_passe4=True
def Clavier(event):
    global posX,posY,niveau,numero,cases_interdites

    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    cases_interdites=["C","H","PNO","PSO","F1","FB","LH","M","LB","CSO","CSE","CNO","CNE","TTSE","TTSO","TTNE","TTNO","F2","F3","F4","E","N","SL2","CP2",
    "CP3","CP5","CP8","SL7","SL8","MPJNO","MPJNE","AU","B1","B2","B3","B4","E5","E3","E2","T3","T1","N","AERNO","AERNE","N2","LNO","LN","LNE","CT2","T5","FINAL1","FINAL2","FINAL3","TE"]

    if numero==1 :
        if touche=='Up' and japon[ligne-1][colonne] not in cases_interdites:
            mvt_haut()
        if touche=='Down' and japon[ligne+1][colonne] not in cases_interdites:
            mvt_bas()
        if touche=="Right" and  japon[ligne][colonne+1] not in cases_interdites:
            mvt_droite()
        if touche=="Left" and  japon[ligne][colonne-1] not in cases_interdites:
            mvt_gauche()
    if numero==2 :
        if touche=='Up' and maison_interior[ligne-1][colonne] not in cases_interdites:
            mvt_haut()
        if  touche=='Down' and maison_interior[ligne+1][colonne] not in cases_interdites:
            mvt_bas()
        if touche=='Right' and  maison_interior[ligne][colonne+1] not in cases_interdites:
            mvt_droite()
        if touche=='Left' and  maison_interior[ligne][colonne-1] not in cases_interdites:
            mvt_gauche()
    if numero==3 :
        if touche=='Up'  and france[ligne-1][colonne] not in cases_interdites:
            mvt_haut()
        if touche=='Down' and france[ligne+1][colonne] not in cases_interdites:
            mvt_bas()
        if touche=="Right" and  france[ligne][colonne+1] not in cases_interdites:
            mvt_droite()
        if touche=="Left"  and  france[ligne][colonne-1] not in cases_interdites:
            mvt_gauche()

    if numero==4:
        if touche=='Up' and amerique[ligne-1][colonne] not in cases_interdites  and numero==4:
            mvt_haut()

        if  touche=='Down' and amerique[ligne+1][colonne] not in cases_interdites  and  numero==4:
            mvt_bas()

        if touche=="Right" and  amerique[ligne][colonne+1] not in cases_interdites and numero==4:
            mvt_droite()

        if touche=='Left' and  amerique[ligne][colonne-1] not in cases_interdites and numero==4:
            mvt_gauche()

    if numero==5:

        if touche=='Up' and regle[ligne-1][colonne] not in cases_interdites  and numero==5:
            mvt_haut()

        if  touche=='Down' and regle[ligne+1][colonne] not in cases_interdites  and  numero==5:
            mvt_bas()

        if touche=="Right" and  regle[ligne][colonne+1] not in cases_interdites and numero==5:
            mvt_droite()

        if touche=='Left' and  regle[ligne][colonne-1] not in cases_interdites and numero==5:
            mvt_gauche()


    if numero==6:

        if touche=='Up' and final[ligne-1][colonne] not in cases_interdites  and numero==6:
            mvt_haut()

        if  touche=='Down' and final[ligne+1][colonne] not in cases_interdites  and  numero==6:
            mvt_bas()

        if touche=="Right" and  final[ligne][colonne+1] not in cases_interdites and numero==6:
            mvt_droite()

        if touche=='Left' and  final[ligne][colonne-1] not in cases_interdites and numero==6:
            mvt_gauche()



def mvt_gauche():
    global perso,posX,posY,compteur_de_pas,texte_pnj,numero,compteur_objet1,compteur_objet2,compteur_objet3,deja_passe3bis,deja_passe4
    posX=posX-50
    if posX<0 :
        posX=00
    liste_canvas[numero].itemconfig(perso,image=tab_gauche[compteur_de_pas%3])
    compteur_de_pas+=1
    liste_canvas[numero].coords(perso,posX,posY)
    if numero==1:
        if posX==50  and posY==0  :
            liste_canvas[numero].after(100,aeroport)
        if posX==50  and posY==50 :
            liste_canvas[numero].after(100,aeroport)

    if numero==2:
        if posX==100 and posY==550:
            liste_canvas[numero].after(100,retour)

    if numero==3 :
        if posX==50  and posY==100 or posX==50  and posY==150 :
            liste_canvas[numero].after(100,aeroport)
        if posX==100 and posY==750:
            liste_canvas[numero].after(100,croissant)
        if posX==100 and posY==750:
            liste_canvas[numero].after(100,croissant2)
    if numero==4 :
        if posX==100  and posY==700 or posX==100  and posY==750 :
            liste_canvas[numero].after(100,aeroport)

        if posX==150 and posY==550 or posX==150 and posY==600:
            liste_canvas[numero].itemconfig(texte_pnj,text="salut tu as un billet pour monter en haut"+"\n"+"non ? alors tu ne pourras pas avoir ton hotdog"+"\n"+"les taxis en donnent souvent aux touristes")

        if posX==600 and posY==550 or posX==600 and posY==600:
            liste_canvas[numero].after(100,hotdog)

        if posX==600  and posY==550 or posX==600  and posY==600 :
            liste_canvas[numero].after(100,hotdog2)


        if deja_passe4==True and posX==600  and posY==550 or deja_passe4==True and posX==600  and posY==600:
            liste_canvas[numero].itemconfig(texte_pnj,text="Il parait que tu cherches un hotdog?"+"\n"+"ca tombe bien il m'en reste un, TIENT !")
            deja_passe4=False
    if numero==6 :
        if posX==50  and posY==700 or posX==50  and posY==750 :
            liste_canvas[numero].after(100,aeroport)

        if posX==50 and posY==700 or posX==50 and posY==750 :
            can6.itemconfig(texte_pnj,text="")
        if posX==50 and posY==50 or posX==50 and posY==100 :
            liste_canvas[numero].after(100,final_final)
def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,texte_pnj,numero,compteur_objet,deja_passe,deja_passe2,deja_passe3,deja_passe3bis
    posY=posY-50
    if posY<0 :
        posY=0

    liste_canvas[numero].itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    liste_canvas[numero].coords(perso,posX,posY)
    if numero==2:
        if posX==550  and posY==400 or posX==500  and posY==400:
            liste_canvas[numero].after(100,parchemin)

        if posX==550  and posY==400 or posX==500  and posY==400:
            liste_canvas[numero].after(100,parchemin2)

        if deja_passe3bis==True and posX==550  and posY==400 or deja_passe3bis==True and posX==500  and posY==400:
            liste_canvas[numero].itemconfig(texte_pnj,text="Miaou ce parchemin sur mon parapluie te reviens"+"\n"+"fais-en bon usage")
            deja_passe3bis=False

    if numero==3 :
        if posX==700  and posY==50 or posX==650  and posY==50  :
            liste_canvas[numero].itemconfig(texte_pnj,text="Bienvenue en France j'espère que le pays te plait" +"\n"+ "mais malheureusement je n'ai pas de croissant, désolé")

        if posX==150  and posY==500 or posX==100  and posY==500:
            liste_canvas[numero].itemconfig(texte_pnj,text="Oh ! la maison semble vide")

        if posX==450  and posY==550 or posX==500  and posY==550 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Va voir dans l'autre maison jaune")

    if numero==4 :
        if posX==100 and posY==200 or posX==150 and posY==200 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Hey je suis la statue de la liberté j'espère que tu te plais en Amerique"+"\n"+"il paraît que tu cherches un hotdog mais je n'en ai pas, désolé"+"\n"+"peut-être chez Central Perk !")

        if posX==700 and posY==50 or posX==650 and posY==50 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Bienvenue à Central Perk que puis-je te servir ? "+"\n"+ "Un hotdog ? malheureusement nous n'en avons plus en stock, désolé"+"\n"+" Va voir Donald Trump il doit savoir quelque chose")

    if numero==6 :

        if deja_passe==True and posX==300 and posY==700 and compteur_objet1==1:
            liste_canvas[numero].after(1000,passage1)
            deja_passe=False
            liste_canvas[numero].itemconfig(texte_pnj,text="Te revoilà, tu as le croissant, super je te laisse passer")
        if posX==300 and posY==700 and compteur_objet1==0:
            liste_canvas[numero].itemconfig(texte_pnj,text="Tu n'as pas le croissant, tu peux aller le chercher en france")




        if deja_passe2==True and posX==200 and posY==450 and compteur_objet2==1:
            liste_canvas[numero].after(1000,passage2)
            deja_passe2=False
            liste_canvas[numero].itemconfig(texte_pnj,text="Super, tu as trouvé le parchemin, tu peux passer")
        if posX==200 and posY==450 and compteur_objet2==0:
            liste_canvas[numero].itemconfig(texte_pnj,text="Tu n'as pas le parchemin, tu peux aller le chercher au japon")




        if deja_passe3==True and  posX==450 and posY==200 and compteur_objet3==1:
            liste_canvas[numero].after(1000,passage3)
            deja_passe3=False
            liste_canvas[numero].itemconfig(texte_pnj,text="Génial tu as bien les 3 objets, dirige toi vers la sortie")
        if posX==450 and posY==200 and compteur_objet3==0:
            liste_canvas[numero].itemconfig(texte_pnj,text="Ewww tu n'as pas le hotdog!!")



def mvt_bas():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,texte_pnj,numero
    posY=posY+50
    if posY>750 :
        posY=750
    liste_canvas[numero].itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    liste_canvas[numero].coords(perso,posX,posY)
    if numero==1:
        if posX==400  and posY==300 or posX==450  and posY==300:
            liste_canvas[numero].itemconfig(texte_pnj,text="Yummy nous sommes les sushis"+"\n"+" et nous n'avons pas vu ton objet, va voir Yoshi Yummy")
        if posX==500  and posY==700 or posX==550 and posY==700:
            liste_canvas[numero].itemconfig(texte_pnj,text="HELLO KITTY c'est moi, je n'ai pas ton objet"+"\n"+" va voir dans l'autre maison il devrait s'y trouver")

        if posX==600  and posY==450 or posX==650  and posY==450 :
            liste_canvas[numero].after(100,maison)


def mvt_droite():
    global perso,posX,posY,compteur_de_pas,texte_pnj,numero
    posX=posX+50
    if posX>800 :
        posX=800
    liste_canvas[numero].itemconfig(perso,image=tab_droite[compteur_de_pas%3])
    compteur_de_pas+=1
    liste_canvas[numero].coords(perso,posX,posY)
    if numero==1:
        if posX==100 and posY==450 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Je n'ai pas ton objet, va dans l'une des maisons"+"\n"+" tu trouveras ton bonheur YOSHIIIII")
        if posX==400  and posY==350 or posX==400  and posY==300 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Yummy nous sommes les sushis"+"\n"+" et nous n'avons pas vu ton objet, va voir Yoshi Yummy")

    if numero==3:
        if posX==450  and posY==400 :
            liste_canvas[numero].itemconfig(texte_pnj,text="Je peux te donner un croissant si tu veux"+"\n"+"il faut que tu le prennes devant la maison jaune"+"\n"+ "c'est un petit enfant qui l'avait caché")
        if posX==150 and posY==750:
            liste_canvas[numero].after(100,croissantdelete)

    if numero==4:

        if posX==400  and posY==600 :
            liste_canvas[numero].itemconfig(texte_pnj,text="AMERICA GREAT AGAIN"+"\n"+"sorry j'ai mangé mon dernier hotdog"+"\n"+"peut-être à l'Empire State Building they got one")
    if numero==5:
        if posX==700 and posY==750:
            liste_canvas[numero].after(100,aeroport)
def aeroport():
    global Mafenetre2
    Mafenetre2=Toplevel()
    Mafenetre2.title('AEROPORT')
    Mafenetre2.geometry('400x400')
    photo = PhotoImage(file = "bg.gif")
    w = Label(Mafenetre2, image=photo)
    w.pack()

    bt1 = PhotoImage(file='boutonfrance.gif')
    button1= Button(Mafenetre2,image=bt1,command= france_map)
    button1.pack()
    button1.place(x=150, y=70)
    bt2 = PhotoImage(file='boutonjapon.gif')
    button2=Button(Mafenetre2,image=bt2,command = japon_aero)
    button2.pack()
    button2.place(x=150, y=150)
    bt3 = PhotoImage(file='boutonamerique.gif')
    button3=Button(Mafenetre2,image=bt3,command = amerique_map)
    button3.pack()
    button3.place(x=150, y=230)
    bt4 = PhotoImage(file='finalbouton.gif')
    button4=Button(Mafenetre2,image=bt4,command = final_map)
    button4.pack()
    button4.place(x=150, y=310)
    Mafenetre2.mainloop()

#programme principal
posX=100
posY=0

Mafenetre.mainloop()

