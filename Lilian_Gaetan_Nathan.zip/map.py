from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.title("QUIZ INFORMATIQUE")
Mafenetre.geometry('650x1000')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=650,height=1000)
can1.place(x=0,y=0)
#creation des cases images
casechemin=PhotoImage(file="chemin.gif")
casemur=PhotoImage(file="mur.gif")
caseusb=PhotoImage(file="usb.gif")
joueur=PhotoImage(file="perso.gif")
casepnj=PhotoImage(file="pnj.gif")
niveau=1
#creation de la matrice
L00=["M","C","U","C","M","C","U","C","M","C","U","C","M"]
L01=["M","C","C","C","M","C","C","C","M","C","C","C","M"]
L02=["M","C","C","C","M","C","C","C","M","C","C","C","M"]
L03=["M","C","C","C","M","C","C","C","M","C","C","C","M"]
L04=["M","C","C","C","C","C","C","C","C","C","C","C","M"]
L05=["M","C","C","C","C","C","C","C","C","C","C","C","M"]
L06=["M","C","C","C","C","C","C","C","C","C","C","C","M"]
L07=["M","M","M","M","M","C","C","C","M","M","M","M","M"]
L08=["M","M","M","M","M","C","C","C","M","M","M","M","M"]
L09=["M","M","M","M","M","C","C","C","M","M","M","M","M"]
L10=["M","M","M","M","M","C","C","C","M","M","M","M","M"]
L11=["M","M","M","M","M","C","C","C","M","M","M","M","M"]
ma_matrice=[L00,L01,L02,L03,L04,L05,L06,L07,L08,L09,L10,L11]
#creation de la map
dico={"C":casechemin,"M":casemur,"U":caseusb}
for i in range(12):
    for j in range(13):
        can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
#position du personnage
posX=300
posY=550
perso=can1.create_image(posX,posY,image=joueur,anchor="nw")
pnj=can1.create_image(250,400,image=casepnj,anchor="nw")

#réponse
reponse=can1.create_text(325,625,text="Allez chercher une clé USB pour choisir une réponse",font=("Arial",14),fill="black")
indice=can1.create_text(325,680,text="Si vous avez besoin d'un indice pour une question, allez voir l'inspecteur !",font=("Arial",14),fill="black")
compteur_indice=0
compteur_mr=0
#fonctions de déplacements
def Clavier(event):
    global posX,posY
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    if touche=="Up" and ma_matrice[ligne-1][colonne]!="M":
        if touche=="Up" and ma_matrice[ligne-1][colonne]!="D":
            mvt_haut()
    if touche=="Right" and ma_matrice[ligne][colonne+1]!="M":
        if touche=="Right" and ma_matrice[ligne][colonne+1]!="D":
            mvt_droite()
    if touche=="Left" and ma_matrice[ligne][colonne-1]!="M":
        if touche=="Left" and ma_matrice[ligne][colonne-1]!="D":
            mvt_gauche()
    if touche=="Down" and ma_matrice[ligne+1][colonne]!="M":
        if touche=="Down" and ma_matrice[ligne+1][colonne]!="D":
            mvt_bas()
def mvt_haut() :
    """déplace le perso vers le haut"""
    global perso,posY,posX,can1,q1,q1p1,q1p2,q1p3,niveau,compteur_mr,compteur_indice
    posY=posY-50
    if posY<0 :
        posY=0
    can1.itemconfig(perso)
    can1.coords(perso,posX,posY)
    if posX==100 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=2
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°2 : Qui a inventé la souris ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : John Souris")
        can1.itemconfig(q1p2,text="Réponse n°2 : Douglas Engelbart")
        can1.itemconfig(q1p3,text="Réponse n°3 : Etienne Duval")
    if posX==250 and posY==400 and niveau==1 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le premier ordinateur a été crée après 1930...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=3
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°3 : Combien d'octet fait un méga octet ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 256,48")
        can1.itemconfig(q1p2,text="Réponse n°2 : 1 000 000")
        can1.itemconfig(q1p3,text="Réponse n°3 : 1 048 576")  #v
    if posX==500 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==2 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le mot 'souris' ne viens pas du nom de famille de l'inventeur...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=4
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°4 : Que vaut le nombre binaire 1011 en décimal ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 11") #v
        can1.itemconfig(q1p2,text="Réponse n°2 : 33")
        can1.itemconfig(q1p3,text="Réponse n°3 : 44")
    if posX==250 and posY==400 and niveau==3 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Un méga octet est composé de bien plus d'octet que 256,48...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=5
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°5 : Que signifie "www" ? ')
        can1.itemconfig(q1p1,text="Réponse n°1 : World Wide Wet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : What World Who")
        can1.itemconfig(q1p3,text="Réponse n°3 : Wide World Wide")
    if posX==300 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==4 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce nombre est sur 4 bits donc le premier chiffre vaut 8 et le dernier 1...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=6
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°6 : Que signifie "USB" ?')
        can1.itemconfig(q1p1,text="Réponse n°1 : Universal Serial Button")
        can1.itemconfig(q1p2,text="Réponse n°2 : Universal Serious Bus")
        can1.itemconfig(q1p3,text="Réponse n°3 : Universal Serial Bus")  #v
    if posX==300 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==5 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous pensiez vraiment qu'il y avait le mot 'Who' dans 'WWW' ?")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=7
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°7 : Qu'est ce qu'un ventirad")
        can1.itemconfig(q1p1,text="Réponse n°1 : Un radiateur")
        can1.itemconfig(q1p2,text="Réponse n°2 : Un radiateur et un ventilateur")  #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Un ventilateur")
    if posX==250 and posY==400 and niveau==6 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Pourquoi une clé USB aurait-elle un rapport avec un bouton ?")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=8
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°8 : Qu'est ce qu'un upgrade")
        can1.itemconfig(q1p1,text="Réponse n°1 : Une connection")
        can1.itemconfig(q1p2,text="Réponse n°2 : Une erreur")
        can1.itemconfig(q1p3,text="Réponse n°3 : Une mise à jour") #v
    if posX==500 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==7 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Facile ! Regardez bien le mot...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=9
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°9 : A quoi sert une adresse ip ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : A identifier chaque PC connecté à Internet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : A identifier un PC")
        can1.itemconfig(q1p3,text="Réponse n°3 : A parler entre potes")
    if posX==250 and posY==400 and niveau==8 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Upgrade a pour synonyme évolution...")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=10
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°10 : Quel a été le jeu vidéo le plus joué en 2019 ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : GTA V")
        can1.itemconfig(q1p2,text="Réponse n°2 : League Of Legends") #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Fortnite")
    if posX==300 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==9 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous parlez par adresse ip à vos potes vous ?")
        compteur_indice+=1
        can1.after(500)
    if posX==100 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.destroy
        can2=Canvas(Mafenetre,bg="white",width=650,height=1000)
        can2.place(x=0,y=0)
        can2.create_text(325,500,text="Félicitations, vous avez réussi à répondre juste à nos 10 questions ",font=("Arial",14),fill="black")
        can2.create_text(325,525,text=" sur le thème de l'Informatique !",font=("Arial",14),fill="black")
        mr="Vous avez cependant fait :",compteur_mr," erreurs."
        i="Vous avez cependant utilisé :",compteur_indice," indices."
        can2.create_text(325,620,text=i,font=("Arial",14),fill="black")
        can2.create_text(325,600,text=mr,font=("Arial",14),fill="black")
    if posX==500 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==10 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce n'est pas un battle royale...")
        compteur_indice+=1
        can1.after(500)

def mvt_bas() :
    """déplace le perso vers le bas"""
    global perso,posY,posX
    posY=posY+50
    if posY>600 :
        posY=600
    can1.itemconfig(perso)
    can1.coords(perso,posX,posY)
    if posX==250 and posY==400 and niveau==1 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le premier ordinateur a été crée après 1930...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==2 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le mot 'souris' ne viens pas du nom de famille de l'inventeur...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==3 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Un méga octet est composé de bien plus d'octet que 256,48...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==4 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce nombre est sur 4 bits donc le premier chiffre vaut 8 et le dernier 1...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==5 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous pensiez vraiment qu'il y avait le mot 'Who' dans 'WWW' ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==6 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Pourquoi une clé USB aurait-elle un rapport avec un bouton ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==7 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Facile ! Regardez bien le mot...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==8 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Upgrade a pour synonyme évolution...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==9 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous parlez par adresse ip à vos potes vous ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==10 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce n'est pas un battle royale...")
        compteur_indice+=1
        can1.after(500)
def mvt_droite():
    """déplace le perso vers la droite"""
    global perso,posY,posX,can1,q1,q1p1,q1p2,q1p3,niveau,compteur_mr,compteur_indice
    posX=posX+50
    if posX>650 :
        posX=650
    can1.itemconfig(perso)
    can1.coords(perso,posX,posY)
    if posX==100 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=2
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°2 : Qui a inventé la souris ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : John Souris")
        can1.itemconfig(q1p2,text="Réponse n°2 : Douglas Engelbart")
        can1.itemconfig(q1p3,text="Réponse n°3 : Etienne Duval")
    if posX==100 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=3
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°3 : Combien d'octet fait un méga octet ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 256,48")
        can1.itemconfig(q1p2,text="Réponse n°2 : 1 000 000")
        can1.itemconfig(q1p3,text="Réponse n°3 : 1 048 576")  #v
    if posX==500 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=4
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°4 : Que vaut le nombre binaire 1011 en décimal ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 11") #v
        can1.itemconfig(q1p2,text="Réponse n°2 : 33")
        can1.itemconfig(q1p3,text="Réponse n°3 : 44")
    if posX==100 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=5
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°5 : Que signifie "www" ? ')
        can1.itemconfig(q1p1,text="Réponse n°1 : World Wide Wet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : What World Who")
        can1.itemconfig(q1p3,text="Réponse n°3 : Wide World Wide")
    if posX==300 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=6
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°6 : Que signifie "USB" ?')
        can1.itemconfig(q1p1,text="Réponse n°1 : Universal Serial Button")
        can1.itemconfig(q1p2,text="Réponse n°2 : Universal Serious Bus")
        can1.itemconfig(q1p3,text="Réponse n°3 : Universal Serial Bus")  #v
    if posX==300 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=7
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°7 : Qu'est ce qu'un ventirad")
        can1.itemconfig(q1p1,text="Réponse n°1 : Un radiateur")
        can1.itemconfig(q1p2,text="Réponse n°2 : Un radiateur et un ventilateur")  #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Un ventilateur")
    if posX==100 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=8
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°8 : Qu'est ce qu'un upgrade")
        can1.itemconfig(q1p1,text="Réponse n°1 : Une connection")
        can1.itemconfig(q1p2,text="Réponse n°2 : Une erreur")
        can1.itemconfig(q1p3,text="Réponse n°3 : Une mise à jour") #v
    if posX==500 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=9
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°9 : A quoi sert une adresse ip ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : A identifier chaque PC connecté à Internet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : A identifier un PC")
        can1.itemconfig(q1p3,text="Réponse n°3 : A parler entre potes")
    if posX==100 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=10
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°10 : Quel a été le jeu vidéo le plus joué en 2019 ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : GTA V")
        can1.itemconfig(q1p2,text="Réponse n°2 : League Of Legends") #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Fortnite")
    if posX==300 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.destroy
        can2=Canvas(Mafenetre,bg="white",width=650,height=1000)
        can2.place(x=0,y=0)
        can2.create_text(325,500,text="Félicitations, vous avez réussi à répondre juste à nos 10 questions ",font=("Arial",14),fill="black")
        can2.create_text(325,525,text=" sur le thème de l'Informatique !",font=("Arial",14),fill="black")
        mr="Vous avez cependant fait :",compteur_mr," erreurs."
        can2.create_text(325,600,text=mr,font=("Arial",14),fill="black")
        i="Vous avez cependant utilisé :",compteur_indice," indices."
        can2.create_text(325,620,text=i,font=("Arial",14),fill="black")
    if posX==500 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
def mvt_gauche():
    """déplace le perso vers la gauche"""
    global perso,posY,posX,can1,q1,q1p1,q1p2,q1p3,niveau,compteur_mr,compteur_indice
    posX=posX-50
    if posX<0 :
        posX=0
    can1.itemconfig(perso)
    can1.coords(perso,posX,posY)
    if posX==100 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==1:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=2
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°2 : Qui a inventé la souris ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : John Souris")
        can1.itemconfig(q1p2,text="Réponse n°2 : Douglas Engelbart")
        can1.itemconfig(q1p3,text="Réponse n°3 : Etienne Duval")
    if posX==100 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=3
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°3 : Combien d'octet fait un méga octet ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 256,48")
        can1.itemconfig(q1p2,text="Réponse n°2 : 1 000 000")
        can1.itemconfig(q1p3,text="Réponse n°3 : 1 048 576")  #v
    if posX==500 and posY==0 and niveau==2:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==3:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=4
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°4 : Que vaut le nombre binaire 1011 en décimal ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : 11") #v
        can1.itemconfig(q1p2,text="Réponse n°2 : 33")
        can1.itemconfig(q1p3,text="Réponse n°3 : 44")
    if posX==100 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=5
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°5 : Que signifie "www" ? ')
        can1.itemconfig(q1p1,text="Réponse n°1 : World Wide Wet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : What World Who")
        can1.itemconfig(q1p3,text="Réponse n°3 : Wide World Wide")
    if posX==300 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==4:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=6
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text='Question n°6 : Que signifie "USB" ?')
        can1.itemconfig(q1p1,text="Réponse n°1 : Universal Serial Button")
        can1.itemconfig(q1p2,text="Réponse n°2 : Universal Serious Bus")
        can1.itemconfig(q1p3,text="Réponse n°3 : Universal Serial Bus")  #v
    if posX==300 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==5:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==6:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=7
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°7 : Qu'est ce qu'un ventirad")
        can1.itemconfig(q1p1,text="Réponse n°1 : Un radiateur")
        can1.itemconfig(q1p2,text="Réponse n°2 : Un radiateur et un ventilateur")  #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Un ventilateur")
    if posX==100 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=8
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°8 : Qu'est ce qu'un upgrade")
        can1.itemconfig(q1p1,text="Réponse n°1 : Une connection")
        can1.itemconfig(q1p2,text="Réponse n°2 : Une erreur")
        can1.itemconfig(q1p3,text="Réponse n°3 : Une mise à jour") #v
    if posX==500 and posY==0 and niveau==7:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==8:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=9
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°9 : A quoi sert une adresse ip ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : A identifier chaque PC connecté à Internet")  #v
        can1.itemconfig(q1p2,text="Réponse n°2 : A identifier un PC")
        can1.itemconfig(q1p3,text="Réponse n°3 : A parler entre potes")
    if posX==100 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        niveau=10
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.itemconfig(q1,text="Question n°10 : Quel a été le jeu vidéo le plus joué en 2019 ?")
        can1.itemconfig(q1p1,text="Réponse n°1 : GTA V")
        can1.itemconfig(q1p2,text="Réponse n°2 : League Of Legends") #v
        can1.itemconfig(q1p3,text="Réponse n°3 : Fortnite")
    if posX==300 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==500 and posY==0 and niveau==9:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==100 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==300 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(reponse,text="Bonne réponse !")
        can1.after(500)
        can1.destroy
        can2=Canvas(Mafenetre,bg="white",width=650,height=1000)
        can2.place(x=0,y=0)
        can2.create_text(325,500,text="Félicitations, vous avez réussi à répondre juste à nos 10 questions ",font=("Arial",14),fill="black")
        can2.create_text(325,525,text=" sur le thème de l'Informatique !",font=("Arial",14),fill="black")
        mr="Vous avez cependant fait :",compteur_mr," erreurs."
        can2.create_text(325,600,text=mr,font=("Arial",14),fill="black")
        i="Vous avez cependant utilisé :",compteur_indice," indices."
        can2.create_text(325,620,text=i,font=("Arial",14),fill="black")
    if posX==500 and posY==0 and niveau==10:
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        compteur_mr+=1
        can1.itemconfig(reponse,text="Mauvaise réponse ! Essayez en une autre...")
        can1.after(500)
    if posX==250 and posY==400 and niveau==1 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le premier ordinateur a été crée après 1930...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==2 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Le mot 'souris' ne viens pas du nom de famille de l'inventeur...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==3 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Un méga octet est composé de bien plus d'octet que 256,48...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==4 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce nombre est sur 4 bits donc le premier chiffre vaut 8 et le dernier 1...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==5 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous pensiez vraiment qu'il y avait le mot 'Who' dans 'WWW' ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==6 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Pourquoi une clé USB aurait-elle un rapport avec un bouton ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==7 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Facile ! Regardez bien le mot...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==8 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Upgrade a pour synonyme évolution...")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==9 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Vous parlez par adresse ip à vos potes vous ?")
        compteur_indice+=1
        can1.after(500)
    if posX==250 and posY==400 and niveau==10 :
        posX=300
        posY=550
        can1.coords(perso,posX,posY)
        can1.itemconfig(perso)
        can1.itemconfig(indice,text="Ce n'est pas un battle royale...")
        compteur_indice+=1
        can1.after(500)
#Première question
q1=can1.create_text(325,725,text="Question n°1 : En quel année a été crée le premier ordinateur ?",font=("Arial",14),fill="black")
q1p1=can1.create_text(325,775,text="Réponse n°1 : 1930",font=("Arial",14),fill="black")
q1p2=can1.create_text(325,800,text="Réponse n°2 : 1970",font=("Arial",14),fill="black")
q1p3=can1.create_text(325,825,text="Réponse n°3 : 1945",font=("Arial",14),fill="black")
#programme principal
can1.focus_set()
can1.bind('<Key>',Clavier)
Mafenetre.mainloop()