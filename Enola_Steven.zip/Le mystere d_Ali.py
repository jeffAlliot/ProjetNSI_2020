#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('700x900')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=1275,height=900)
can1.place(x=0,y=0)
#creation des cases images
Herbe=PhotoImage(file="herbe.gif")
parquet=PhotoImage(file="parquet.gif")
chemin=PhotoImage(file="sable,gravier.gif")
entrée=PhotoImage(file="tapis.gif")
perso1=PhotoImage(file="perso1.gif")
perso2=PhotoImage(file="perso2.gif")
perso3=PhotoImage(file="perso3.gif")
perso4=PhotoImage(file="perso4.gif")
perso5=PhotoImage(file="perso5.gif")
perso6=PhotoImage(file="perso6.gif")
perso7=PhotoImage(file="perso7.gif")
perso8=PhotoImage(file="perso8.gif")
murhaut=PhotoImage(file="mur_haut.gif")
murbas=PhotoImage(file="mur_bas.gif")
murdroit=PhotoImage(file="mur_gauche.gif")
murgauche=PhotoImage(file="mur_droit.gif")
anglegauchebas=PhotoImage(file="angle_gauche_bas.gif")
angledroitebas=PhotoImage(file="angle_droite_bas.gif")
anglegauchehaut=PhotoImage(file="angle_haut_gauche.gif")
angledroitehaut=PhotoImage(file="angle_haut_droite.gif")
table=PhotoImage(file="table.gif")
Dalle=PhotoImage(file="Dalle.gif")
buisson=PhotoImage(file="sapin.gif")
franck=PhotoImage(file="Franck.gif")
marilyne=PhotoImage(file="Maryline.gif")
ali=PhotoImage(file="Ali.gif")
start1=PhotoImage(file="start1.gif")
#start2=PhotoImage(file="start2.gif")
start3=PhotoImage(file="start3.gif")
jeu=PhotoImage(file="jeu.gif")
tab_droite=[perso3,perso7]
tab_gauche=[perso4,perso8]
tab_haut=[perso2,perso6]
tab_bas=[perso1,perso5]
tab_start=[jeu,start1,start3]
compteur_de_pas=0
niveau=0
#start
if niveau==0:
    #position 
    posX=0  #abscisse de départ
    posY=0 #ordonnée de départ
    start=can1.create_image(posX,posY,image=jeu,anchor="nw")
#niveau 1
def menu():
    global can1,posX,posY,perso,niveau,ma_matrice,text_pnj1,text_pnj2
    niveau=1
    ma_matrice=[]
    #creation de la matrice
    L0=["AHG","MH","MH","MH","MH","MH","AHD"]
    L1=["MG","P","P","P","P","P","MD"]
    L2=["MG","P","P","T","P","P","MD"]
    L3=["MG","P","P","P","P","P","MD"]
    L4=["MG","M","P","P","P","P","MD"]
    L5=["MG","P","P","P","P","P","MD"]
    L6=["ABG","MB","MB","E","MB","MB","ABD"]
    ma_matrice=[L0,L1,L2,L3,L4,L5,L6]
    #creation de la map
    dico={"P":parquet,"M":marilyne,"T":table,"E":entrée,"MB":murbas,"MH":murhaut,"MD":murdroit,"MG":murgauche,"AHG":anglegauchehaut,"AHD":angledroitehaut,"ABD":angledroitebas,"ABG":anglegauchebas}
    for i in range(7):
        for j in range(7):
            can1.create_image(100*j,100*i,image=dico[ma_matrice[i][j]],anchor="nw")
    #position du personnage
    posX=300  #abscisse de départ
    posY=300 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=perso1,anchor="nw")
    #zone de texte
    text_pnj1=can1.create_text(1000,325,text="Pendant une soirée ton amie a disparue",font=("Georgia",15),fill="Black")
    text_pnj2=can1.create_text(1005,350,text="Essaye de la retrouver en demandant de l'aide aux passants",font=("Georgia",15),fill="Black")

#fonctions
def Clavier(event):
    """event variable qui a récupéré l'information tapée au Clavier"""
    global posY,posX,ma_matrice,niveau
    touche=event.keysym
    ligne=posY//100
    colonne=posX//100
    cases_interdites=["MH","MD","B","H","ABD","ABG","AHD","AHG","MB","MG","F","M","A","T"]
    if touche=='Up' and ma_matrice[ligne-1][colonne] not in cases_interdites : 
        mvt_haut()
    if touche=='Right' and ma_matrice[ligne][colonne+1] not in cases_interdites: 
        mvt_droite()
    if touche=='Left' and ma_matrice[ligne][colonne-1] not in cases_interdites: 
        mvt_gauche()
    if touche=='Down' and ma_matrice[ligne+1][colonne] not in cases_interdites: 
        mvt_bas()
    if touche=='space':
        avancement()
        
def position():
    global posX,posY,can1,niveau,text_pnj1,text_pnj2
    if niveau==1 and posX==200 and posY==400 :
        can1.itemconfig(text_pnj1,text="Je crois l'avoir vu dans le jardin...")
        can1.itemconfig(text_pnj2,text="")
                
    if niveau==2 and posX==400 and posY==200 :
        can1.itemconfig(text_pnj1,text="Tout à l'heure elle est passé devant la Cabane")
        can1.itemconfig(text_pnj2,text="")
       
        
    if niveau==3 and posX==300 and posY==300 :
        can1.itemconfig(text_pnj1,text="Oh Salut, j'était en train de te chercher ")
        can1.itemconfig(text_pnj2,text="")
        
        
def mvt_haut() :
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_haut,position
    posY=posY-100
    if posY<0:
        posY=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()

def mvt_droite():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_droite,position
    posX=posX+100
    if posX>500:
        posX=500
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()

def avancement():
    """avancement du chargement"""
    global can1,compteur_de_pas,tab_start
    #mise à jour de l'image
    can1.itemconfig(start,image=tab_start[compteur_de_pas%3])
    compteur_de_pas+=1
    if compteur_de_pas==3:
        can1.after(1000,menu)


def mvt_gauche():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_gauche,position
    posX=posX-100
    if posX<0:
        posX=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()

def mvt_bas():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,texte_pnj,compteur_de_pas,tab_bas,position
    posY=posY+100
    if posY>600:
        posY=300
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    print(posX,posY)
    can1.coords(perso,posX,posY)
    if posX==300 and posY==600 :
        can1.after(2000,entree)
    if posX==200 and posY==600 :
        can1.after(2000,dalle)
    position()

#niveau 2
def entree():
    global can1,posX,posY,perso,niveau,ma_matrice,text_pnj1,text_pnj2
    niveau=2
    ma_matrice=[] 
     #creation de la matrice
    L0=["B","B","B","C","B","B","B"]
    L1=["B","H","H","C","H","H","B"]
    L2=["B","H","H","C","C","F","B"]
    L3=["B","H","H","H","C","H","B"]
    L4=["B","H","H","C","C","H","B"]
    L5=["B","H","C","C","H","H","B"]
    L6=["B","B","D","B","B","B","B"]
    ma_matrice=[L0,L1,L2,L3,L4,L5,L6]
     #creation de la map
    dico={"D":Dalle,"F":franck,"B":buisson,"H":Herbe,"C":chemin}
    for i in range(7):
        for j in range(7):
            can1.create_image(100*j,100*i,image=dico[ma_matrice[i][j]],anchor="nw")
    #position du personnage
    posX=300  #abscisse de départ
    posY=0 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=perso1,anchor="nw")
    #zone de texte
    can1.itemconfig(text_pnj1,text="Tu es arrivé dans le jardin")
    can1.itemconfig(text_pnj2,text="Demande à Franck si il sait quelque chose")
    
#niveau 3
def dalle():
     global can1,posX,posY,perso,niveau,ma_matrice,text_pnj1,text_pnj2
     niveau=3
     ma_matrice=[]
     #creation de la matrice
     L0=["AHG","MH","MH","MH","MH","MH","AHD"]
     L1=["MG","P","P","P","P","P","MD"]
     L2=["MG","P","P","A","P","P","MD"]
     L3=["MG","P","P","P","P","P","MD"]
     L4=["MG","P","P","P","P","P","MD"]
     L5=["MG","P","P","P","P","P","MD"]
     L6=["ABG","MB","P","MB","MB","MB","ABD"]
     ma_matrice=[L0,L1,L2,L3,L4,L5,L6]
     #creation de la map
     dico={"P":parquet,"A":ali,"M":marilyne,"T":table,"MB":murbas,"MH":murhaut,"MD":murdroit,"MG":murgauche,"AHG":anglegauchehaut,"AHD":angledroitehaut,"ABD":angledroitebas,"ABG":anglegauchebas}
     for i in range(7):
        for j in range(7):
            can1.create_image(100*j,100*i,image=dico[ma_matrice[i][j]],anchor="nw")
     #position du personnage
     posX=200  #abscisse de départ
     posY=600 #ordonnée de départ
     perso=can1.create_image(posX,posY,image=perso1,anchor="nw")
     #zone de texte
     can1.itemconfig(text_pnj1,text="Tu as trouvé Ali !!!")
     can1.itemconfig(text_pnj2,text="")



#programme principal
can1.focus_set() #focus sur le can1
can1.bind('<Key>',Clavier) #fonction clavier si touche enfoncée
Mafenetre.mainloop()
