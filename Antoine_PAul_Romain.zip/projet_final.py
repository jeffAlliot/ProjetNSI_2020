#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.title("mini jeu")
Mafenetre.attributes('-fullscreen',True)
Mafenetre.geometry('1250x1250')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=1250,height=1250)
can1.place(x=0,y=0)
#creation des cases images
caseeau=PhotoImage(file="eau.gif")
casepont=PhotoImage(file="pont.gif")
casearbre1=PhotoImage(file="arbre.gif")
caseherbe=PhotoImage(file="herbe.gif")
casesable=PhotoImage(file="sable.gif")
mouv1=PhotoImage(file="perso.gif")
mouv2=PhotoImage(file="perso2.gif")
mouv3=PhotoImage(file="perso3.gif")
droite1=PhotoImage(file="droite1.gif")
droite2=PhotoImage(file="droite2.gif")
droite3=PhotoImage(file="droite3.gif")
gauche1=PhotoImage(file="gauche1.gif")
gauche2=PhotoImage(file="gauche2.gif")
gauche3=PhotoImage(file="gauche3.gif")
papi=PhotoImage(file="papi.gif")
caillou=PhotoImage(file="caillou.GIF")
murdroite=PhotoImage(file="murdroite.GIF")
murdroitebord=PhotoImage(file="murdroitebord.GIF")
murdroitebordhaut=PhotoImage(file="murdroitebordhaut.gif")
murdroitehaut=PhotoImage(file="murdroitehaut.GIF")
murgauche=PhotoImage(file="murgauche.GIF")
murgauchecoin=PhotoImage(file="murgauchecoin.GIF")
murgauchecoin1=PhotoImage(file="murgauchecoin1.GIF")
murgauchecoin2=PhotoImage(file="murgauchecoin2.GIF")
murgauchecoinhaut=PhotoImage(file="murgauchecoinhaut.GIF")
murhaut2=PhotoImage(file="murhaut2.GIF")
sol=PhotoImage(file="sol.GIF")
sol1=PhotoImage(file="sol1.GIF")
solbordurehaute=PhotoImage(file="solbordurehaute.GIF")
solhaut=PhotoImage(file="solhaut.GIF")
grotte=PhotoImage(file="grotte.gif")
echelle=PhotoImage(file="echelle.GIF")
echelle2=PhotoImage(file="echelle2.GIF")
P2=PhotoImage(file="P2.gif")
P1=PhotoImage(file="P1.gif")

#creation de la matrice
L0=["A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A"]
L1=["A","H","H","H","H","A","H","A","A","H","A","H","H","A","H","H","H","H","H","H","A","H","H","H","A"]
L2=["A","H","H","A","H","H","H","H","H","H","H","H","H","H","H","A","A","A","H","A","A","H","H","A","A"]
L3=["A","H","H","H","H","H","H","H","H","A","A","A","H","A","H","A","A","A","H","A","A","H","H","H","A"]
L4=["A","H","H","H","H","A","H","H","H","H","H","A","H","A","H","A","A","H","H","H","H","H","H","H","A"]
L5=["A","A","H","H","H","A","H","A","H","A","H","A","H","A","H","H","H","H","H","H","H","H","H","H","A"]
L6=["A","H","H","H","H","A","A","H","A","H","A","H","A","H","A","A","A","A","A","A","A","H","H","H","A"]
L7=["A","H","A","H","H","A","H","H","H","H","H","H","H","H","A","H","H","H","H","H","A","H","H","H","A"]
L8=["A","H","H","H","H","A","H","H","H","A","H","H","H","H","A","H","S","S","S","H","A","H","H","H","A"]
L9=["A","H","H","H","H","A","H","H","A","H","H","H","H","H","A","H","S","G","S","H","A","H","H","H","A"]
L10=["A","H","H","H","H","A","S","S","S","S","S","S","S","S","A","S","S","S","S","H","A","H","H","H","A"]
L11=["A","H","A","A","A","A","S","S","S","S","S","S","S","S","S","S","S","S","S","H","A","H","H","H","A"]
L12=["A","H","H","S","S","A","H","H","A","H","H","H","H","H","A","A","A","A","A","A","A","H","H","H","A"]
L13=["A","H","H","S","S","H","A","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","A"]
L14=["E","E","E","P","P","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E"]
L15=["E","E","E","P","P","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E","E"]
L16=["A","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","A"]
L17=["A","H","H","A","A","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","H","A"]
L18=["A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A","A"]#25 lignes
ma_matrice1=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18]
L18=["SH","MDH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MH","MGCH"]
L19=["SH","MD","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S","S","S","S","S","S1","S1","S1","MG"]
L20=["SH","MD","S","S","S","S","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S","S","MGC1","SB","SB","SB","MDBH","S1","MG"]
L21=["SH","MD","S","S","S","S","S1","S1","S1","S1","S1","S1","MGC1","SB","SB","SB","MDBH","S","MGC2","MH","MH","MH","MDB","S1","MG"]
L22=["SH","MD","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MD","S","S","S","S1","S1","S1","S1","MG"]
L23=["SH","MD","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MD","S","S","S","S1","S1","S1","S1","MG"]
L24=["SH","SB","SB","SB","SB","MDBH","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MD","S","S","S","S1","S1","S1","S1","MG"]
L25=["SH","S1","S1","S1","S1","MD","S1","S1","S1","S1","S1","S1","MGC2","MH","MGC","S1","SB","SB","SB","SB","SB","SB","SB","SB","MG"]
L26=["SH","MDH","MH","MH","MH","MDB","MDH","MH","MH","MH","MH","MH","MGC","S1","MGC2","MH","MH","MH","MH","MH","MH","MH","MH","MH","MG"]
L27=["SH","MD","MDH","MH","MH","MH","MDB","S1","S1","S1","S1","S1","MGC2","MH","MH","MH","MH","MH","MH","MH","MGCH","S1","S1","S1","MG"]
L28=["SH","MD","MD","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MG"]
L29=["SH","MD","MD","S1","S1","S1","S1","S1","S","S","S1","S1","S1","S1","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MG"]
L30=["SH","MD","MD","S1","S1","S1","S1","MGC1","SB","SB","SB","SB","MDBH","S1","S1","S1","S1","S1","S1","S1","MG","S1","S1","S1","MG"]
L31=["SH","MD","MD","S1","S1","S1","S1","MG","S1","S1","S1","S1","MD","S1","S1","S1","S1","S1","S1","S1","MGC2","MH","MH","MH","MG"]
L32=["SH","MD","MD","S1","S1","S1","S1","MG","MGC1","SB","SB","MDBH","SB","SB","SB","MDBH","S1","S1","S1","S1","S1","S1","S1","S1","MG"]
L33=["SH","MD","MD","S1","S1","S1","S1","MG","MG","S1","S1","MD","S1","S1","S1","MD","S1","S1","S1","S1","S1","S1","S1","S1","MG"]
L34=["SH","MD","MD","S1","S1","S1","C","MG","MG","S1","S1","MD","S1","S1","S1","SB","SB","SB","MDBH","S1","S1","S1","S1","S1","MG"]
L35=["SH","MD","SB","P1","P2","SB","SB","SB","MG","S1","S1","SB","SB","MDBH","S1","S1","S1","S1","MD","S1","S1","S1","S1","C","MG"]
L36=["SH","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB","SB"]

ma_matrice2=[L18,L19,L20,L21,L22,L23,L24,L25,L26,L27,L28,L29,L30,L31,L32,L33,L34,L35,L36]
#creation de la map
dico1={"E":caseeau,"P":casepont,"G":grotte,"A":casearbre1,"H":caseherbe,"S":casesable}
dico2={"P2":P2,"P1":P1,"C":caillou,"MD":murdroite,"E":echelle,"MDB":murdroitebord,"MDBH":murdroitebordhaut,"MDH":murdroitehaut,"MG":murgauche,"MGC":murgauchecoin,"MGC1":murgauchecoin1,"MGC2":murgauchecoin2,"MGCH":murgauchecoinhaut,"MH":murhaut2,"SB":solbordurehaute,"S":sol,"S1":sol1,"SH":solhaut}
for i in range(19):
    for j in range(25):
        can1.create_image(50*j,50*i,image=dico1[ma_matrice1[i][j]],anchor="nw")
#position du personnage
posX=1150  #abscisse de départ
posY=800#ordonnée de départ
posX1=900
posY1=450
posX2=950
posY2=50
ech=can1.create_image(posX2,posY2,image=echelle,anchor="nw")
perso=can1.create_image(posX,posY,image=mouv1,anchor="nw")
mouv_haut=[mouv1,mouv2,mouv3]
mouv_droite=[droite1,droite2,droite3]
mouv_gauche=[gauche1,gauche2,gauche3]
compteur_de_pas=0
texte_pnj=can1.create_text(850,400,text="",font=("Arial",12),fill="black")
texte_perso1=can1.create_text(625,400,text="",font=("Arial",12),fill="black")
texte_perso2=can1.create_text(625,425,text="",font=("Arial",12),fill="black")
texte_perso3=can1.create_text(625,425,text="",font=("Arial",12),fill="black")
texte_fin=can1.create_text(0,1000,text="",font=("Arial",20),fill="black")
texte_narrat=can1.create_text(100,970,text="vas parler au papi",font=("Arial",18),fill="black")
perso2=can1.create_image(posX1,posY1,image=papi,anchor="nw")
compteur_mission=0
compt_echelle=0
clavier=0

#fonctions
def Clavier1(event):
    """event variable qui a récupéré l'information tapée au Clavier"""
    global posY,posX,ma_matrice
    touche=event.keysym
    ligne=posY//50
    colonne=posX//50
    if touche=='Up' and ma_matrice1[ligne-1][colonne]!="A" and ma_matrice1[ligne-1][colonne]!="E" :
        mvt_haut()
    if touche=='Right' and ma_matrice1[ligne][colonne+1]!="A" and ma_matrice1[ligne][colonne+1]!="E" :
        mvt_droite()
    if touche=='Left' and ma_matrice1[ligne][colonne-1]!="A" and ma_matrice1[ligne][colonne-1]!="E" :
        mvt_gauche()
    if touche=='Down' and ma_matrice1[ligne+1][colonne]!="A" and ma_matrice1[ligne+1][colonne]!="E" :
        mvt_bas()


def Clavier2(event):
    """event variable qui a récupéré l'information tapée au Clavier"""
    global posY,posX,ma_matrice
    touche=event.keysym
    ligne=posY//50
    colonne=posX//50
    if touche=='Up' and (ma_matrice2[ligne-1][colonne]=="S" or ma_matrice2[ligne-1][colonne]=="S1" or ma_matrice2[ligne-1][colonne]=="E"):
        mvt_haut()
    if touche=='Right' and (ma_matrice2[ligne][colonne+1]=="S" or ma_matrice2[ligne][colonne+1]=="S1" or ma_matrice2[ligne][colonne+1]=="E"):
        mvt_droite2()
    if touche=='Left' and (ma_matrice2[ligne][colonne-1]=="S" or ma_matrice2[ligne][colonne-1]=="S1" or ma_matrice2[ligne][colonne-1]=="E"):
        mvt_gauche()
    if touche=='Down' and (ma_matrice2[ligne+1][colonne]=="S" or ma_matrice2[ligne+1][colonne]=="S1" or ma_matrice2[ligne+1][colonne]=="E" or ma_matrice2[ligne+1][colonne]=="P1" or ma_matrice2[ligne+1][colonne]=="P2") :
        mvt_bas()

def Clavier3(event):
    """event variable qui a récupéré l'information tapée au Clavier"""
    global posY,posX,ma_matrice
    touche=event.keysym
    ligne=posY//50
    colonne=posX//50
    if touche=='Up' and ma_matrice1[ligne-1][colonne]!="A" and ma_matrice1[ligne-1][colonne]!="E" :
        mvt_haut()
    if touche=='Right' and ma_matrice1[ligne][colonne+1]!="A" and ma_matrice1[ligne][colonne+1]!="E" :
        mvt_droite3()
    if touche=='Left' and ma_matrice1[ligne][colonne-1]!="A" and ma_matrice1[ligne][colonne-1]!="E" :
        mvt_gauche()
    if touche=='Down' and ma_matrice1[ligne+1][colonne]!="A" and ma_matrice1[ligne+1][colonne]!="E" :
        mvt_bas()

def mvt_haut():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_mouv,compteur_mission,perso,perso2,texte_narrat,texte_pnj,texte_perso1,texte_perso2
    posY=posY-50
    if posY<0:
        posY=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_haut[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==900 and posY==500:
        can1.itemconfig(texte_pnj,text="hey gamin, un de mes amis s'est perdu dans cette grotte. veux tu bien aller le chercher stp? ")
        compteur_mission=1
    else:
        can1.itemconfig(texte_pnj,text="")
    if compteur_mission==1:
        if posX==850 and posY==450:
            if compt_echelle==0:
                change_map()
            else:
                change_map2()
    if (posX==1150 and posY==100) or (posX==1100 and posY==50):
        texte_pnj=can1.create_text(625,400,text="ce jeu est bien foutu, ces élèves mérittent 20/20!!!",font=("Arial",30),fill="black")
        can1.after(2000,fin)
    texte()
        

def mvt_droite():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_droite,compteur_mission,perso,perso2,texte_narrat,texte_pnj,clavier,texte_perso1
    texte()
    posX=posX+50
    if posX>1250:
        posX=1250
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_droite[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==900 and posY==500:
        can1.itemconfig(texte_pnj,text="hey gamin, un de mes amis s'est perdu dans cette grotte. veux tu bien aller le chercher stp? ")
        compteur_mission=1
    else:
        can1.itemconfig(texte_pnj,text="")
    if posX==950 and posY==50:
        texte_perso1=can1.create_text(625,70,text="je me demande a quoi ca peut servir...",font=("Arial",18),fill="black")
    if compteur_mission==1:
        if posX==850 and posY==450:
            change_map()

def mvt_droite2():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_droite,compteur_mission,perso,perso2,texte_narrat,texte_pnj,clavier
    texte()
    posX=posX+50
    if posX>1250:
        posX=1250
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_droite[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if (posX==1150 and posY==100) or (posX==1100 and posY==50):
        texte_pnj=can1.create_text(625,400,text="ce jeu est bien foutu, ces élèves mérittent 20/20!!!",font=("Arial",30),fill="black")
        can1.after(2000,fin)


def mvt_droite3():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_droite,compteur_mission,perso,perso2,texte_narrat,texte_pnj
    texte()
    posX=posX+50
    if posX>1250:
        posX=1250
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_droite[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==950 and posY==50:
        echelle()
    if compteur_mission==1:
        if posX==850 and posY==450:
            change_map2()
    if (posX==1150 and posY==100) or (posX==1100 and posY==50):
        texte_pnj=can1.create_text(625,400,text="ce jeu est bien foutu, ces élèves mérittent 20/20!!!",font=("Arial",30),fill="black")
        can1.after(2000,fin)

def mvt_gauche():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_mouv,compteur_mission,perso,perso2,texte_narrat,texte_pnj
    texte()
    posX=posX-50
    if posX<0:
        posX=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_gauche[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==900 and posY==500:
        can1.itemconfig(texte_pnj,text="hey gamin, un de mes amis s'est perdu dans cette grotte. veux tu bien aller le chercher stp? ")
        compteur_mission=1
    else:
        can1.itemconfig(texte_pnj,text="")
    if compteur_mission==1:
        if posX==850 and posY==450:
            if compt_echelle==0:
                change_map()
            else:
                change_map2()
    if (posX==1150 and posY==100) or (posX==1100 and posY==50):
        texte_pnj=can1.create_text(625,400,text="ce jeu est bien foutu, ces élèves mérittent 20/20!!!",font=("Arial",30),fill="black")
        can1.after(2000,fin)

def mvt_bas():
    """deplacement du perso vers le bas"""
    global posX,posY,can1,compteur_de_pas,tab_mouv,compteur_mission,perso,perso2,texte_narrat,texte_pnj,compt_echelle
    texte()
    posY=posY+50
    if posY>1000:
        posY=1000
    #mise à jour de l'image
    can1.itemconfig(perso,image=mouv_haut[compteur_de_pas%3])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    if posX==900 and posY==500:
        can1.itemconfig(texte_pnj,text="hey gamin, un de mes amis s'est perdu dans cette grotte. veux tu bien aller le chercher stp?")
        compteur_mission=1
    else:
        can1.itemconfig(texte_pnj,text="")
    if compteur_mission==1:
        if posX==850 and posY==450:
            if compt_echelle==0:
                change_map()
            else:
                change_map2()
    if (posX==1150 and posY==100) or (posX==1100 and posY==50):
        texte_pnj=can1.create_text(625,400,text="ce jeu est bien foutu, ces élèves mérittent 20/20!!!",font=("Arial",30),fill="black")
        can1.after(2000,fin)
    if (posX==150 and posY==850) or (posX==200 and posY==850):
        map1()

def change_map():
    """change de map"""
    global can1,perso,perso2,texte_narrat,texte_pnj,posX,posY,posX1,posY1
    for i in range(19):
            for j in range(25):
                can1.create_image(50*j,50*i,image=dico2[ma_matrice2[i][j]],anchor="nw")
    posX=150
    posY=800
    posX1=1150
    posY1=50
    perso=can1.create_image(posX,posY,image=mouv1,anchor="nw")
    perso2=can1.create_image(posX1,posY1,image=papi,anchor="nw")
    can1.delete(texte_narrat)
    texte_narrat=can1.create_text(120,970,text="rejoins l'ami du papi",font=("Arial",18),fill="black")
    texte_perso1=can1.create_text(625,70,text="mmmh, j'ai l'air coincé en bas: je ne peux pas monter cette paroit..",font=("Arial",18),fill="black")
    texte_perso2=can1.create_text(625,100,text="il faut que je trouve un moyen de passer, il doit bien y avoir un indice...",font=("Arial",18),fill="black")
    can1.bind('<Key>',Clavier2)

def change_map2():
    """modifie la 2eme map"""
    global can1,ma_matrice2,perso,perso2,posX,posY,posY1,posX1,texte_perso1,texte_perso2,texte_narrat
    ma_matrice2[8][9]="E"
    for i in range(19):
        for j in range(25):
            can1.create_image(50*j,50*i,image=dico2[ma_matrice2[i][j]],anchor="nw")
    posX=150
    posY=800
    posX1=1150
    posY1=50
    perso=can1.create_image(posX,posY,image=mouv1,anchor="nw")
    perso2=can1.create_image(posX1,posY1,image=papi,anchor="nw")
    can1.delete(texte_narrat)
    texte_narrat=can1.create_text(120,970,text="rejoins l'ami du papi",font=("Arial",18),fill="black")
    texte_perso1=can1.create_text(625,400,text="hey, bien joué!",font=("Arial",18),fill="black")
    texte_perso2=can1.create_text(100,10,text="",font=("Arial",18),fill="red")
    can1.bind('<Key>',Clavier2)

def map1():
    """rechange de map"""
    global can1,perso,perso2,texte_narrat,texte_pnj,posX,posY,posX1,posY1,posX2,posY2,dico1,ma_matrice1,ech,clavier,ech2
    for i in range(19):
            for j in range(25):
                can1.create_image(50*j,50*i,image=dico1[ma_matrice1[i][j]],anchor="nw")
    posX=800
    posY=450
    posX1=900
    posY1=450
    posX2=950
    posY2=50
    can1.delete(ech)
    perso=can1.create_image(posX,posY,image=mouv1,anchor="nw")
    perso2=can1.create_image(posX1,posY1,image=papi,anchor="nw")
    ech2=can1.create_image(posX2,posY2,image=echelle2,anchor="nw")
    can1.delete(texte_narrat)
    texte_narrat=can1.create_text(200,970,text="trouve un moyen de monter la paroie",font=("Arial",18),fill="black")
    clavier=1
    can1.bind('<Key>',Clavier3)
    
def texte():
    """fais disparaitre le texte"""
    global texte_perso1,can1,texte_perso2
    can1.delete(texte_perso1)
    can1.delete(texte_perso2)

def fin():
    """image de fin"""
    global texte_narrat,can1
    can1.delete(texte_narrat)
    can1.destroy()
    can1=Canvas(Mafenetre,bg="white",width=1250,height=1250)
    can1.place(x=0,y=0)
    texte_narrat=can1.create_text(625,500,text="FIN",font=("Arial",70),fill="black")
    texte_fin=can1.create_text(220,950,text="created by Paul O, Romain E and Antoine G",font=("Arial",16),fill="black")
    
def echelle():
    """fait disparaitre l'echelle et modifie la 2eme map"""
    global compt_echelle,can1,ech,texte_narrat,texte_perso1
    compt_echelle=1
    can1.delete(ech2)
    can1.delete(texte_narrat)
    can1.delete(texte_perso1)
    texte_perso1=can1.create_text(625,70,text="ça pourrait servir pour monter une paroie",font=("Arial",18),fill="black")
    texte_narrat=can1.create_text(120,970,text="retourne dans la grotte",font=("Arial",18),fill="black")



#programme principal

can1.focus_set()  #focus sur le can1
can1.bind('<Key>',Clavier1)  #fonction clavier si touche enfoncée
Mafenetre.mainloop()


