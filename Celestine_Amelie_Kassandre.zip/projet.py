#creation d'une bitmap
#modules
from tkinter import *
import random
from pygame import mixer
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('750x750')
Mafenetre.title("La fabuleuse aventure de Mr Alliot")
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=750,height=750)
can1.place(x=0,y=0)
#musique
mixer.init()
mixer.music.load("music.mp3")
mixer.music.play(loops=4)
#creation des cases images
    #mobilier et accessoires
casechaise=PhotoImage(file="Chaise droite.gif")
caseordinateur=PhotoImage(file="ordinateur.gif")
casetablehaut=PhotoImage(file="Table haut.gif")
casetablebas=PhotoImage(file="Table bas.gif")
casetabledroite=PhotoImage(file="Table gauche.gif")
casetablegauche=PhotoImage(file="Table droite.gif")
casechaisegauche=PhotoImage(file="Chaise gauche.gif")
caseimprimante=PhotoImage(file="imprimante.gif")
casecafé=PhotoImage(file="café.gif")
casecasier=PhotoImage(file="casier.gif")
casebibliothèque=PhotoImage(file="bibliothèque.gif")
casecarton=PhotoImage(file="carton.gif")

    #murs
casemurdroit=PhotoImage(file="MurDroit.gif")
casemurgauche=PhotoImage(file="MurGauche.gif")
casemurhaut=PhotoImage(file="MurHinf.gif")
casemurbas=PhotoImage(file="MurHsup.gif")
casemurcoinbas=PhotoImage(file="MurCoinInfGauche.gif")
casemurcoinhaut=PhotoImage(file="MurCoinSupGauche.gif")
casemurcoinbasd=PhotoImage(file="MurCoinInfDroit.gif")
casemurcoinhautd=PhotoImage(file="MurCoinSupDroit.gif")
casecoinbasdroit=PhotoImage(file="coinbasdroit.gif")
casecoinbasgauche=PhotoImage(file="coinbasgauche.gif")
casecoinhautdroit=PhotoImage(file="coinhautdroit.gif")
casecoinhautgauche=PhotoImage(file="coinhautgauche.gif")

    #portes et fenêtres
casefenetre=PhotoImage(file="FenetreHInf.gif")
caseportesup=PhotoImage(file="PorteOuverteHsup.gif")
caseportesupcouloirduhaut=PhotoImage(file="PorteOuverteHsup.gif")
caseportesupcdi=PhotoImage(file="PorteOuverteHsup.gif")
caseporteinf=PhotoImage(file="PorteOuverteHinf.gif")
caseportespeciale=PhotoImage(file="PorteSpéciale.gif")    
caseportegauche=PhotoImage(file="PorteVGauche.gif")
caseportedroite=PhotoImage(file="PorteVdroite.gif")
caseporteinf=PhotoImage(file="PorteOuverteHinf.gif")
caseporteouvertedroite=PhotoImage(file="PorteOuverteVGauche.gif")
caseportefermésup=PhotoImage(file="PorteHSup.gif")
caseporteferméinf=PhotoImage(file="PorteHInf.gif")
portespecialeouverte=PhotoImage(file="PorteSpécialeOuverte.gif")


    #escaliers et ascenceur
caseascenseurhaut=PhotoImage(file="ascenseurfermé.gif")
caseascenseurbas=PhotoImage(file="ascenseurfermé.gif")

    #sols et case noire
casenoir=PhotoImage(file="noir.gif")
casesol=PhotoImage(file="solclasse.gif")
casesolcouloir=PhotoImage(file="sol.gif")

    #cases texte
quete=PhotoImage(file="quete.gif")
troupeaueleve=PhotoImage(file="troupeaueleves.gif")
oups=PhotoImage(file="oupscestferme.gif")
a=PhotoImage(file="1Ahtueslà.gif")
b=PhotoImage(file="2oùestlaclé.gif")
c=PhotoImage(file="3D-leconciergealaclé.gif")
d=PhotoImage(file="4A-j'yvais.gif")
e=PhotoImage(file="5D-pompomgirl.gif")
f=PhotoImage(file="6A-ok....gif")
g=PhotoImage(file="g.gif")
casegagnecombat=PhotoImage(file="gagné.gif")
caseperdcombat=PhotoImage(file="plusdevie.gif")
consigne=PhotoImage(file="consigne.gif")
consignecafe=PhotoImage(file="consignecafé.gif")
vousavezlacle=PhotoImage(file="consigneclé.gif")
fini=PhotoImage(file="pompomgirl.gif")

# début et cinématique
début=PhotoImage(file="début.gif")
image0=PhotoImage(file="0.gif")
image1=PhotoImage(file="1.gif")
image2=PhotoImage(file="2.gif")
image3=PhotoImage(file="3.gif")
    #personnages
        #adultes
concierge=PhotoImage(file="concierge.gif")
vieconcierge=1000
        #élèves
eleve1=PhotoImage(file="Eb1.gif")
eleve1gauche=PhotoImage(file="Eg1.gif")
eleve2=PhotoImage(file="Eb2.gif")
eleve2gauche=PhotoImage(file="Eg2.gif")
eleve2droite=PhotoImage(file="Ed2.gif")
eleve3=PhotoImage(file="Eb3.gif")
eleve3gauche=PhotoImage(file="Eg3.gif")
eleve3droite=PhotoImage(file="Ed3.gif")
eleve4=PhotoImage(file="Eb4.gif")
eleve4gauche=PhotoImage(file="Eg4.gif")

        #professeurs et concierge
            #Monsieur Alliot
d1=PhotoImage(file="d1.gif")
d2=PhotoImage(file="d2.gif")
d3=PhotoImage(file="d3.gif")
h1=PhotoImage(file="h1.gif")
h2=PhotoImage(file="h2.gif")
h3=PhotoImage(file="h3.gif")
b1=PhotoImage(file="b1.gif")
b2=PhotoImage(file="b2.gif")
b3=PhotoImage(file="b3.gif")
g1=PhotoImage(file="g1.gif")
g2=PhotoImage(file="g2.gif")
g3=PhotoImage(file="g3.gif")

vie=1000
cle="non"
conversation="non"
cinematique="non"
combat="non"
            #Monsieur Dupuy
Dupuy=PhotoImage(file="prof.gif")

            #Concierge


tab_droite=[d1,d2,d1,d3]
tab_haut=[h1, h2 ,h1, h3]
tab_gauche=[g1,g2,g1,g3]
tab_bas=[b1,b2,b1,b3]

compteur_de_pas=0

#creation de la matrice
L0=[51,4,4,4,1,4,4,1,4,4,1,4,9,4,52]
L1=[2,10,7,7,10,7,7,10,7,7,10,10,10,10,3]
L2=[2,10,10,10,10,10,10,10,10,10,10,10,10,10,3]
L3=[2,11,0,11,0,11,0,11,10,10,10,10,10,10,3]
L4=[2,12,0,12,0,12,0,12,10,10,10,10,10,7,3]
L5=[2,11,10,10,10,10,10,10,10,10,10,10,10,15,3]
L6=[2,12,10,10,10,10,10,10,10,10,10,10,10,10,3]
L7=[2,11,0,11,0,11,0,11,10,10,10,10,10,10,3]
L8=[2,12,0,12,0,12,0,12,10,10,10,11,10,10,3]
L9=[2,11,10,10,10,10,10,10,10,10,10,12,10,10,3]
L10=[2,12,10,10,10,10,10,10,10,10,10,10,10,10,3]
L11=[2,11,0,11,0,11,0,11,10,10,10,10,10,10,3]
L12=[2,12,0,12,0,12,0,12,10,10,10,10,10,10,3]
L13=[2,13,14,13,14,13,14,13,14,10,10,10,10,10,3]
L14=[53,5,5,5,5,5,5,5,5,5,5,41,5,5,54]
ma_matrice=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14]

M0=[6,51,4,4,1,4,4,1,4,4,52,6,6,6,6]
M1=[6,2,19,19,10,10,7,7,10,16,3,6,6,6,6]
M2=[6,2,10,10,10,10,10,10,10,16,3,6,6,6,6]
M3=[6,2,10,10,10,10,10,10,10,10,3,6,6,6,6]
M4=[6,2,10,0,13,14,13,14,15,10,17,4,4,4,52]
M5=[6,2,10,0,11,10,10,11,15,10,20,20,20,20,3]
M6=[6,2,10,0,12,10,10,12,15,10,10,10,50,10,3]
M7=[6,2,10,0,13,14,13,14,15,10,10,10,10,10,3]
M8=[6,2,10,0,10,10,10,10,10,10,18,5,8,5,54]
M9=[6,2,10,0,10,15,10,10,10,10,3,6,6,6,6]
M10=[6,2,10,10,10,10,10,0,10,15,3,6,6,6,6]
M11=[6,53,5,5,5,5,5,5,5,5,54,6,6,6,6]
M12=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
M13=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
M14=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]

ma_matrice2=[M0,M1,M2,M3,M4,M5,M6,M7,M8,M9,M10,M11,M12,M13,M14]

K0=[51,4,1,1,1,4,1,1,1,4,1,4,52,6,6]
K1=[2,23,23,7,7,7,7,7,7,7,0,10,3,6,6]
K2=[2,10,10,10,10,10,10,10,10,10,0,10,22,6,6]
K3=[21,10,10,10,10,10,10,10,10,10,10,10,17,4,52]
K4=[2,10,23,23,23,10,10,23,23,23,10,10,11,16,3]
K5=[2,10,10,10,10,10,10,10,10,10,10,10,12,10,3]
K6=[2,10,10,10,10,10,10,10,10,10,10,10,11,15,3]
K7=[2,10,23,23,23,10,10,23,23,23,10,49,12,10,3]
K8=[21,10,10,10,10,10,10,10,10,10,10,10,13,14,3]
K9=[2,10,10,10,10,10,10,10,10,10,10,10,10,10,3]
K10=[2,10,23,23,23,10,10,23,23,10,10,10,10,10,3]
K11=[2,10,10,10,10,10,10,10,10,10,10,23,23,23,3]
K12=[2,0,11,15,0,11,15,10,10,10,10,10,10,10,3]
K13=[2,0,12,15,0,12,15,10,10,10,10,10,10,15,3]
K14=[53,5,5,5,5,5,5,5,5,5,5,8,5,5,54]
ma_matrice3=[K0,K1,K2,K3,K4,K5,K6,K7,K8,K9,K10,K11,K12,K13,K14]

N0=[6,6,6,6,6,6,6,2,37,46,35,40,3,6,6]
N1=[6,6,6,6,6,6,6,2,28,28,28,28,22,6,6]
N2=[6,6,6,6,6,6,6,2,28,28,28,28,3,6,6]
N3=[6,6,6,6,6,6,6,21,28,28,28,28,3,6,6]
N4=[6,6,6,6,6,6,6,2,28,28,28,28,3,6,6]
N5=[51,4,4,4,25,4,4,29,28,28,28,28,31,6,6]
N6=[2,28,28,28,28,28,28,28,28,28,28,28,17,4,4]
N7=[2,28,28,28,28,28,28,28,28,28,28,28,28,28,48]
N8=[2,28,28,28,28,28,28,28,28,28,28,28,28,28,38]
N9=[53,5,5,5,5,5,5,5,5,5,30,28,28,28,36]
N10=[6,6,6,6,6,6,6,6,6,6,53,32,5,5,5]
N11=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
N12=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
N13=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
N14=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
ma_matrice4=[N0,N1,N2,N3,N4,N5,N6,N7,N8,N9,N10,N11,N12,N13,N14]

O0=[6,6,6,6,6,6,6,2,46,40,37,35,22,6,6]
O1=[6,6,6,6,6,6,6,2,28,28,28,28,3,6,6]
O2=[6,6,6,6,6,6,6,2,28,28,28,28,3,6,6]
O3=[6,6,6,6,6,6,6,21,28,28,28,28,3,6,6]
O4=[6,6,6,6,6,6,6,2,28,28,28,28,3,6,6]
O5=[4,4,4,34,4,42,4,29,28,28,28,28,3,6,6]
O6=[45,28,28,28,28,28,28,28,28,28,28,28,17,4,4]
O7=[39,28,28,28,28,28,28,28,28,28,28,28,28,28,47]
O8=[45,28,28,28,28,28,28,28,28,28,28,28,28,28,36]
O9=[5,5,5,32,5,5,5,5,5,5,30,28,28,28,38]
O10=[6,6,6,6,6,6,6,6,6,6,53,32,5,5,5]
O11=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
O12=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
O13=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
O14=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
ma_matrice5=[O0,O1,O2,O3,O4,O5,O6,O7,O8,O9,O10,O11,O12,O13,O14]

R0=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
R1=[6,6,51,4,4,4,4,4,4,4,4,4,52,6,6]
R2=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R3=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R4=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R5=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R6=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R7=[6,6,2,10,10,10,10,44,44,10,10,10,3,6,6]
R8=[6,6,2,10,10,10,10,10,44,10,10,10,3,6,6]
R9=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R10=[6,6,21,10,10,10,10,10,10,10,10,10,3,6,6]
R11=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R12=[6,6,2,10,10,10,10,10,10,10,10,10,3,6,6]
R13=[6,6,53,5,5,5,5,5,5,5,5,5,54,6,6]
R14=[6,6,6,6,6,6,6,6,6,6,6,6,6,6,6]
ma_matrice6=[R0,R1,R2,R3,R4,R5,R6,R7, R8,R9,R10,R11,R12,R13,R14]

matrice_utilisee=ma_matrice

#creation de la map
dico={0:casechaise, 1:casefenetre, 2:casemurdroit, 3:casemurgauche, 4:casemurhaut, 5:casemurbas, 6:casenoir, 7:caseordinateur, 8:caseportesup, 9:caseportespeciale, 10:casesol, 11:casetablehaut, 12:casetablebas, 13:casetabledroite, 14:casetablegauche, 15:casechaisegauche, 16:caseimprimante ,17:casemurcoinbas , 18:casemurcoinhaut, 19:casecafé, 20:casecasier, 21:caseportedroite, 22:caseportegauche, 23:casebibliothèque, 24:caseporteinf ,25:caseascenseurhaut ,28:casesolcouloir,29:casemurcoinbasd ,30:casemurcoinhautd, 31:caseporteouvertedroite,32:caseportefermésup, 33:caseporteferméinf, 34:caseporteinf, 35:eleve1, 36:eleve1gauche, 37:eleve2, 38:eleve2gauche, 39:eleve2droite, 40:eleve3, 41:caseportesupcouloirduhaut,42:caseascenseurbas,43:caseportesupcdi,44:casecarton,45:eleve3droite,46:eleve4,47:eleve4gauche,48:eleve3gauche,49:concierge, 50: Dupuy, 51:casecoinbasdroit, 52:casecoinbasgauche, 53: casecoinhautdroit, 54:casecoinhautgauche, 55:portespecialeouverte}

for i in range(len(matrice_utilisee[0])):
    for j in range(len(matrice_utilisee)):
        can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")


#position du personnage
posX=500 #abscisse de départ
posY=250 #ordonnée de départ
perso=can1.create_image(posX,posY,image=b1,anchor="nw",tag="perso")
posXmessage=0
posYmessage=550
posXmenu=0
posYmenu=0
X=150
X2=150
X3=150
Y=300
Y2=300
Y3=300

can1.create_image(150,300,image=quete, anchor="nw", tag="message")
can1.create_image( 0,0,image=début, anchor="nw",tag="menu")
    
autorise=[8, 10, 24, 25, 27, 28, 26, 31,34,55]
eleves=[35,36,37,38,39,40,45,46,47,48]

def Clavier(event):
    """récupère l'information tapée sur le clavier"""
    global posX, posY,compteur_de_pas, matrice_utilisee, ma_matrice4, perso, ma_matrice, ma_matrice2, ma_matrice3, ma_matrice5, ma_matrice6, posXmessage, posYmessage, vie, vieconcierge, cle, X, Y, X2, Y2, X3, Y3, conversation, cinematique, combat
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    count=0
    
    if touche=="Return" and cinematique=="non":
        cinematique="oui"
        can1.after(0000,functionz)
    
    if touche=="x" and matrice_utilisee[ligne-1][colonne]==49:
        combat="oui"
        if vie>0 :
            textedamage=can1.create_text(305,280, text="", font=("Arial", 14),tag="textedamage")
            can1.delete("textedamage")
        if vie>0 :
            vieconcierge-=random.randint(150,200)
            if vieconcierge>0 :
                vie-=random.randint(200,270)
            if vie<0 :
                vie=0
                can1.create_image(150,300,image=caseperdcombat, anchor="nw", tag="message")
                can1.delete("textedamage")
            if vieconcierge<=0 :
                vieconcierge=0
                can1.create_image(150,300,image=casegagnecombat, anchor="nw", tag="message")
                cle="oui"
                ma_matrice3[7][11]=10
            textedamage=can1.create_text(50,250, text="Vous avez donné un coup de sac au concierge.\n Le concierge vous a répondu avec un mouvement expert de \n judoka. Il vous reste "+str(vie)+" points de vie. Il reste au concierge "+str(vieconcierge)+" \n points de vie.", font=("Arial", 14), tag="textedamage", fill="black", anchor= "nw")
    
    if matrice_utilisee[ligne-1][colonne]==19 and combat=="oui":
        can1.create_image(X2,Y2,image=consignecafe, anchor="nw", tag="message")
        can1.after(5000,reset2)
        if touche=="x":
            vie=1000
            can1.create_text(100,150, text="+1000pts", font=("Arial", 14), tag="caf", fill="black", anchor= "nw")
            can1.after(800,reset4)
        
    if touche=="x" and matrice_utilisee[ligne-1][colonne]==9 :
        ma_matrice[0][12]=55
        for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
        perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        
    if matrice_utilisee==ma_matrice:
        if cle=="oui":
            can1.create_image(X3,Y3,image=vousavezlacle, anchor="nw", tag="message")
            can1.after(4000,reset3)
    
    
    if touche=="Up" :
        can1.itemconfig(perso,image=tab_haut[compteur_de_pas%4])
        compteur_de_pas+=1
        if matrice_utilisee[ligne-1][colonne] in autorise and matrice_utilisee[6][12]!=50:
            mvt_haut() 
        if matrice_utilisee[ligne-1][colonne]==25 : 
            matrice_utilisee=ma_matrice5
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=250
            posY=300
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        if matrice_utilisee[ligne-1][colonne]==42 : 
            matrice_utilisee=ma_matrice4
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=200 
            posY=300
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        if matrice_utilisee[ligne-1][colonne]==34 : 
            matrice_utilisee=ma_matrice2
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=600
            posY=350
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        
        if matrice_utilisee[ligne-1][colonne]==55 : 
            matrice_utilisee=ma_matrice6 
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=150  
            posY=500 
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
            can1.after(1000, fin)
        if matrice_utilisee[ligne-1][colonne]==49 :
            can1.create_image(X,Y,image=consigne, anchor="nw", tag="message")
            can1.after(4000,reset)
            
    if touche=="Down" :
        can1.itemconfig(perso,image=tab_bas[compteur_de_pas%4])
        compteur_de_pas+=1
        if matrice_utilisee[ligne+1][colonne] in autorise and matrice_utilisee[6][12]!=50:
            mvt_bas()
        if matrice_utilisee[ligne+1][colonne]==41 : 
            matrice_utilisee=ma_matrice4
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=550
            posY=250
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        if matrice_utilisee[ligne+1][colonne]==8 and matrice_utilisee[6][12]!=50:
            matrice_utilisee=ma_matrice5
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=150
            posY=350
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        if matrice_utilisee[ligne+1][colonne]==43:
            matrice_utilisee=ma_matrice3
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=550
            posY=650
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
            
    if touche=="Right" :
        can1.itemconfig(perso,image=tab_droite[compteur_de_pas%4])
        compteur_de_pas+=1
        if matrice_utilisee[ligne][colonne+1] in autorise and matrice_utilisee[6][12]!=50:
            mvt_droite()
        if matrice_utilisee[ligne][colonne+1]==31 : 
            matrice_utilisee=ma_matrice
            for i in range(len(matrice_utilisee[0])):
                for j in range(len(matrice_utilisee)):
                    can1.create_image(50*j,50*i,image=dico[matrice_utilisee[i][j]],anchor="nw")
            posX=550
            posY=650
            perso=can1.create_image(posX,posY,image=b1,anchor="nw")
        
    if touche=="Left" :
        can1.itemconfig(perso,image=tab_gauche[compteur_de_pas%4])
        compteur_de_pas+=1
        if  matrice_utilisee[ligne][colonne-1] in autorise and matrice_utilisee[6][12]!=50:
            mvt_gauche()
            
    if matrice_utilisee[ligne+1][colonne] in eleves:
            can1.create_image(posXmessage,posYmessage,image=troupeaueleve, anchor="nw", tag="message")
                
    if matrice_utilisee[ligne-1][colonne] in eleves:
            can1.create_image(posXmessage,posYmessage,image=troupeaueleve, anchor="nw", tag="message")
           
    if matrice_utilisee[ligne][colonne-1] in eleves:
            can1.create_image(posXmessage,posYmessage,image=troupeaueleve, anchor="nw", tag="message")
            
    if matrice_utilisee[ligne][colonne+1] in eleves:
            can1.create_image(posXmessage,posYmessage,image=troupeaueleve, anchor="nw", tag="message")

    if matrice_utilisee[ligne-1][colonne]==9: 
            can1.create_image(posXmessage,posYmessage,image=oups, anchor="nw", tag="message")
        
    if touche=="space":
         can1.delete("message")
    
    if matrice_utilisee==ma_matrice2:
        if ma_matrice2[6][12]==50 and conversation=="non":
            can1.create_image(posXmessage,posYmessage,image=g, anchor="nw", tag="dialogue")
            if touche=="Return" :
                conversation="oui"
                can1.delete("g")
                can1.after(0000,afunction)  
                ma_matrice5[9][3]=43
def afunction():
    can1.create_image(posXmessage,posYmessage,image=a, anchor="nw", tag="dialogue")    
    can1.after(3000,bfunction)         
def bfunction():
    global can1, b, posXmessage, posYmessage
    can1.create_image(posXmessage,posYmessage,image=b, anchor="nw", tag="dialogue") 
    can1.after(6000,cfunction)           
def cfunction():
    global can1, c, posXmessage, posYmessage
    can1.create_image(posXmessage,posYmessage,image=c, anchor="nw", tag="dialogue")
    can1.after(6000,dfunction)
def dfunction():
    global can1, d, posXmessage, posYmessage
    can1.create_image(posXmessage,posYmessage,image=d, anchor="nw", tag="dialogue")
    can1.after(6000,efunction)
def efunction():
    global can1, e, posXmessage, posYmessage
    can1.create_image(posXmessage,posYmessage,image=e, anchor="nw", tag="dialogue") 
    can1.after(6000,ffunction)
def ffunction():
    global can1, f, posXmessage, posYmessage
    can1.create_image(posXmessage,posYmessage,image=f , anchor="nw", tag="dialogue")
    can1.after(2000,finish)
def finish():
    can1.delete("dialogue")
    ma_matrice2[6][12]=10
    
def functionz():
    global can1, image0, posXmenu, posYmenu
    can1.create_image(posXmenu,posYmenu,image=image0, anchor="nw", tag="menu")    
    can1.after(4000,functionu)         
def functionu():
    global can1, image1, posXmenu, posYmenu
    can1.create_image(posXmenu,posYmenu,image=image1, anchor="nw", tag="menu") 
    can1.after(6000,functiond)           
def functiond():
    global can1, image2, posXmenu, posYmenu
    can1.create_image(posXmenu,posYmenu,image=image2, anchor="nw", tag="menu")
    can1.after(9000,functiont)
def functiont():
    global can1, image3, posXmenu, posYmenu
    can1.create_image(posXmenu,posYmenu,image=image3, anchor="nw", tag="menu")
    can1.after(9000,functionq)
def functionq():
    global can1, posXmenu, posYmenu
    can1.delete("menu")
    posXmenu=-750
    posYmenu=-750
    
def fin():
    global can1, fin
    can1.create_image(0,0,image=fini, anchor="nw")
    
                          
def reset():
    global can1, X, Y
    X=-750
    Y=-750
    can1.delete("message") 

def reset2():
    global can1, X2, Y2
    X2=-750
    Y2=-750
    can1.delete("message") 

def reset3():
    global can1, X3, Y3
    X3=-750
    Y3=-750
    can1.delete("message")  

def reset4():
    global can1
    can1.delete("caf")        
        
def mvt_gauche():
    """déplace le perso vers la gauche"""
    global perso,posX,posY,compteur_de_pas
    posX-=50
    if posX<0:
        posX=0
    can1.coords(perso,posX,posY)

def mvt_haut():
    """déplace le perso vers le haut"""
    global perso,posY, posX
    posY-=50
    if posY<0:
        posY=0
    can1.coords(perso,posX,posY)
    
def mvt_bas():
    """déplace le perso vers le bas"""
    global perso,posY, posX
    posY+=50
    if posY>700:
        posY=700
    can1.coords(perso,posX,posY)

        
def mvt_droite():
    """déplace le perso vers la droite"""
    global perso,posX,posY, compteur_de_pas
    posX+=50
    if posX>700:
        posX=700
    can1.coords(perso,posX,posY)
        
   
        
#programme principal
can1.focus_set()
can1.bind('<Key>',Clavier)
Mafenetre.mainloop()
mixer.music.stop()