##################################################################
#                                                                #
#                        Projet Final Spé NSI                    #  
#                                                                #
#                    M.ANGER, P-L.BARDON, J.BESTARD              #
#                                                                #
#                          THE LAST RALPH                        #
#                                                                #
##################################################################

##########################################
#                                        #
# Importations des modules nécessaires   #
#                                        #
##########################################

from tkinter import *
import random
import time
from pygame import mixer

############################
#                          #
#  Création de la fenêtre  #
#                          #
############################

Mafenetre = Tk()
Mafenetre.geometry('500x500')

############################
#                          #
# Définition des fonctions #
#                          #
############################

def CallAnimPerso():
    """Fonction qui permet l'appelle de la fonction AnimPerso : Elle sert à éviter les bugs d'affichages"""
    global AP
    AP = niv.after(200,AnimPerso)

def AnimPerso():
    """Fonction qui permet l'affichage d'un effet de respiration sur Ralph, le personnage principal"""
    global compt_anim,AP,compt_niv
    if compt_anim==0:
            niv.itemconfig(perso,image=RalphGaucheAFK0)
            compt_anim+=1
            AP = niv.after(750,AnimPerso)
            
    elif compt_anim==1:
            niv.itemconfig(perso,image=RalphGaucheAFK1)
            compt_anim+=1
            AP = niv.after(750,AnimPerso)
            
    elif compt_anim==2:
            niv.itemconfig(perso,image=RalphGaucheAFK2)
            compt_anim+=1
            AP = niv.after(750,AnimPerso)

    elif compt_anim==3:
            niv.itemconfig(perso,image=RalphGaucheAFK1)
            compt_anim=0
            AP = niv.after(750,AnimPerso)

#Fonctions Ennemies

def ApparitionEnnemies():
    """Fonction qui permet de créer les ennemies au Stage 2"""
    global PosEnnemies, ListeEnnemies,nbre_ennemies, ListeX,niv
    
    if nbre_ennemies!=3:
        posXE = random.randrange(50,800,50)
        posYE = random.randrange(50,450,50)
        
        if posXE != 200 and posXE != 500 and posXE != 550 and posXE != 750 and posXE != 800:
            
            if posXE in ListeX:
                ApparitionEnnemies()  
                
            else :
                Im = random.randint(0,1)
                
                if Im==0:
                    i = Ennemi1
                if Im==1:
                    i = Ennemi2
                    
                ListeX.append(posXE)
                tuplePos=[posXE,posYE]
                ListeEnnemies.append(niv.create_image(posXE,posYE,image=i,anchor="nw"))
                PosEnnemies.append(tuplePos)
                nbre_ennemies+=1
                ApparitionEnnemies()
        else :
            ApparitionEnnemies()
            
            
#Les 3 fonctions suivantes permettent l'animation des ennemies verticalement
def AnimationEnnemies1():       
    global ListeEnnemies, PosEnnemies, i1, AE1, niv
    posXE=PosEnnemies[0][0]
    posYE= PosEnnemies[0][1] 
    
    if posYE==50:
        i1 = (+50)
    if posYE==400:
        i1 = (-50)
        
    posYE+=i1
    PosEnnemies[0][1]=posYE
    niv.coords(ListeEnnemies[0],posXE,posYE)
    AE1 = niv.after(750,AnimationEnnemies1)

def AnimationEnnemies2():       
    global ListeEnnemies, PosEnnemies, i2, AE2, niv
    posXE= PosEnnemies[1][0]
    posYE= PosEnnemies[1][1] 
    
    if posYE==50:
        i2 = (+50)
    if posYE==400:
        i2 = (-50)
        
    posYE+=i2
    PosEnnemies[1][1]=posYE
    niv.coords(ListeEnnemies[1],posXE,posYE)
    AE2 = niv.after(750,AnimationEnnemies2)

def AnimationEnnemies3():       
    global ListeEnnemies, PosEnnemies, i3, AE3, niv
    posXE=PosEnnemies[2][0]
    posYE= PosEnnemies[2][1]  
    
    if posYE==50:
        i3 = (+50)
    if posYE==400:
        i3 = (-50)
        
    posYE+=i3
    PosEnnemies[2][1]=posYE
    niv.coords(ListeEnnemies[2],posXE,posYE)
    AE3 = niv.after(750,AnimationEnnemies3)

#Fonction d'attaque
    
def FonctionUp():
    """Fonction qui permet d'envoyer la flèche vers le haut"""
    global posXF,posYF, Arrow, niv, AF
    posXF, posYF = niv.coords(Arrow)
    posYF-=25
    niv.coords(Arrow,posXF,posYF)
    AF = niv.after(30,AnimationTir)

def FonctionDown():
    """Fonction qui permet d'envoyer la flèche vers le bas"""
    global posXF,posYF, Arrow, niv, AF
    posXF, posYF = niv.coords(Arrow)
    posYF+=25
    niv.coords(Arrow,posXF,posYF)
    AF = niv.after(30,AnimationTir)

def FonctionRight():
    """Fonction qui permet d'envoyer la flèche vers la droite"""
    global posXF,posYF, Arrow, niv, AF
    posXF, posYF = niv.coords(Arrow)
    posXF+=25
    niv.coords(Arrow,posXF,posYF)
    AF = niv.after(30,AnimationTir)

def FonctionLeft():
    """Fonction qui permet d'envoyer la flèche vers la gauche"""
    global posXF,posYF, Arrow, niv, AF
    posXF, posYF = niv.coords(Arrow)
    posXF-=25
    niv.coords(Arrow,posXF,posYF)
    AF = niv.after(30,AnimationTir)

dicoFonctFleche={'Up':FonctionUp,'Down':FonctionDown,'Right':FonctionRight,'Left':FonctionLeft} #Dico qui regroupe les 4 fonctions précédentes pour éviter l'accumulation de if, elif ...

def Tirer():
    """Fonction qui va permettre à Ralph de tirer une flèche"""
    global DerniereToucheDepl, toucheDepl, compt_niv, niv, ListeEnnemies, PosEnnemies, tir, Arrow, posXB, posYB, boss, AP, AF
    niv.after_cancel(AP)
    
    if tir == 1:
        niv.after_cancel(AP)
        niv.delete(Arrow)
        niv.after_cancel(AF)
        tir=0
        Tirer()   
        
    if tir==0:
        toucheDepl = DerniereToucheDepl
        
        if toucheDepl=='Up':
            posXF=posX
            posYF=posY-50
            imageF=Fleche[0]
            
        elif toucheDepl=='Down':
            posXF=posX
            posYF=posY+50
            imageF=Fleche[2]
            
        elif toucheDepl=='Right':
            niv.itemconfig(perso,image=RalphDroiteTir)
            posXF=posX+50
            posYF=posY
            imageF=Fleche[1]
            
        elif toucheDepl=='Left':
            niv.itemconfig(perso,image=RalphGaucheTir)
            posXF=posX-50
            posYF=posY
            imageF=Fleche[3]
            
        Arrow = niv.create_image(posXF,posYF,image=imageF,anchor="nw")
        tir=1
        AP = niv.after(750,AnimPerso)
        AF = niv.after(0,AnimationTir)

def AnimationTir():
    """Fonction qui anime la flèche"""
    global compt_niv, PosEnnemi, posXF, posYF, Arrow, toucheDepl, ListeEnnemies, tir, AE1,AE2,AE, posXB, posYB, NbreVieBoss, AB, nbre_ennemies, ListePillierPerso
    global dicoFonctFleche, ListeArbre
    
    posXF, posYF = niv.coords(Arrow)
    
    if PosEnnemies!=[]:
        posXE1= PosEnnemies[0][0]
        posYE1= PosEnnemies[0][1]
        posXE2= PosEnnemies[1][0]
        posYE2= PosEnnemies[1][1]
        posXE3= PosEnnemies[2][0]
        posYE3= PosEnnemies[2][1]
        
        if posXF == posXE1 and posYF == posYE1:
                niv.delete(ListeEnnemies[0])
                niv.after_cancel(AE1)
                niv.delete(Arrow)
                PosEnnemies[0][0],PosEnnemies[0][1]=0,0
                nbre_ennemies-=1
                tir=0
                
        elif posXF == posXE2 and posYF == posYE2:
                niv.delete(ListeEnnemies[1])
                niv.after_cancel(AE2)
                niv.delete(Arrow)
                PosEnnemies[1][0],PosEnnemies[1][1]=0,0
                nbre_ennemies-=1
                tir=0            
                
        elif posXF == posXE3 and posYF == posYE3:
                niv.delete(ListeEnnemies[2])
                niv.after_cancel(AE3)
                niv.delete(Arrow)
                PosEnnemies[2][0],PosEnnemies[2][1]=0,0
                nbre_ennemies-=1
                tir=0
                
        else :            
            
            if posXF>=50 and posXF<=850:
                if posYF>=50 and posYF<=450:
                    
                    dicoFonctFleche[toucheDepl]()
                else :
                    niv.delete(Arrow)
            else :
                niv.delete(Arrow)    
                
    elif map[compt_niv]==map[4]:        
       
        if posXF==posXB and posYF==posYB:
            
            if NbreVieBoss!=0:
                niv.after_cancel(AB)
                niv.delete(Arrow)
                NbreVieBoss-=1
                
                textVieBoss = ("Vie du Boss : " + str(NbreVieBoss))
                
                niv.itemconfig(Affichage_VieBoss,text=textVieBoss)
                
                print(NbreVieBoss)
                tir=0
                AB = niv.after(500,AnimationBoss)
                
            elif NbreVieBoss==0 :         
                niv.delete(boss)
                niv.after_cancel(AB)
                niv.delete(Arrow)
                tir=0
                
                niv.after(2000,Win)
                
        else:
            if posXF>=50 and posXF<=850:
                if posYF>=50 and posYF<=450:
                    
                    tuplePos=(posXF,posYF)
                    
                    if tuplePos in ListePillierPerso:
                        niv.delete(Arrow)
                    else :
                        dicoFonctFleche[toucheDepl]()
    else:        
        
        if posXF>=50 and posXF<=850:
            if posYF>=50 and posYF<=450:
                
                tuplePos=(posXF,posYF)
                   
                if tuplePos in ListeArbre:
                    niv.delete(Arrow)
                else:
                    dicoFonctFleche[toucheDepl]()
            else :
                niv.delete(Arrow)
        else :
            niv.delete(Arrow)   

#Fonction du Boss final

def AnimationBoss():
    """Fonction qui anime le boss de la même façon que la fonction pour les ennemies du stage 2"""
    global iB, boss, AB, posXB, posYB, NbreVieBoss, posX, posY, projectile, ProjBoss, niv, compt_pas_boss, Tab_HautBasBoss, APB
    
    posXB, posYB = niv.coords(boss)
    niv.itemconfig(boss,image=Tab_HautBasBoss[compt_pas_boss]) 
    compt_pas_boss+=1
        
    if compt_pas_boss==2:
        compt_pas_boss=0    
    
    if posY==posYB:
        niv.itemconfig(boss,image=BossTir,anchor="nw")   
        APB = niv.after(0,ProjectileBoss)
        
    else:
        
        if posYB == 50:
            iB = (+50)
        if posYB == 400:
            iB = (-50)
        
        posYB+=iB
        niv.coords(boss,posXB,posYB)
        AB = niv.after(550,AnimationBoss)

def ProjectileBoss():
    """Fonction qui anime le projectile lancer par le boss de la même façon que l'animation de la flèche"""
    global posXB, posYB, posXP, posYP, ProjBoss, TirBoss, AP, NbreViePerso, AP, Perso, AB, niv, Affichage_ViePerso, textVieJoueur, DebutJeu, ListePillier, APB
    
    niv.after_cancel(AB)    
    
    if TirBoss==0:
        posXP = posXB
        posYP = posYB        
        ProjBoss = niv.create_image(posXP,posYP,image=Projectile,anchor="nw")        
        TirBoss=1
        APB = niv.after(20,ProjectileBoss)
    
    if TirBoss==1 :
        
        posXP, posYP = niv.coords(ProjBoss)
        
        if posXP==posX and posYP==posY:
            if NbreViePerso!=0:
                
                niv.after_cancel(AP)
                niv.delete(ProjBoss)
                niv.after_cancel(APB)
                NbreViePerso-=1
                
                textVieJoueur = ("Vie du joueur : " + str(NbreViePerso))
                niv.itemconfig(Affichage_ViePerso,text=textVieJoueur)
                
                TirBoss=0
                AP = niv.after(500,AnimPerso)
                AB = niv.after(400,AnimationBoss)
            
            elif NbreViePerso==0:
                           
                niv.after_cancel(APB)
                niv.delete(ProjBoss)
                niv.delete(perso)
                TirBoss=0
                
                GameOver()
                
        elif posXP>=50 and posXP<=850:
                if posYP>=50 and posYP<=450:
                    
                    tuplePos = (posXP,posYB)

                    if tuplePos in ListePillierBoss :
                        niv.delete(ProjBoss)   
                        niv.after_cancel(APB)
                        AB = niv.after(400,AnimationBoss)
                        TirBoss=0
                        
                    else :
                        posXP+=25
                        niv.coords(ProjBoss,posXP,posYP)
                        APB = niv.after(45,ProjectileBoss)
        else :
            niv.delete(ProjBoss)   
            niv.after_cancel(APB)
            AB = niv.after(400,AnimationBoss)
            TirBoss=0


#fonction concernant le mouvement

def Clavier(event):
    global posX,posY,compt_niv,touche, DerniereToucheDepl, DebutJeu, nbre_ennemies
    """event variable qui a récupéré l'information tapée au Clavier"""
    touche=event.keysym
    ligne = posY//50
    colonne = posX//50
    
    niv.after_cancel(AP)  
    
    if touche =='Down' and posX==250 and posY==400 and map[compt_niv]==map[1] and DebutJeu==1:
        DerniereToucheDepl=touche
        Stage1bis()  
    
    if touche=='Up'and posY>50 :
        if map[compt_niv]==map[0]:
            if map[compt_niv][ligne-1][colonne]!=5 and map[compt_niv][ligne-1][colonne]!=3 :
                if map[compt_niv][ligne-1][colonne]!=7 and map[compt_niv][ligne-1][colonne]!=8 and map[compt_niv][ligne-1][colonne]!=9:
                    DerniereToucheDepl=touche
                    haut()
        elif map[compt_niv]==map[1]:
            if map[compt_niv][ligne-1][colonne]!=10:
                DerniereToucheDepl=touche
                haut()
        elif map[compt_niv]==map[3]:
            if map[compt_niv][ligne-1][colonne]==1:
                DerniereToucheDepl=touche
                haut()
        elif map[compt_niv]==map[4]:
            if map[compt_niv][ligne-1][colonne]==1:
                DerniereToucheDepl=touche
                haut()
        
    if touche=='Right'and posX<900:
        if map[compt_niv]==map[0]:
            if map[compt_niv][ligne][colonne+1]!=5:
                if map[compt_niv][ligne][colonne+1]!=7 and map[compt_niv][ligne][colonne+1]!=8 and map[compt_niv][ligne][colonne+1]!=9:
                    DerniereToucheDepl=touche
                    droite()
        elif map[compt_niv]==map[1]:
            if map[compt_niv][ligne][colonne+1]!=10 and map[compt_niv][ligne][colonne+1]!=9:
                DerniereToucheDepl=touche
                droite()
        elif map[compt_niv]==map[3]:
            if map[compt_niv][ligne][colonne+1]==1:
                DerniereToucheDepl=touche
                droite()
        elif map[compt_niv]==map[4]:
            if map[compt_niv][ligne][colonne+1]!=3 and map[compt_niv][ligne][colonne+1]==1:
                DerniereToucheDepl=touche
                droite()
        
    if touche=='Left':
        if map[compt_niv]==map[0]:
            if map[compt_niv][ligne][colonne-1]!=5 and map[compt_niv][ligne][colonne-1]!=3 and map[compt_niv][ligne][colonne-1]!=2:
                if map[compt_niv][ligne][colonne-1]!=7 and map[compt_niv][ligne][colonne-1]!=8 and map[compt_niv][ligne][colonne-1]!=9:
                    DerniereToucheDepl=touche
                    gauche()
        elif map[compt_niv]==map[1]:
            if map[compt_niv][ligne][colonne-1]!=10 and map[compt_niv][ligne][colonne-1]!=9:
                DerniereToucheDepl=touche
                gauche()
        elif map[compt_niv]==map[3]:
            if map[compt_niv][ligne][colonne-1]==1:
                DerniereToucheDepl=touche
                gauche()
        elif map[compt_niv]==map[4]:
            if posX>100 and map[compt_niv][ligne][colonne-1]==1:
                DerniereToucheDepl=touche
                gauche()

    if touche=='Down'and posY<400 :
        if map[compt_niv]==map[0]:
            if map[compt_niv][ligne+1][colonne]!=5 and map[compt_niv][ligne+1][colonne]!=3:
                if map[compt_niv][ligne+1][colonne]!=7 and map[compt_niv][ligne+1][colonne]!=8 and map[compt_niv][ligne+1][colonne]!=9:
                    DerniereToucheDepl=touche
                    bas()
        elif map[compt_niv]==map[1]:
            if map[compt_niv][ligne+1][colonne]!=10:
                DerniereToucheDepl=touche
                bas()
        elif map[compt_niv]==map[3]:
            if map[compt_niv][ligne+1][colonne]==1:
                DerniereToucheDepl=touche
                bas()
        elif map[compt_niv]==map[4]:
            if map[compt_niv][ligne+1][colonne]==1:
                DerniereToucheDepl=touche
                bas()
    
    if touche=='Control_R' and map[compt_niv]==map[0] and map[compt_niv]==map[2] and map[compt_niv][ligne][colonne]==1:
        StageMaison()
    
    if touche=='Control_R' and map[compt_niv]==map[1] and posX==250 and posY==100:
        InteractionPNJ()
        
    if touche=='Left' and DebutJeu==1 and map[compt_niv]==map[2] and posX==0 and posY==300:
        Stage2()
    
    if touche=='Left' and nbre_ennemies==0 and map[compt_niv]==map[3] and posX==0 and posY==50:
        Stage3()
    
    if touche=='a':
        Tirer()

def AdoySpeak():
    """Permet de faire parler notre PNJ Adoy"""
    global channel2, TexteAdoy, channel1
    channel1.set_volume(0.01)
    channel2.play(TexteAdoy)
    

def InteractionPNJ():
    """Fait apparaître le texte de Adoy"""
    global i,x,y,t,DebutJeu, TexteAdoy, channel1,niv

    if t == 100:
        AdoySpeak() 
        t=0
        niv.after(50,InteractionPNJ)
        
    if t<11: #<10 pour éviter les messages d'erreurs
        texte = ["ADOY : Bien le bonjour jeune Aventurier,;","je devine que tu es la pour ma quete !;","Il y a quelque mois maintenant,;","un apprenti de l'ancien Thanos,;","a recree son oeuvre.;",
    		"Il a tue tout ton peuple...;","Et vole tout mes meubles !!;","Ton but : l'aneantir ;", "Et annuler le sort des tes confreres.;","Plus, si possible,;","Ramener mes meubles !;"]
        
        script=niv.create_text(x,y, text="", font=('8_bit_1_6',8), fill="black", justify ='right')
        niv.coords(script,x,y)
        niv.itemconfig(script,text=(texte[t][i]))
        x+=8
        i+=1
        if t==10 and texte[10][i]==texte[10][20]:
            DebutJeu=1
            channel1.set_volume(0.04)   
        elif texte[t][i]==';':
            i=0
            t+=1
            x=621
            y+=10
            niv.after(100,InteractionPNJ)
        else : 
            niv.after(100,InteractionPNJ)

#Déplacements
def haut():
    """deplacement du perso vers le haut"""
    global posX,posY,niv1, compt_pas_Hor, Tab_Gauche,compt_niv,AP,compt_anim
    posY=posY-50
    niv.itemconfig(perso,image=Tab_Haut[compt_pas_Hor])
    compt_pas_Hor+=1
    compt_anim = 0
    if compt_pas_Hor==2:
        compt_pas_Hor=0
    if posY<0:
        posY=0  
    niv.coords(perso,posX,posY)
    AP = niv.after_idle(CallAnimPerso)

def droite():
    """deplacement du perso vers la droite"""
    global posX,posY,niv1, compt_pas_Vert, Tab_Droite,compt_niv,AP,compt_anim
    posX=posX+50
    niv.itemconfig(perso,image=Tab_Droite[compt_pas_Vert])
    compt_pas_Vert+=1
    compt_anim = 0
    if compt_pas_Vert==4:
        compt_pas_Vert=0   
    niv.coords(perso,posX,posY)
    AP = niv.after_idle(CallAnimPerso)

def gauche():
    """deplacement du perso vers la gauche"""
    global posX,posY,niv1, compt_pas_Vert, Tab_Gauche,compt_niv,AP,compt_anim
    posX=posX-50
    niv.itemconfig(perso,image=Tab_Gauche[compt_pas_Vert])
    compt_pas_Vert+=1
    compt_anim = 0
    if compt_pas_Vert==4:
        compt_pas_Vert=0
    niv.coords(perso,posX,posY)
    AP = niv.after_idle(CallAnimPerso)
    
def bas():
    """deplacement du perso vers le bas"""
    global posX,posY,niv1, compt_pas_Hor, tab_monte,compt_niv,AP,compt_anim 
    posY=posY+50
    niv.itemconfig(perso,image=Tab_Bas[compt_pas_Hor])
    compt_pas_Hor+=1
    compt_anim = 0
    if compt_pas_Hor==2:
        compt_pas_Hor=0
    niv.coords(perso,posX,posY)
    AP = niv.after_idle(CallAnimPerso)

#Fonction pour changer de niveau
def Intro():
    """Premier canvas de notre jeu"""
    global compt_niv,niv, song
    niv=Canvas(Mafenetre,height=500,width=500)
    niv.create_image(0,0,image=Fond,anchor="nw")
    niv.pack()
    compt_niv=0
    Button(niv,text="New game",font=("8_bit_1_6",12),anchor=CENTER,command=Stage1).place(relx=0.5, y=435, anchor=CENTER)
    Button(niv,text="Quit",font=("8_bit_1_6",12),anchor=CENTER,command=Quit).place(relx=0.5, y=465, anchor=CENTER)

def Stage1():
    """Affichage du premier niveau de notre jeu"""
    global AP,niv, dico, perso, Arrow, posXF, posX, posYF, posY
    niv.destroy()
    Mafenetre.geometry('950x500')
    niv=Canvas(Mafenetre,bg='white',height=500,width=950)
    for i in range(10):
        for j in range(19):
            niv.create_image(50*j,50*i,image=dico[map1[i][j]],anchor="nw")
    Fleurs()
    posX=900  #abscisse de départ
    posY=100 #ordonnéez de départ
    perso=niv.create_image(posX,posY,image=RalphGauche,anchor="nw") 
    niv.pack()
    niv.focus_set()
    AP = niv.after(0,AnimPerso)
    niv.bind('<Key>',Clavier)

def Stage1bis():
    """Affichage du premier niveau de notre jeu mais en sortant ADOY"""
    global compt_niv, posX, posY,perso,AP,niv
    niv.after_cancel(AP)
    niv.destroy()
    compt_niv=2
    niv=Canvas(Mafenetre,bg='white',height=500,width=950)
    for i in range(10):
        for j in range(19):
            niv.create_image(50*j,50*i,image=dico[map1[i][j]],anchor="nw")
    Fleurs()
    niv.pack()
    niv.focus_set()
    posX = 300
    posY = 100
    perso=niv.create_image(posX,posY,image=RalphGauche,anchor="nw")
    AP = niv.after(0,AnimPerso)
    niv.bind('<Key>',Clavier)

def Fleurs():
    """Fonction qui crée les fleurs pour le premier niveau"""
    global niv
    f = niv.create_image(800,250,image=Fleur2,anchor="nw")
    f = niv.create_image(900,400,image=Fleur2,anchor="nw")
    f = niv.create_image(50,350,image=Fleur2,anchor="nw")
    f = niv.create_image(500,400,image=Fleur2,anchor="nw")
    f = niv.create_image(100,100,image=Fleur,anchor="nw")
    f = niv.create_image(500,200,image=Fleur,anchor="nw")
    f = niv.create_image(700,150,image=Fleur,anchor="nw")
    f = niv.create_image(250,350,image=Fleur,anchor="nw")

def StageMaison():
    """Affichage de la maison de ADOY"""
    global compt_niv, posX, posY,perso, AP, dico2, niv, i,t,x,y
    niv.after_cancel(AP)
    niv.destroy()
    compt_niv=1
    niv=Canvas(Mafenetre,bg='white',height=500,width=950)
    for i in range(10):
        for j in range(11):
            niv.create_image(50*j,50*i,image=dico2[mapMaison[i][j]],anchor="nw")
    niv.pack()
    niv.focus_set()
    i=0
    t=100
    x=565
    y=50
    posX = 250
    posY = 450
    perso=niv.create_image(posX,posY,image=RalphGauche,anchor="nw")
    AP = niv.after(0,AnimPerso)
    pnj=niv.create_image(250,50,image=MaitreADOY,anchor="nw")
    niv.bind('<Key>',Clavier)
    
def Stage2():
    """Affichage du second niveau de notre jeu"""
    global compt_niv, posX, posY,perso, ListeEnnemies,PosEnnemies, AE1, AE2, AE3, AP, niv
    niv.after_cancel(AP)
    ListeEnnemies=[]
    PosEnnemies=[]
    niv.destroy()
    compt_niv=3
    niv=Canvas(Mafenetre,bg='white',height=500,width=950)
    for i in range(10):
        for j in range(19):
            niv.create_image(50*j,50*i,image=dicoGrotte[map2[i][j]],anchor="nw")
    niv.pack()
    niv.focus_set()
    posX = 850
    posY = 300
    perso=niv.create_image(posX,posY,image=RalphGauche,anchor="nw")
    AP = niv.after(0,AnimPerso)
    ApparitionEnnemies()
    AE1 = niv.after(random.randint(750,2250),AnimationEnnemies1)
    AE2 = niv.after(random.randint(750,2250),AnimationEnnemies2)
    AE3 = niv.after(random.randint(750,2250),AnimationEnnemies3)  
    niv.bind('<Key>',Clavier)

def Stage3():
    """Affichage du dernier niveau de notre jeu"""
    global compt_niv, posX, posY,perso,boss, AB, posXB, posYB, AP, PosEnnemies, Affichage_VieBoss, Affichage_ViePerso,textVieJoueur, textVieBoss, niv, NbreVieBoss, NbreViePerso
    Mafenetre.geometry('1150x500')
    niv.after_cancel(AP)
    niv.destroy()
    compt_niv=4
    PosEnnemies=[]
    niv=Canvas(Mafenetre,bg='white',height=500,width=1150)
    for i in range(10):
        for j in range(19):
            niv.create_image(50*j,50*i,image=dicoBoss[map3[i][j]],anchor="nw")
    niv.pack()
    niv.focus_set()
    #Boss
    posXB=50
    posYB=250
    boss=niv.create_image(posXB,posYB,image=Boss,anchor="nw")    
    AB = niv.after(750,AnimationBoss)
    #Perso
    posX = 850
    posY = 400
    perso= niv.create_image(posX,posY,image=RalphGauche,anchor="nw")
    AP = niv.after(0,AnimPerso)
    #Affichage Vie
    NbreVieBoss=4
    NbreViePerso=2
    textVieJoueur = ("Vie du joueur : " + str(NbreViePerso))
    textVieBoss = ("Vie du Boss : " + str(NbreVieBoss))
    Affichage_ViePerso = niv.create_text(1050,74, text=textVieJoueur, font=("8_bit_1_6",10), fill="black", justify ='right')
    Affichage_VieBoss = niv.create_text(1050,89, text=textVieBoss, font=("8_bit_1_6",10), fill="black", justify ='right')
    niv.bind('<Key>',Clavier)

def GameOver():
    """Affichage du GameOver lors d'une mort contre le boss"""
    global niv
    Mafenetre.geometry('500x500')
    niv.destroy()
    niv = Canvas(Mafenetre, bg='white', height=500, width=500)
    niv.create_image(0,0,image=FondGO,anchor="nw")
    niv.pack()
    niv.focus_set()
    Button(niv,text="Try Again",font=("8_bit_1_6",12),anchor=CENTER,command=Stage3).place(relx=0.5, y=435, anchor=CENTER)

def Win():
    """Affichage de l'image WIN, lors d'une victoire contre le boss"""
    global niv, i,t,x,y
    Mafenetre.geometry('500x500')
    niv.destroy()
    niv = Canvas(Mafenetre, bg='white', height=500, width=500)
    niv.create_image(0,0,image=FondFin,anchor="nw")
    niv.pack()
    niv.focus_set()
    i=0
    t=0
    x=162
    y=55
    Button(niv,text="Continuez",font=("8_bit_1_6",12),anchor=CENTER,command=Final).place(relx=0.5, y=435, anchor=CENTER)

def Final():
    """Affichage du Canvas nécessaire pour la fonction Presentation"""
    global niv, i,t,x,y
    niv.destroy()
    niv = Canvas(Mafenetre, bg='black', height=500, width=500)
    niv.pack()
    niv.focus_set()
    niv.after(500,Presentation)

def Presentation():
    """Affiche la liste des personnes qui ont participés au projet"""
    
    
    texte = ["Projet NSI 2019/2020;","Programme du jeu par :;","bestard julien;","et bardon pierre-louis.;"
             ,"Design du jeu par :;","anger matis;","Musique:;","HALO (Theme) (8 Bit Remix Cover Version);","[Tribute to HALO] - 8 Bit Universe;"]

    ListeXY = [(20,142),(143,160),(143,178),(20,242),(124,260),(20,342),(92,360),(92,378)]
    
    global niv, i,t,x,y
    
    script=niv.create_text(x,y, text="", font=('8_bit_1_6',8), fill="white", justify ='right')
        
    niv.coords(script,x,y)
    niv.itemconfig(script,text=(texte[t][i]))
    x+=8
    i+=1
    
    if t==8 and texte[8][i]==";":
        Button(niv,text="Quitter",font=("8_bit_1_6",12),anchor=CENTER,command=Quit).place(relx=0.5, y=475, anchor=CENTER)        
    
    elif texte[t][i]==';':
        i=0
        x=ListeXY[t][0]
        y=ListeXY[t][1]
        t+=1
        niv.after(50,Presentation)
    else : 
        niv.after(50,Presentation)

def Quit():
    """Fonction qui ferme le jeu et coupe la musique"""
    Mafenetre.destroy()
    channel1.stop()
    channel2.stop()

    
############################
#                          #
#    Programme Principal   #
#                          #
############################

#Importation de toutes les images nécessaires au jeu
#Fond
Fond = PhotoImage(file="Fond/Menu.png")    
FondGO = PhotoImage(file="Fond/GameOver.png")
FondFin = PhotoImage(file="Fond/Fin.png")
#Plaine
Herbe=PhotoImage(file="Fond/Plaine/Herbe.gif")
Chemin=PhotoImage(file="Fond/Plaine/Chemin.gif")
Montagne=PhotoImage(file="Fond/Plaine/Montagne.gif")
Montagne2=PhotoImage(file="Fond/Plaine/Montagne2.gif")
Village=PhotoImage(file="Fond/Plaine/VillageSurHerbe.gif")
Eau=PhotoImage(file="Fond/Plaine/Eau.png")
Pont=PhotoImage(file="Fond/Plaine/Pont.png")

ArbreHaut=PhotoImage(file="Fond/Plaine/ArbreHaut.png")
ArbreBas=PhotoImage(file="Fond/Plaine/ArbreBas.png")
FeuDeCamp=PhotoImage(file="Fond/Plaine/FeuDeCamp.png")
Fleur=PhotoImage(file="Fond/Plaine/Fleur.gif")
Fleur2=PhotoImage(file="Fond/Plaine/Fleurx2.png")

#Grotte
MurGrotte=PhotoImage(file="Fond/Grotte/Mur.png")
SolGrotte1=PhotoImage(file="Fond/Grotte/SOL1.png")
SolGrotte2=PhotoImage(file="Fond/Grotte/SOL2.png")
SolGrotte3=PhotoImage(file="Fond/Grotte/SOL3.png")
SolGrotte4=PhotoImage(file="Fond/Grotte/SOL4.png")
SolGrotte5=PhotoImage(file="Fond/Grotte/SOL5.png")
SolGrotte6=PhotoImage(file="Fond/Grotte/SOL6.png")
SolGrotte7=PhotoImage(file="Fond/Grotte/SOL7.png")
Torche=PhotoImage(file="Fond/Grotte/Torche.png")
Torche2=PhotoImage(file="Fond/Grotte/Torche2.png")

#Maison
Planche=PhotoImage(file="Fond/Maison/Planche.gif")
Planche2=PhotoImage(file="Fond/Maison/PlancheSpruce.gif")
MurMaison = PhotoImage(file="Fond/Maison/MurVillage.gif")

#Salle du Boss
MurBoss = PhotoImage(file="Fond/Boss/Mur.png")
SolBoss = PhotoImage(file="Fond/Boss/Sol.png")
PillierBoss = PhotoImage(file="Fond/Boss/Pillier.png")

#PNJ
MaitreADOY=PhotoImage(file="ArmePerso/MaitreADOY.png")

#Perso
RalphGauche=PhotoImage(file="ArmePerso/Ralph/Gauche/RalphBase.png")
RalphRunGauche1=PhotoImage(file="ArmePerso/Ralph/Gauche/RUN/Run1.png")
RalphRunGauche2=PhotoImage(file="ArmePerso/Ralph/Gauche/RUN/Run2.png")
RalphRunGauche4=PhotoImage(file="ArmePerso/Ralph/Gauche/RUN/Run4.png")
Tab_Gauche=[RalphRunGauche1,RalphRunGauche2,RalphRunGauche1,RalphRunGauche4]

RalphDroite=PhotoImage(file="ArmePerso/Ralph/Droite/RalphBase.png")
RalphRunDroite1=PhotoImage(file="ArmePerso/Ralph/Droite/RUN/Run1.png")
RalphRunDroite2=PhotoImage(file="ArmePerso/Ralph/Droite/RUN/Run2.png")
RalphRunDroite4=PhotoImage(file="ArmePerso/Ralph/Droite/RUN/Run4.png")
Tab_Droite=[RalphRunDroite1,RalphRunDroite2,RalphRunDroite1,RalphRunDroite4]

RalphHaut1=PhotoImage(file="ArmePerso/Ralph/Haut/RalphUp1.png")
RalphHaut2=PhotoImage(file="ArmePerso/Ralph/Haut/RalphUp2.png")
Tab_Haut=[RalphHaut1,RalphHaut2]

RalphBas1=PhotoImage(file="ArmePerso/Ralph/Bas/RalphDown1.png")
RalphBas2=PhotoImage(file="ArmePerso/Ralph/Bas/RalphDown2.png")
Tab_Bas=[RalphBas1,RalphBas2]

RalphGaucheAFK0=PhotoImage(file="ArmePerso/Ralph/Gauche/AFK/AFK0.png")
RalphGaucheAFK1=PhotoImage(file="ArmePerso/Ralph/Gauche/AFK/AFK1.png")
RalphGaucheAFK2=PhotoImage(file="ArmePerso/Ralph/Gauche/AFK/AFK2.png")

#Arme
RalphGaucheTir = PhotoImage(file="ArmePerso/Ralph/Gauche/ATC/ATCGauche.png")
RalphDroiteTir = PhotoImage(file="ArmePerso/Ralph/Droite/ATC/ATCDroite.png")

Fleche1=PhotoImage(file="ArmePerso/Ralph/Fleche1.gif")
Fleche2=PhotoImage(file="ArmePerso/Ralph/Fleche2.gif")
Fleche3=PhotoImage(file="ArmePerso/Ralph/Fleche3.gif")
Fleche4=PhotoImage(file="ArmePerso/Ralph/Fleche4.gif")
Fleche = [Fleche1,Fleche2,Fleche3,Fleche4] #Liste qui nous servira a gérer le sens de la flèche

#Ennemi
Ennemi1=PhotoImage(file="ArmePerso/Mob.gif")
Ennemi2=PhotoImage(file="ArmePerso/Mob2.gif")

Boss=PhotoImage(file="ArmePerso/Boss/Boss.png")
BossUp=PhotoImage(file="ArmePerso/Boss/BossUp.png")
BossDown=PhotoImage(file="ArmePerso/Boss/BossDown.png")
Tab_HautBasBoss=[BossUp,BossDown]

BossTir=PhotoImage(file="ArmePerso/Boss/BossTir.png")
Projectile = PhotoImage(file="ArmePerso/Boss/Projectile.png")

#creation des matrices
L0=[3,3,3,3,3,3,3,3,3,3,3,3,3,5,5,5,3,3,3]
L1=[3,4,4,4,4,4,4,4,4,7,4,4,5,5,5,4,4,4,4]
L2=[3,4,4,4,4,4,1,4,4,8,4,5,5,5,4,4,0,0,0]
L3=[3,4,7,4,0,0,0,0,0,0,4,5,5,5,4,0,0,7,4]
L4=[3,4,8,4,0,4,4,4,4,0,4,5,5,5,0,0,4,8,5]
L5=[3,4,4,4,0,4,9,4,4,0,0,6,6,6,0,4,4,5,5]
L6=[0,0,0,0,0,4,4,4,7,4,4,5,5,5,5,5,5,5,5]
L7=[3,4,4,4,4,4,4,4,8,4,4,5,5,5,5,5,5,5,4]
L8=[3,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,4,4]
L9=[3,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]
map1=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9]

L0=[9,9,9,9,9,9,9,9,9,9,9]
L1=[9,7,7,7,7,10,7,7,7,7,9]
L2=[9,7,7,7,7,8,7,7,7,7,9]
L3=[9,7,7,7,7,8,7,7,7,7,9]
L4=[9,7,7,7,7,8,7,7,7,7,9]
L5=[9,7,7,7,7,8,7,7,7,7,9]
L6=[9,7,7,7,7,8,7,7,7,7,9]
L7=[9,7,7,7,7,8,7,7,7,7,9]
L8=[9,7,7,7,7,8,7,7,7,7,9]
L9=[9,9,9,9,7,7,7,9,9,9,9]
mapMaison=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9]

L0=[0,0,0,0,0,0,8,0,0,0,0,0,0,0,8,0,0,0,0]
L1=[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L2=[0,1,1,1,1,1,1,1,1,1,7,1,1,1,1,1,4,1,0]
L3=[0,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L4=[0,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,0]
L5=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L6=[0,1,1,1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L7=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,0]
L8=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0] 
L9=[0,0,0,0,0,0,9,0,0,0,0,0,0,0,9,0,0,0,0]
map2=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9]

L0=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
L1=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L2=[0,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L3=[0,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,0]
L4=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L5=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L6=[0,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,0]
L7=[0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L8=[0,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]
L9=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
map3=[L0,L1,L2,L3,L4,L5,L6,L7,L8,L9]

map=[map1,mapMaison,map1,map2,map3] #Liste contenant toutes nos matrices

#Ensemble des dictionnaires utilisés pour les bitmaps
dico={0:Chemin,1:Village,2:Montagne,3:Montagne2,4:Herbe,5:Eau,6:Pont,7:ArbreHaut,8:ArbreBas,9:FeuDeCamp}
dico2={7:Planche,8:Planche2,9:MurMaison, 10:MaitreADOY}
dicoGrotte={0:MurGrotte,1:SolGrotte1,2:SolGrotte2,3:SolGrotte3,4:SolGrotte4,5:SolGrotte5,6:SolGrotte6,7:SolGrotte7,8:Torche,9:Torche2}
dicoBoss={0:MurBoss,1:SolBoss,2:PillierBoss}


niv=0       #Variable qui deviendrat un Canvas au lancement du programme
DebutJeu=0  #Variable qui nous servira a détecté si on est aller parlé au PNJ

#Fleche
Arrow=0
posXF, posYF =0,0

#Personnage
perso=0
posX, posY = 0,0
NbreViePerso=0
textVieJoueur = str

#Boss
boss=0
posXB=0
posYB=0
NbreVieBoss=4
textVieBoss = str

#Liste des obstacles
ListePillierBoss=[(100,100),(500,150),(350,300),(100,400)]
ListePillierPerso=[(150,100),(550,150),(400,300),(150,400)]
ListeArbre=[(100,200),(450,100),(800,250),(400,350)]

#Variable des multiples animations
AP = 0      #Animation du perso
AF = 0      #Animation de la flèche
AE1 = 0     #Animation du première Ennemi
AE2 = 0     #Animation du second Ennemi
AE3 = 0     #Animation du troisème Ennemi
AB = 0      #Animation du Boss
APB = 0     #Animation du projectile du Boss


i1 = (+50) #Pas de déplacement pour les ennemies
i2 = (+50)
i3 = (+50)

iB=(+50)

#Attaque
tir=0
TirBoss=0
toucheDepl=0

#Ennemies
PosEnnemies=[]
ListeEnnemies=[]
ListeX=[]
nbre_ennemies=0

#Liste de tout les compteurs nécessaires au fonctionnement du programme
compt_pas_boss=0
compt_pas_Vert=0
compt_pas_Hor=0
compt_anim=0
compt_niv=0

#Variable pour le texte
i=0
t=0
x=565
y=50

Intro() #Lancement du jeu

#Musique
mixer.init()
mixer.set_num_channels(2)
channel1 = mixer.Channel(0)
channel2 = mixer.Channel(1)
Musique = mixer.Sound('Musique.ogg')
TexteAdoy = mixer.Sound('TexteADOY.ogg')
channel1.play(Musique, loops = -1)
channel1.set_volume(0.04)
channel2.set_volume(0.1)

Mafenetre.protocol("WM_DELETE_WINDOW", Quit) #Detecte la fermeture de la fenetre par le joueur
Mafenetre.mainloop()
