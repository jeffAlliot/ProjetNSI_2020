#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('500x400')
#zone de dessin
can4=Canvas(Mafenetre,bg="white",width=600,height=500)
can4.place(x=0,y=0)
can3=Canvas(Mafenetre,bg="white",width=600,height=500)
can3.place(x=0,y=0)
can2=Canvas(Mafenetre,bg="white",width=600,height=500)
can2.place(x=0,y=0)
can1=Canvas(Mafenetre,bg="white",width=600,height=500)
can1.place(x=0,y=0)
matrice_can=[can1,can2,can3]
niveau=0
#creation des cases images
caseporte=PhotoImage(file="porte.gif")
caseporte2=PhotoImage(file="porte.gif")
casemur1=PhotoImage(file="mur1.gif")
casemur2=PhotoImage(file="mur2.gif")
casesol1=PhotoImage(file="sol1.gif")
casesol2=PhotoImage(file="sol2.gif")
personnage1=PhotoImage(file="personnage1.gif")
personnage2=PhotoImage(file="personnage2.gif")
garde1=PhotoImage(file="garde1.gif")
garde2=PhotoImage(file="garde2.gif")
droite1=PhotoImage(file="droite1.gif")
droite2=PhotoImage(file="droite2.gif")
titre_fin=PhotoImage(file="fin.gif")
garde_droite1=PhotoImage(file="garde_droite1.gif")
garde_droite2=PhotoImage(file="garde_droite2.gif")
Pnj=PhotoImage(file="Pnj.gif")
#creation de la matrice
L0=["W","W","W","W","W","W","O","W","P","W"]
L1=["W","M","M","M","W","W","S","W","S","W"]
L2=["W","S","O","S","W","W","O","M","O","W"]
L3=["W","O","W","O","M","W","S","O","S","W"]
L4=["M","S","M","S","O","W","O","W","W","W"]
L5=["S","O","S","W","S","W","S","W","W","W"]
L6=["O","S","O","W","O","M","O","W","W","W"]
L7=["S","O","S","W","S","O","S","W","W","W"]
ma_matrice=[L0,L1,L2,L3,L4,L5,L6,L7]
#création de la deuxieme matrice
L10=["P","W","W","W","M","M","M","M","M","M"]
L11=["O","W","W","W","O","S","O","S","O","S"]
L12=["S","W","W","W","S","W","W","O","W","O"]
L13=["O","M","W","M","O","M","W","W","W","S"]
L14=["S","O","W","O","S","O","W","M","M","O"]
L15=["O","W","W","S","W","S","W","S","O","S"]
L16=["S","M","M","O","S","O","W","O","S","O"]
L17=["O","S","O","S","W","W","W","S","O","S"]
ma_matrice2=[L10,L11,L12,L13,L14,L15,L16,L17]

#création de la troisième matrice
L20=["S","O","S","O","S","O","D","O","S","W"]
L21=["O","W","O","W","W","S","W","S","O","W"]
L22=["S","M","S","M","M","O","W","W","W","W"]
L23=["O","S","O","S","O","S","M","M","M","W"]
L24=["S","W","S","O","S","O","S","O","S","W"]
L25=["O","W","O","W","O","W","O","W","O","W"]
L26=["S","W","S","M","S","M","S","M","S","P"]
L27=["O","M","O","S","O","S","O","S","O","W"]
ma_matrice3=[L20,L21,L22,L23,L24,L25,L26,L27]
matrice_matrice=[ma_matrice,ma_matrice2,ma_matrice3]
#creation de la map
dico={"M":casemur1,"W":casemur2,"P":caseporte,"S":casesol1,"O":casesol2,"D":caseporte2}
for i in range(8):
    for j in range(10):
        can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
#position du personnage
posX=50  #abscisse de départ
posY=300 #ordonnée de départ
perso=can1.create_image(posX,posY,image=personnage1,anchor="nw")   
tab_droite=[droite1,droite2]
tab_haut=[personnage1,droite1]
tab_gauche=[personnage1,personnage2]
tab_bas=[personnage1,droite1]

compteur_de_pas=0
#création du garde
garde=can1.create_image(300,0,image=garde1,anchor="nw")
tab_garde=[garde1,garde2]
tab_garde_droite=[garde_droite1,garde_droite2]
compteur_de_pas_garde=0
#zone de texte
texte_pnj=can1.create_text(100,350,text="",font=("Arial",14),fill="red")

#fonctions
def Clavier(event) :
    """event variable qui a récupéré l'information tapée au clavier"""
    global posX,posY,matrice_matrice,niveau,cle
    touche=event.keysym
    ligne=posY//50
    colonne=posX//50
    if touche=="Up" and matrice_matrice[niveau][ligne-1][colonne]=="O" :
        mvt_haut()
    elif touche=="Up" and matrice_matrice[niveau][ligne-1][colonne]=="S" :
        mvt_haut()
    elif touche=="Up" and matrice_matrice[niveau][ligne-1][colonne]=="P" :
        if niveau==0 :
            niveau=1
            niveau2()
        elif niveau==1 :
            niveau=2
            niveau3()
    elif touche=="Down" and matrice_matrice[niveau][ligne+1][colonne]=="O" :
        mvt_bas()
    elif touche=="Down" and matrice_matrice[niveau][ligne+1][colonne]=="S" :
        mvt_bas()
    elif touche=="Left" and matrice_matrice[niveau][ligne][colonne-1]=="O" :
        mvt_gauche()
    elif touche=="Left" and matrice_matrice[niveau][ligne][colonne-1]=="S" :
        mvt_gauche()
    elif touche=="Left" and matrice_matrice[niveau][ligne][colonne-1]=="D" :
        posX-=100
        can3.coords(perso,posX,posY)
    elif touche=="Right" and matrice_matrice[niveau][ligne][colonne+1]=="O" :
        mvt_droite()
    elif touche=="Right" and matrice_matrice[niveau][ligne][colonne+1]=="S" :
        mvt_droite()
    elif touche=="Right" and matrice_matrice[niveau][ligne][colonne+1]=="D" :
        posX+=100
        can3.coords(perso,posX,posY)
    elif touche=="Right" and matrice_matrice[niveau][ligne][colonne+1]=="P" and cle==1:
        niveau=3
        fin()
#def mvt_police() :
#    mise a jour des coordonnées du policier
#    can?.after()
def mvt_haut() :
    """déplaceemnt du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_haut,matrice_can,niveau,can2
   
    posY=posY-50
    if posY<0:
        posY=0
    #mise a jour de l'image du personnage
    matrice_can[niveau].itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise a jour des coordonnées des personnages
    matrice_can[niveau].coords(perso,posX,posY)
    
def mvt_bas() :
    """déplaceemnt du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_bas,matrice_can,niveau
    posY=posY+50
    if posY>350:
        posY=350
    #mise a jour de l'image du personnage
    matrice_can[niveau].itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise a jour des coordonnées des personnages
    matrice_can[niveau].coords(perso,posX,posY)
    
def mvt_droite() :
    """déplaceemnt du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_droite,matrice_can,niveau
    posX=posX+50
    if posX>500:
        posX=500
    #mise a jour de l'image du personnage
    matrice_can[niveau].itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise a jour des coordonnées des personnages
    matrice_can[niveau].coords(perso,posX,posY)
    
def mvt_gauche() :
    """déplaceemnt du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_gauche,matrice_can,niveau
    posX=posX-50
    if posX<0:
        posX=0
    #mise a jour de l'image du personnage
    matrice_can[niveau].itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise a jour des coordonnées des personnages
    matrice_can[niveau].coords(perso,posX,posY)

pos_garde=[0,50,100,150,200,250,300,350]

x=0
z=0
def mvt_garde():
    """déplacement automatique du garde"""
    global pos_garde,x,z,pos_garde2,compteur_de_pas_garde,matrice_can,niveau
    
    if z==0 :
        x+=1
    elif z==1 :
        x-=1
    if x==7 :
        z=1
    elif x==0 :
        z=0
    matrice_can[niveau].itemconfig(garde,image=tab_garde[compteur_de_pas_garde%2])
    can1.coords(garde,300,pos_garde[x])
    can1.after(500,mvt_garde)
    
mvt_garde()   

def pas_garde() :
    global compteur_de_pas_garde,matrice_can,niveau
    compteur_de_pas_garde+=1
    matrice_can[niveau].after(500,pas_garde)
    
pas_garde()  
    
    
def gameover() :
    """affiche game over si le perso touche le garde """
    global posX,posY,x,pos_garde
    if posY==pos_garde[x] and posX==300 :
        posX=50
        posY=300
        can1.coords(perso,posX,posY)
        
    can1.after(1,gameover)
gameover()


#def niveau2
def niveau2() :
    global dico,can2,ma_matrice2,posX,posY,perso,zz,y,pos_garde2,garde2,n,garde3,pos_garde3,garde4,pos_garde4,w,zzz
    can1.destroy()
    for i in range(8):
        for j in range(10):
            can2.create_image(50*j,50*i,image=dico[ma_matrice2[i][j]],anchor="nw")
    posX=400
    posY=300
    perso=can2.create_image(posX,posY,image=personnage1,anchor="nw") 
    matrice_can[niveau].focus_set()
    matrice_can[niveau].bind("<Key>",Clavier)
    
    
    #création du garde2
    garde2=can2.create_image(250,50,image=garde1,anchor="nw")
    #fonction can2
    pos_garde2=[200,250,300,350,400,450]

    y=0
    zz=0
    mvt_garde2()
    gameover2()
    #création du garde 3
    garde3=can2.create_image(150,300,image=garde1,anchor="nw")
    pos_garde3=[(150,300),(200,300),(250,300),(250,250),(250,200),(200,200),(150,200),(150,250)]
    n=0
    mvt_garde3()
    gameover3()
    #création du garde 4
    garde4=can2.create_image(0,50,image=garde1,anchor="nw")
    #fonction can2
    pos_garde4=[50,100,150,200,250,300,350]
    w=0
    zzz=0
    mvt_garde4()
    gameover4()
    pas_garde()

#fonction mouvement des gardes
def mvt_garde2():
    """déplacement automatique du garde"""
    global pos_garde2,y,zz,compteur_de_pas_garde,matrice_can,niveau

    if zz==0 :
        y+=1
        matrice_can[niveau].itemconfig(garde2,image=tab_garde_droite[compteur_de_pas_garde%2])
    elif zz==1 :
        y-=1
        matrice_can[niveau].itemconfig(garde2,image=tab_garde[compteur_de_pas_garde%2])
    if y==5 :
        zz=1
    elif y==0 :
        zz=0
    can2.coords(garde2,pos_garde2[y],50)
    can2.after(500,mvt_garde2)

def mvt_garde3():
    """déplacement automatique du garde"""
    global pos_garde3,n,compteur_de_pas_garde,matrice_can,niveau
    n+=1
    if n==8 :
        n=0
    if n<5 :
        matrice_can[niveau].itemconfig(garde3,image=tab_garde_droite[compteur_de_pas_garde%2])
    if n>4:
        matrice_can[niveau].itemconfig(garde3,image=tab_garde[compteur_de_pas_garde%2])
        
    can2.coords(garde3,pos_garde3[n])
    can2.after(500,mvt_garde3)

def mvt_garde4():
    """déplacement automatique du garde"""
    global pos_garde4,w,zzz,compteur_de_pas_garde,matrice_can,niveau

    if zzz==0 :
        w+=1
    elif zzz==1 :
        w-=1
    
    if w==6 :
        zzz=1
    elif w==0 :
        zzz=0
    matrice_can[niveau].itemconfig(garde4,image=tab_garde[compteur_de_pas_garde%2])
    can2.coords(garde4,0,pos_garde4[w])
    can2.after(500,mvt_garde4)

#fonctions game over    
def gameover2() :
    """affiche game over si le perso touche le garde """
    global posX,posY,y,pos_garde2
    if posY==50 and posX==pos_garde2[y] :
        posX=400
        posY=300
        texte2.after(5,texte2.destroy)
        can2.coords(perso,posX,posY)
            

    can2.after(1,gameover2)

def gameover3() :
    """affiche game over si le perso touche le garde """
    global posX,posY,n,pos_garde3
    if posY==pos_garde3[n][1] and posX==pos_garde3[n][0] :
        posX=400
        posY=300
        can2.coords(perso,posX,posY)

    can2.after(1,gameover3)
    
def gameover4() :
    """affiche game over si le perso touche le garde """
    global posX,posY,w,pos_garde4
    if posX==0 and posY==pos_garde4[w] :
        posX=400
        posY=300
        can2.coords(perso,posX,posY)

    can2.after(1,gameover4)


#def niveau3
def niveau3() :
    global dico,can3,ma_matrice3,posX,posY,perso,cle,pause,r,gardejaune,pos_gardejaune,h,gardeviolet,pos_gardeviolet,b,gardebleu,pos_gardebleu,p,garderouge,pos_garderouge
    can2.destroy()
    can3.create_text(300,200,text="vous êtes passé au niveau 3",fill="red")
    for i in range(8):
        for j in range(10):
            can3.create_image(50*j,50*i,image=dico[ma_matrice3[i][j]],anchor="nw")
    posX=0
    posY=350
    perso=can3.create_image(posX,posY,image=personnage1,anchor="nw") 
    matrice_can[niveau].focus_set()
    matrice_can[niveau].bind("<Key>",Clavier)
    pnj=can3.create_image(400,50,image=Pnj,anchor="nw")
    cle=0
    pause=0
    pnj_cle()
    
    #création du garde jaune
    gardejaune=can3.create_image(250,0,image=garde1,anchor="nw")
    pos_gardejaune=[(250,0),(200,0),(150,0),(100,0),(100,50),(100,100),(100,150),(150,150),(200,150),(250,150),(250,100),(250,50)]
    r=0
    mvt_gardejaune()
    gameoverjaune()
    #création du garde violet
    gardeviolet=can3.create_image(250,0,image=garde1,anchor="nw")
    pos_gardeviolet=[(300,200),(250,200),(200,200),(200,250),(200,300),(200,350),(250,350),(300,350),(350,350),(400,350),(400,300),(400,250),(400,200),(350,200)]
    h=0
    mvt_gardeviolet()
    gameoverviolet()
    #création du grade bleu
    pos_gardebleu=[(100,350),(150,350),(200,350),(250,350),(300,350),(300,300),(300,250),(300,200),(250,200),(200,200),(150,200),(100,200),(100,250),(100,300)]
    b=0
    gardebleu=can3.create_image(100,350,image=garde1,anchor="nw") 
    pas_garde()
    mvt_gardebleu()
    gameoverbleu()
    #création du garde rouge
    garderouge=can3.create_image(0,0,image=garde1,anchor="nw")
    pos_garderouge=[(0,0),(0,50),(0,100),(0,150),(50,150),(100,150),(150,150),(200,150),(250,150),(250,100),(250,50),(250,0),(200,0),(150,0),(100,0),(50,0)]
    p=0
    mvt_garderouge()
    gameoverrouge()

#mouvement des gardes au niveau 3    
def mvt_gardebleu():
    """déplacement automatique du garde"""
    global pos_gardebleu,b,compteur_de_pas_garde,matrice_can,niveau,texte_pnj,gardebleu
    b+=1
    if b==14 :
        b=0
    if b<7 :
        matrice_can[niveau].itemconfig(gardebleu,image=tab_garde_droite[compteur_de_pas_garde%2])
    if b>6:
        matrice_can[niveau].itemconfig(gardebleu,image=tab_garde[compteur_de_pas_garde%2])

    can3.coords(gardebleu,pos_gardebleu[b])
    can3.after(500,mvt_gardebleu)  
    
def mvt_gardejaune():
    """déplacement automatique du garde"""
    global pos_gardejaune,r,compteur_de_pas_garde,matrice_can,niveau,gardejaune
    r+=1
    if r==12 :
        r=0
    if r>4 :
        matrice_can[niveau].itemconfig(gardejaune,image=tab_garde_droite[compteur_de_pas_garde%2])
    if r<5:
        matrice_can[niveau].itemconfig(gardejaune,image=tab_garde[compteur_de_pas_garde%2])
        
    can3.coords(gardejaune,pos_gardejaune[r])
    can3.after(500,mvt_gardejaune)
    
    
def mvt_gardeviolet():
    """déplacement automatique du garde"""
    global pos_gardeviolet,h,compteur_de_pas_garde,matrice_can,niveau,gardeviolet
    h+=1
    if h==14 :
        h=0
    if h>4 :
        matrice_can[niveau].itemconfig(gardeviolet,image=tab_garde_droite[compteur_de_pas_garde%2])
    if h<5:
        matrice_can[niveau].itemconfig(gardeviolet,image=tab_garde[compteur_de_pas_garde%2])
        
    can3.coords(gardeviolet,pos_gardeviolet[h])
    can3.after(500,mvt_gardeviolet)
    
def mvt_garderouge():
    """déplacement automatique du garde"""
    global pos_garderouge,p,compteur_de_pas_garde,matrice_can,niveau,garderouge
    p+=1
    if p==16 :
        p=0
    if p>8 :
        matrice_can[niveau].itemconfig(garderouge,image=tab_garde[compteur_de_pas_garde%2])
    if p<9:
        matrice_can[niveau].itemconfig(garderouge,image=tab_garde_droite[compteur_de_pas_garde%2])

    can3.coords(garderouge,pos_garderouge[p])
    can3.after(500,mvt_garderouge)

#gameover niveau3    
def gameoverjaune() :
    """affiche game over si le perso touche le garde """
    global posX,posY,r,pos_gardejaune,cle
    if posY==pos_gardejaune[r][1] and posX==pos_gardejaune[r][0] :
        posX=0
        posY=350
        cle=0
        can3.coords(perso,posX,posY)

    can3.after(1,gameoverjaune)
    
def gameoverviolet() :
    """affiche game over si le perso touche le garde """
    global posX,posY,h,pos_gardeviolet,cle
    if posY==pos_gardeviolet[h][1] and posX==pos_gardeviolet[h][0] :
        posX=0
        posY=350
        cle=0
        can3.coords(perso,posX,posY)

    can3.after(1,gameoverviolet)
    
def gameoverbleu() :
    """affiche game over si le perso touche le garde """
    global posX,posY,b,pos_gardebleu,cle
    if posY==pos_gardebleu[b][1] and posX==pos_gardebleu[b][0] :
        posX=0
        posY=350
        cle=0
        can3.coords(perso,posX,posY)

    can3.after(1,gameoverbleu)  

def gameoverrouge() :
    """affiche game over si le perso touche le garde """
    global posX,posY,p,pos_garderouge,cle
    if posY==pos_garderouge[p][1] and posX==pos_garderouge[p][0] :
        posX=0
        posY=350
        cle=0
        can3.coords(perso,posX,posY)
    
    can3.after(1,gameoverrouge)


def pnj_cle() :
    global posX,posY,cle,texte,pause
    if posX==400 and posY==50 and cle==0:
        texte=can3.create_text(200,50,text=("Hey j'ai trouvé une clé, tiens, j'éspère qu'elle te serviras"),font=("Arial",13),fill="white")
        cle=1
    if cle==1 :
        pause+=1
    if pause==2000 :    
        can3.tag_lower(texte)
    can3.after(1,pnj_cle)

    global titre_fin
def fin() :
    can3.destroy()
    Mafenetre.geometry('600x500')
    can4.create_image(0,0,image=titre_fin,anchor="nw")
    
    
    
    
    
    
    
    
#programme principal

matrice_can[niveau].focus_set() #focus sur le can1
matrice_can[niveau].bind("<Key>",Clavier) #fonction clavier si touche enfoncée

    
Mafenetre.mainloop()

