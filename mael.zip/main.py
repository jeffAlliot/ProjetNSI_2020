""" =============================
IMPORTATIONS DES ELEMENTS EXTERNES
=============================="""

# Modules

from tkinter import *
from time import *
from math import *
from tkinter.font import Font
from pygame import mixer as pygs

import random

# Autres

from data import *

""" =============================
INITIALISATION FENETRE/PERSONNAGE
=============================="""


next_move = ceil(time())

# Fenêtre

Mafenetre=Tk()
Mafenetre.geometry('768x864')
Mafenetre.title("Joe's Adventures")

font_title = Font( family="Constantia", size="16" )
font_base = Font( family="Constantia", size="10" )

# Zone de dessin

can1=Canvas(Mafenetre,bg="#111111",width=768,height=864)
can1.place(x=0,y=0)

# Variables globale du personnage

can_player = 0
player_posX = 0
player_posY = 0
player_look = "Down"
player_in_matrice = main_matrice
player_move_px = 32
player_pos_canX = 0
player_mid = 0
player_isindialog = False
player_story_lvl = 0
player_exeption_tiles = blocked_tiles

player_itemcollected = 0

dlg_writing = False

global_int = IntVar()

""" =============================
FONCTION DES MAPS
=============================="""


def DrawMainMap(x, y) :
    """ Dessine la map centrale.En dessinant le personnage aux coordonnées x, y.
    x : int
    y : int
    """
    
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid,player_in_matrice, player_exeption_tiles, champ_2, champ_3, champ_4
    player_in_matrice = main_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 32
    player_pos_canX = 0
    player_mid = 0
    player_exeption_tiles = blocked_tiles
    # Dessin de la map (matrice)
    
    DrawMap(main_matrice, tilestbl, can1, 24, 27, 32)
    
    # Dessin des arbres et maisons
    
    DrawHouse(9,7,can1)
    DrawTree(14, 9, can1)
    DrawTree(2, 2, can1)
    DrawTree(11, 0, can1)
    DrawTree(20, 1, can1)
    DrawTree(21, 5, can1)
    DrawTree(3, 17, can1)
    DrawTree(20, 14, can1)
    
    # Dessin des barrières
    
    DrawObject(0,8,251,True,can1,tilestbl)
    DrawObject(1,8,252,True,can1,tilestbl)
    DrawObject(1,7,227,True,can1,tilestbl)
    DrawObject(2,7,251,True,can1,tilestbl)
    DrawObject(3,7,251,True,can1,tilestbl)
    DrawObject(4,7,252,True,can1,tilestbl)
    DrawObject(4,6,227,True,can1,tilestbl)
    DrawObject(5,6,251,True,can1,tilestbl)
    DrawObject(6,6,252,True,can1,tilestbl)
    DrawObject(6,5,230,True,can1,tilestbl)
    DrawObject(6,4,230,True,can1,tilestbl)
    DrawObject(6,3,227,True,can1,tilestbl)
    for k in range(7,14) :
        DrawObject(k,3,251,True,can1,tilestbl)
    DrawObject(14,3,229,True,can1,tilestbl)
    DrawObject(14,4,250,True,can1,tilestbl)
    for k in range(15,19)  :
        DrawObject(k,4,251,True,can1,tilestbl)
    DrawObject(19,4,229,True,can1,tilestbl)
    for k in range(5,9) :
        DrawObject(19,k,230,True,can1,tilestbl)
    DrawObject(19,9,250,True,can1,tilestbl)
    for k in range(20,24):
        DrawObject(k,9,251,True,can1,tilestbl)
    
    # Dessin des fleurs
    
    DrawObject(2,16,141,True,can1,tilestbl)
    obj_coords_233 = [[2,15],[3,16],[3,15],[3,14],[1,17],[1,18],[2,18],[7,7],[7,9],[9,5],[10,6],[16,6],[17,8],[18,7]]
    for elt in obj_coords_233 :
        DrawObject(elt[0],elt[1],233,False,can1,tilestbl)
    obj_coords_256 = [[8,6],[9,7],[7,8],[5,8],[6,9],[11,6],[14,5],[17,5],[17,7],[19,10],[0,13],[1,13],[2,14],[1,15],[0,16],[2,19],[0,20],[1,21],[5,15],[6,16],[5,17]]
    for elt in obj_coords_256 :
        DrawObject(elt[0],elt[1],256,False,can1,tilestbl)
    DrawObject(12,17,162,True,can1,tilestbl)
    obj_coords_187 = [[13,17],[10,17],[10,18],[9,19],[13,16],[14,16],[16,17]]
    for elt in obj_coords_187 :
        DrawObject(elt[0],elt[1],187,False,can1,tilestbl)
    obj_coords_210 = [[11,18],[13,18],[10,16],[9,18],[8,19],[17,17],[17,16]]
    for elt in obj_coords_210 :
        DrawObject(elt[0],elt[1],210,False,can1,tilestbl)
    DrawObject(8,7,141,True,can1,tilestbl)
    DrawObject(9,9,209,False,can1,tilestbl)
    DrawObject(13,11,209,False,can1,tilestbl)
    DrawObject(9,11,209,False,can1,tilestbl)
    obj_coords_257 = [[1,1],[2,5],[6,2],[9,0],[16,2],[19,1],[22,3],[2,5]]
    for elt in obj_coords_257 :
        DrawObject(elt[0],elt[1],257,False,can1,tilestbl)
    DrawObject(15,0,258,False,can1,tilestbl)
    DrawObject(23,1,258,False,can1,tilestbl)
    DrawObject(20,7,258,False,can1,tilestbl)
    DrawObject(20,25,325,False,can1,tilestbl)
    DrawObject(23,5,323,False,can1,tilestbl)
    DrawObject(5,3,323,False,can1,tilestbl)
    DrawObject(9,1,326,False,can1,tilestbl)
    obj_coords_327 = [[0,4],[6,0],[17,0],[23,0],[23,10]]
    for elt in obj_coords_327 :
        DrawObject(elt[0],elt[1],327,False,can1,tilestbl)
    DrawObject(10,7,67,True,can1,tilestbl)
    
    # Entités
    
    if champ_collected[1] == False and player_story_lvl == 2:
        champ_2 = can1.create_image(12 * 32,  4 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([4, 12])
    if champ_collected[2] == False and player_story_lvl == 2:
        champ_3 = can1.create_image(5 * 32,  19 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([19, 5])
    if champ_collected[3] == False and player_story_lvl == 2:
        champ_4 = can1.create_image(17 * 32,  15 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([15, 17])
    
    # On dessine le personnage
    
    DrawPlayer(x, y, can1)
    
    ReloadChatBox()

def DrawMainHouse() :
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid, player_in_matrice, player_exeption_tiles
    player_in_matrice = main_house_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 16
    player_mid = 16
    player_pos_canX = 224
    player_exeption_tiles = []
    DrawMap(main_house_matrice, tilestblin, can1, 20, 20, 16)
    for elt in main_house_collisions :
        blocked_obj_tiles.append(elt)
    DrawObject(12,2,6,False,can1,tilestblin)
    DrawObject(13,2,8,False,can1,tilestblin)
    DrawObject(14,2,8,False,can1,tilestblin)
    DrawObject(15,2,18,False,can1,tilestblin)
    DrawObject(12,3,121,False,can1,tilestblin)
    DrawObject(13,3,125,False,can1,tilestblin)
    DrawObject(14,3,125,False,can1,tilestblin)
    DrawObject(15,3,126,False,can1,tilestblin)
    DrawObject(12,4,141,False,can1,tilestblin)
    DrawObject(13,4,142,False,can1,tilestblin)
    DrawObject(14,4,142,False,can1,tilestblin)
    DrawObject(15,4,143,False,can1,tilestblin)
    DrawObject(12,2,184,False,can1,tilestblin)
    DrawObject(13,2,185,False,can1,tilestblin)
    DrawObject(14,2,185,False,can1,tilestblin)
    DrawObject(15,2,186,False,can1,tilestblin)
    DrawObject(12,3,14,False,can1,tilestblin)
    DrawObject(15,3,15,False,can1,tilestblin)
    DrawObject(12,4,31,False,can1,tilestblin)
    DrawObject(15,4,32,False,can1,tilestblin)
    DrawObject(17,2,36,False,can1,tilestblin)
    DrawObject(17,3,53,False,can1,tilestblin)
    DrawObject(17,4,53,False,can1,tilestblin)
    DrawObject(17,5,78,True,can1,tilestblin)
    DrawObject(1,1,1,False,can1,tilestblin)
    DrawObject(8,1,2,False,can1,tilestblin)
    DrawObject(11,1,1,False,can1,tilestblin)
    DrawObject(18,1,2,False,can1,tilestblin)
    obj_coords_34 = [[3,4],[4,4],[5,4],[6,4],[3,1]]
    for elt in obj_coords_34 :
        DrawObject(elt[0],elt[1],34,False,can1,tilestblin)
    DrawObject(2,1,33,False,can1,tilestblin)
    DrawObject(2,4,33,False,can1,tilestblin)
    DrawObject(6,4,35,False,can1,tilestblin)
    DrawObject(4,1,35,False,can1,tilestblin)
    DrawObject(2,2,53,False,can1,tilestblin)
    DrawObject(3,2,53,False,can1,tilestblin)
    DrawObject(4,2,53,False,can1,tilestblin)
    DrawObject(2,5,50,True,can1,tilestblin)
    DrawObject(6,5,50,True,can1,tilestblin)
    DrawObject(3,5,51,True,can1,tilestblin)
    DrawObject(7,5,51,True,can1,tilestblin)
    DrawObject(7,4,35,True,can1,tilestblin)
    DrawObject(4,5,65,True,can1,tilestblin)
    DrawObject(5,5,66,True,can1,tilestblin)
    DrawObject(13,11,176,False,can1,tilestblin)
    DrawObject(14,11,177,False,can1,tilestblin)
    DrawObject(15,11,178,False,can1,tilestblin)
    DrawObject(13,12,192,False,can1,tilestblin)
    DrawObject(14,12,193,False,can1,tilestblin)
    DrawObject(15,12,194,False,can1,tilestblin)
    DrawObject(13,13,192,False,can1,tilestblin)
    DrawObject(14,13,193,False,can1,tilestblin)
    DrawObject(15,13,194,False,can1,tilestblin)
    DrawObject(13,14,22,False,can1,tilestblin)
    DrawObject(14,14,23,False,can1,tilestblin)
    DrawObject(15,14,24,False,can1,tilestblin)
    DrawObject(6,9,160,True,can1,tilestblin)
    DrawObject(7,9,161,True,can1,tilestblin)
    DrawObject(8,9,162,True,can1,tilestblin)
    DrawObject(6,10,171,True,can1,tilestblin)
    DrawObject(7,10,172,False,can1,tilestblin)
    DrawObject(8,10,173,True,can1,tilestblin)
    DrawObject(6,11,187,True,can1,tilestblin)
    DrawObject(7,11,188,True,can1,tilestblin)
    DrawObject(8,11,189,True,can1,tilestblin)
    DrawObject(7,9,79,False,can1,tilestblin)
    DrawObject(5,10,174,True,can1,tilestblin)
    DrawObject(9,10,175,True,can1,tilestblin)
    DrawObject(7,8,21,True,can1,tilestblin)
    DrawObject(7,12,20,True,can1,tilestblin) 
    DrawObject(3,13,195,True,can1,tilestblin)
    DrawObject(3,14,25,True,can1,tilestblin)
    
    DrawPlayer(10, 17, can1)
    
    DrawObject(5,9,163,False,can1,tilestblin)
    DrawObject(9,9,164,False,can1,tilestblin)
    DrawObject(7,7,191,False,can1,tilestblin)
    DrawObject(7,11,190,False,can1,tilestblin)
    
    ReloadChatBox()

def DrawPlageMap(x, y) :
    """ Dessine la partie EST de la map, la plage. En dessinant le personnage aux coordonnées x, y.
    x : int
    y : int
    """
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid,player_in_matrice, player_exeption_tiles, champ_5, champ_6
    player_in_matrice = plage_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 32
    player_pos_canX = 0
    player_mid = 0
    if player_story_lvl == 4 :
        player_exeption_tiles = (487,489,441,393,96,97,98,415,336,338,339,73,74,75,316,398)
    else :
        player_exeption_tiles = blocked_tiles
    
    # Dessin de la map (matrice)
    
    DrawMap(plage_matrice, tilestbl, can1, 24, 27, 32)
    
    # Dessin des arbres
    
    DrawTree(4,0,can1)
    DrawTree(1,3,can1)
    DrawObject(0,0,277,False,can1,tilestbl)
    DrawObject(0,1,300,False,can1,tilestbl)
    DrawObject(1,0,278,False,can1,tilestbl)
    DrawObject(1,1,301,False,can1,tilestbl)
    
    # Dessin des barrières
    
    obj_coords_251 = [[0,9],[1,9],[5,4],[6,4],[3,7]]
    for elt in obj_coords_251 :
        DrawObject(elt[0],elt[1],251,True,can1,tilestbl)
    obj_coords_252 = [[2,9],[7,4],[4,7],[8,1]]
    for elt in obj_coords_252 :
        DrawObject(elt[0],elt[1],252,True,can1,tilestbl)
    obj_coords_230 = [[2,8],[4,6],[4,5],[7,3],[7,2],[8,0]]
    for elt in obj_coords_230 :
        DrawObject(elt[0],elt[1],230,True,can1,tilestbl)
    DrawObject(2,7,227,True,can1,tilestbl)
    DrawObject(4,4,227,True,can1,tilestbl)
    DrawObject(7,1,227,True,can1,tilestbl)
    
    # Dessin des fleurs/cailloux/bush
    
    DrawObject(10,8,185,True,can1,tilestbl)
    obj_coords_186 = [[9,6],[10,6],[11,8],[10,9],[8,11]]
    for elt in obj_coords_186 :
        DrawObject(elt[0],elt[1],186,False,can1,tilestbl)
    obj_coords_209 = [[8,3],[9,4],[10,6],[10,7],[8,7],[9,8],[9,9],[9,10],[11,12]]
    for elt in obj_coords_209 :
        DrawObject(elt[0],elt[1],209,False,can1,tilestbl)
    obj_coords_325 = [[4,25],[18,26],[22,20],[22,2]]
    for elt in obj_coords_325 :
        DrawObject(elt[0],elt[1],325,False,can1,tilestbl)
    DrawObject(9,16,324,True,can1,tilestbl)
    DrawObject(18,8,326,False,can1,tilestbl)
    DrawObject(1,8,323,False,can1,tilestbl)
    DrawObject(3,2,323,False,can1,tilestbl)
    DrawObject(0,6,327,False,can1,tilestbl)
    DrawObject(6,3,327,False,can1,tilestbl)
    DrawObject(16,3,327,False,can1,tilestbl)
    DrawObject(9,16,327,False,can1,tilestbl)
    DrawObject(11,1,281,False,can1,tilestbl)
    DrawObject(5,7,281,False,can1,tilestbl)
    DrawObject(11,15,281,False,can1,tilestbl)
    DrawObject(0,5,304,False,can1,tilestbl)
    DrawObject(7,0,304,False,can1,tilestbl)
    DrawObject(2,0,257,False,can1,tilestbl)
    
    DrawObject(16,11,100,True,can1,tilestbl)
    
    # Entités
    
    if champ_collected[4] == False and player_story_lvl == 2:
        champ_5 = can1.create_image(7 * 32,  5 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([5, 7])
    if champ_collected[5] == False and player_story_lvl == 2:
        champ_6 = can1.create_image(10 * 32,  16 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([16, 10])
    
    # Dessin du joueur
    
    DrawPlayer(x, y, can1)
    
    ReloadChatBox()
    
def DrawWaterfallMap(x, y) :
    """ Dessine la partie OUEST de la map, la plage. En dessinant le personnage aux coordonnées x, y.
    x : int
    y : int
    """
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid,player_in_matrice, player_exeption_tiles
    player_in_matrice = waterfall_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 32
    player_pos_canX = 0
    player_mid = 0
    player_exeption_tiles = blocked_tiles
    
    DrawMap(waterfall_matrice, tilestbl, can1, 24, 27, 32)
    
    # Dessin des arbres
    
    DrawObject(22, 6, 250, True, can1, tilestbl)
    
    DrawTree(1,10,can1)
    DrawTree(11,11,can1)
    DrawTree(5,19,can1)
    DrawTree(20,16,can1)
    DrawTree(21,6,can1)
    
    # Dessin des barrières
    DrawObject(13, 7, 102, True, can1, tilestbl)
    DrawObject(23, 8, 250, True, can1, tilestbl)
    DrawObject(23, 7, 230, True, can1, tilestbl)
    DrawObject(23, 6, 229, True, can1, tilestbl)
    DrawObject(22, 5, 230, True, can1, tilestbl)
    DrawObject(22, 4, 230, True, can1, tilestbl)
    
    # Dessin des fleurs/cailloux/bush
    
    obj_coords_233 = [[3,16],[2,18],[2,19],[1,20],[10,11],[9,9],[15,21],[16,19],[17,20]]
    for elt in obj_coords_233 :
        DrawObject(elt[0],elt[1],233,False,can1,tilestbl)
    obj_coords_256 = [[4,14],[1,17],[3,17],[4,19],[3,20],[1,21],[17,18],[18,19],[16,20],[16,21],[18,21],[11,9],[9,10],[9,12],[1,1],[3,0],[4,1],[8,0],[14,2],[19,2],[21,0]]
    for elt in obj_coords_256 :
        DrawObject(elt[0],elt[1],256,False,can1,tilestbl)
    DrawObject(0, 15, 324, True, can1, tilestbl)
    DrawObject(3, 23, 324, True, can1, tilestbl)
    DrawObject(22, 21, 324, True, can1, tilestbl)
    DrawObject(10, 13, 323, True, can1, tilestbl)
    
    obj_coords_257 = [[0,8],[16,17],[15,8]]
    for elt in obj_coords_257 :
        DrawObject(elt[0],elt[1],257,True,can1,tilestbl)
    obj_coords_304 = [[1,0],[4,8],[6,24],[22,15],[19,1],[1,21],[17,18]]
    for elt in obj_coords_304 :
        DrawObject(elt[0],elt[1],304,True,can1,tilestbl)
    
    DrawObject(2, 8, 669, True, can1, tilestbl)
    
    DrawPlayer(x, y, can1)
    """
    if player_story_lvl == 4 :
        for k in blocked_obj_tiles :
           """ 
    
    ReloadChatBox()
    
def DrawForestMap(x, y) :
    """ Dessine la partie NORD OUEST de la map, la plage. En dessinant le personnage aux coordonnées x, y.
    x : int
    y : int
    """
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid,player_in_matrice, player_exeption_tiles, champ_collected, player_story_lvl, champ_1, rock_1, rock_2
    player_in_matrice = forest_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 32
    player_pos_canX = 0
    player_mid = 0
    player_exeption_tiles = blocked_tiles
    
    DrawMap(forest_matrice, tilestbl, can1, 24, 27, 32)
    
    # Dessin des arbres
    
    DrawObject(1, 0, 300, False, can1, tilestbl)
    DrawObject(2, 0, 301, False, can1, tilestbl)
    
    DrawObject(8, 0, 300, False, can1, tilestbl)
    DrawObject(9, 0, 301, False, can1, tilestbl)
    
    DrawObject(15, 0, 300, False, can1, tilestbl)
    DrawObject(16, 0, 301, False, can1, tilestbl)
    
    DrawObject(19, 0, 300, False, can1, tilestbl)
    DrawObject(20, 0, 301, False, can1, tilestbl)
    
    tree_coords = [[5,-1],[-1,-1],[10,-1],[20,-1],[2,0],[9,0],[13,0],[17,0],[22,0],[0,1],[6,1],[11,1],[16,1],[19,1],[3,2],[22,2],[18,2],[14,2],[1,3],[7,3],[10,3],[20,3],[2,4],[4,4],[8,4],[12,4],[15,4],[19,4],[22,4],[0,5],[6,5],[16,5],[3,6],[5,6],[18,6],[21,6],[1,7],[17,7],[20,7],[23,7],[-1,8],[2,8],[6,8],[4,9],[16,9],[19,9],[22,9],[0,10],[3,10],[21,10],[5,11],[18,11],[23,11],[2,12],[7,12],[17,12],[20,12],[1,13],[4,13],[6,13],[9,13],[15,13],[-1,14],[16,14],[19,14],[10,20],[14,21]]
    for elt in tree_coords :
        DrawTree(elt[0],elt[1],can1)
        
    # Dessin des fleurs/cailloux/bush/souches
    
    obj_coords_187 = [[13,12],[12,14],[15,19],[16,20],[18,19],[19,18],[0,26],[2,24]]
    for elt in obj_coords_187 :
        DrawObject(elt[0],elt[1],187,False,can1,tilestbl)
    obj_coords_210 = [[11,11],[11,12],[14,11],[12,13],[13,14],[14,15],[15,18],[14,20],[17,19],[18,20],[19,19],[20,18],[21,17],[1,22],[3,23],[1,24],[1,25],[1,26]]
    for elt in obj_coords_210 :
        DrawObject(elt[0],elt[1],210,False,can1,tilestbl)
    
    obj_coords_163 = [[4,0],[12,0],[8,2],[21,2],[0,4],[6,4],[13,3],[18,5],[22,13],[2,11],[0,13]]
    for elt in obj_coords_163 :
        DrawObject(elt[0],elt[1],163,False,can1,tilestbl)
    obj_coords_257 = [[2,17],[0,23],[3,26],[19,21],[18,10],[5,2]]
    for elt in obj_coords_257 :
        DrawObject(elt[0],elt[1],257,True,can1,tilestbl)
    obj_coords_304 = [[7,11],[16,8],[15,12],[18,17],[19,1],[1,21],[17,18]]
    for elt in obj_coords_304 :
        DrawObject(elt[0],elt[1],304,True,can1,tilestbl)
    DrawObject(10, 17, 326, False, can1, tilestbl)
    DrawObject(8, 23, 327, False, can1, tilestbl)
    DrawObject(4, 16, 327, False, can1, tilestbl)
    DrawObject(22, 24, 327, False, can1, tilestbl)
    DrawObject(15, 7, 323, False, can1, tilestbl)

    # Dessin de la maison
    
    DrawHouse(8,5,can1)
    DrawObject(8, 5, 277, False, can1, tilestbl)
    DrawObject(8, 6, 300, False, can1, tilestbl)
    
    # Entités
    
    if champ_collected[0] == False and player_story_lvl == 2:
        champ_1 = can1.create_image(9 * 32,  24 * 32, image=champ,anchor="nw", state = "normal")
        blocked_obj_tiles.append([24, 9])
    if rock_destroyed[0] == False :
        rock_1 = can1.create_image(12 * 32,  22 * 32, image=tilestbl[322],anchor="nw", state = "normal")
        blocked_obj_tiles.append([22, 12])
    if rock_destroyed[1] == False :
        rock_2 = can1.create_image(13 * 32,  22 * 32, image=tilestbl[322],anchor="nw", state = "normal")
        blocked_obj_tiles.append([22, 13])

    DrawPlayer(x, y, can1)
    
    ReloadChatBox()

def DrawForestHouse() :
    global player_move_px, player_pos_canX, blocked_obj_tiles, player_mid, player_in_matrice, player_exeption_tiles
    player_in_matrice = forest_house_matrice
    can1.delete("all")
    blocked_obj_tiles.clear()
    player_move_px = 16
    player_mid = 16
    player_pos_canX = 224
    player_exeption_tiles = []
    DrawMap(forest_house_matrice, tilestblin, can1, 20, 20, 16)
    for elt in main_house_collisions :
        blocked_obj_tiles.append(elt)
    DrawObject(12,2,6,False,can1,tilestblin)
    DrawObject(13,2,8,False,can1,tilestblin)
    DrawObject(14,2,8,False,can1,tilestblin)
    DrawObject(15,2,18,False,can1,tilestblin)
    DrawObject(12,3,121,False,can1,tilestblin)
    DrawObject(13,3,125,False,can1,tilestblin)
    DrawObject(14,3,125,False,can1,tilestblin)
    DrawObject(15,3,126,False,can1,tilestblin)
    DrawObject(12,4,141,False,can1,tilestblin)
    DrawObject(13,4,142,False,can1,tilestblin)
    DrawObject(14,4,142,False,can1,tilestblin)
    DrawObject(15,4,143,False,can1,tilestblin)
    DrawObject(12,2,86,False,can1,tilestblin)
    DrawObject(13,2,87,False,can1,tilestblin)
    DrawObject(14,2,87,False,can1,tilestblin)
    DrawObject(15,2,88,False,can1,tilestblin)
    DrawObject(12,3,99,False,can1,tilestblin)
    DrawObject(15,3,100,False,can1,tilestblin)
    DrawObject(12,4,109,False,can1,tilestblin)
    DrawObject(15,4,110,False,can1,tilestblin)
    DrawObject(17,2,36,False,can1,tilestblin)
    DrawObject(17,3,53,False,can1,tilestblin)
    DrawObject(17,4,53,False,can1,tilestblin)
    DrawObject(17,5,78,True,can1,tilestblin)
    DrawObject(1,1,1,False,can1,tilestblin)
    DrawObject(8,1,2,False,can1,tilestblin)
    DrawObject(11,1,1,False,can1,tilestblin)
    DrawObject(18,1,2,False,can1,tilestblin)
    obj_coords_34 = [[3,4],[4,4],[5,4],[6,4],[3,1]]
    for elt in obj_coords_34 :
        DrawObject(elt[0],elt[1],34,False,can1,tilestblin)
    DrawObject(2,1,33,False,can1,tilestblin)
    DrawObject(2,4,33,False,can1,tilestblin)
    DrawObject(6,4,35,False,can1,tilestblin)
    DrawObject(4,1,35,False,can1,tilestblin)
    DrawObject(2,2,53,False,can1,tilestblin)
    DrawObject(3,2,53,False,can1,tilestblin)
    DrawObject(4,2,53,False,can1,tilestblin)
    DrawObject(2,5,50,True,can1,tilestblin)
    DrawObject(6,5,50,True,can1,tilestblin)
    DrawObject(3,5,51,True,can1,tilestblin)
    DrawObject(7,5,51,True,can1,tilestblin)
    DrawObject(7,4,35,True,can1,tilestblin)
    DrawObject(4,5,65,True,can1,tilestblin)
    DrawObject(5,5,66,True,can1,tilestblin)
    
    DrawObject(13,11,80,False,can1,tilestblin)
    DrawObject(14,11,81,False,can1,tilestblin)
    DrawObject(15,11,82,False,can1,tilestblin)
    
    DrawObject(13,12,92,False,can1,tilestblin)
    DrawObject(14,12,93,False,can1,tilestblin)
    DrawObject(15,12,94,False,can1,tilestblin)
    
    DrawObject(13,13,92,False,can1,tilestblin)
    DrawObject(14,13,93,False,can1,tilestblin)
    DrawObject(15,13,94,False,can1,tilestblin)
    
    DrawObject(13,14,105,False,can1,tilestblin)
    DrawObject(14,14,107,False,can1,tilestblin)
    DrawObject(15,14,108,False,can1,tilestblin)
    
    DrawObject(6,9,160,True,can1,tilestblin)
    DrawObject(7,9,161,True,can1,tilestblin)
    DrawObject(8,9,162,True,can1,tilestblin)
    DrawObject(6,10,171,True,can1,tilestblin)
    DrawObject(7,10,172,False,can1,tilestblin)
    DrawObject(8,10,173,True,can1,tilestblin)
    DrawObject(6,11,187,True,can1,tilestblin)
    DrawObject(7,11,188,True,can1,tilestblin)
    DrawObject(8,11,189,True,can1,tilestblin)
    DrawObject(7,9,79,False,can1,tilestblin)
    DrawObject(5,10,174,True,can1,tilestblin)
    DrawObject(9,10,175,True,can1,tilestblin)
    DrawObject(7,8,21,True,can1,tilestblin)
    DrawObject(7,12,20,True,can1,tilestblin) 
    
    DrawObject(14,6,196,True,can1,tilestblin)
    DrawObject(14,7,25,True,can1,tilestblin)
    
    DrawPlayer(10, 17, can1)
    
    DrawObject(5,9,163,False,can1,tilestblin)
    DrawObject(9,9,164,False,can1,tilestblin)
    DrawObject(7,7,191,False,can1,tilestblin)
    DrawObject(7,11,190,False,can1,tilestblin)
    
    ReloadChatBox()


""" =============================
FONCTIONS DE DESSIN
=============================="""


def DrawTree(posX, posY, can) :
    """ Dessine un arbre sur la map (composé de plusieurs tiles) selon la "posX" ème case horizontale et la "posY" ème case verticale sur le canvas "can".
    posX : int
    posY : int
    can : le canvas sur lequel on veut dessiner l'arbre'
    """
    for y in range(3):
        for x in range(2):
            can.create_image((posX * 32) + (32*x),(posY * 32) + (32*y),image=tilestbl[tree_matrice[y][x] - 1],anchor="nw")
            if not [posY + y, posX + x] in blocked_obj_tiles :
                blocked_obj_tiles.append([posY + y, posX + x])

def DrawObject(posX, posY, int_obj, isSolid, can, img_list) :
    """ Dessine l'objet d'identidiant "int_obj" de taille 1x1 aux selon la "posX" ème case horizontale et la "posY" ème case verticale sur le canvas "can".
    Les collisions sont activées si isSolid est égal à True.
    posX : int
    posY : int
    can : le canvas sur lequel on veut dessiner l'arbre'
    isSolid : bool
    """
    can.create_image(posX * player_move_px + player_pos_canX,posY * player_move_px + player_pos_canX,image=img_list[int_obj - 1],anchor="nw")
    if isSolid == True :
        if not [posY, posX] in blocked_obj_tiles :
            blocked_obj_tiles.append([posY, posX])
        if player_in_matrice == main_house_matrice :
            blocked_obj_tiles.append([posY, posX-1])
    
def DrawHouse(posX, posY, can) :
    """ Dessine un arbre sur la map (composé de plusieurs tiles) selon la "posX" ème case horizontale et la "posY" ème case verticale sur le canvas "can".
    posX : int
    posY : int
    can : le canvas sur lequel on veut dessiner l'arbre'
    """
    exeptions = (48,296,319,320,276)
    for y in range(6):
        for x in range(4):
            can.create_image((posX * 32) + (32*x),(posY * 32) + (32*y),image=tilestbl[house_matrice_left[y][x] - 1],anchor="nw")
            if not house_matrice_left[y][x] in exeptions :
                blocked_obj_tiles.append([posY + y, posX + x])
    for y in range(5):
        for x in range(3):
            can.create_image((posX * 32) + (32*x) + 128,(posY * 32) + (32*y),image=tilestbl[house_matrice_right[y][x] - 1],anchor="nw")
            if not house_matrice_right[y][x] in exeptions :
                blocked_obj_tiles.append([posY + y, posX + x + 4])
            
def DrawPlayer(posX, posY, can) :
    """ Dessine le joueur selon la "posX" ème case horizontale et la "posY" ème case verticale sur le canvas "can".
    posX : int
    posY : int
    canv : le canvas sur lequel on veut dessiner l'arbre
    """
    global can_player, player_posX, player_posY
    player_posX = posX * player_move_px + player_pos_canX
    player_posY = posY * player_move_px + player_pos_canX
    can_player = can.create_image(posX * player_move_px + 5 + player_pos_canX,posY * player_move_px + player_pos_canX,image=start_texture,anchor="nw")


    
def DrawMap(draw_matrice, draw_imglist, can, sizeX, sizeY, tsize) :
    """ Dessine toutes les tiles d'une map de sizeX x sizeY avec une taille de 32px pour chaque tile.
    draw_matrice : tableau de tableau (matrice)
    can : le canvas sur lequel on veut dessiner la map
    """
    for i in range(sizeY):
        for j in range(sizeX):
            can.create_image(tsize*j + player_pos_canX, tsize*i + player_pos_canX, image=draw_imglist[draw_matrice[i][j] - 1],anchor="nw")

def DrawEndScreen() :
    """Dessine le message de fin."""
    can1.delete("all")
    global player_in_matrice, dlg_writing, player_itemcollected, player_exeption_tiles, can_player, player_posX, player_posY, player_look, player_move_px, player_pos_canX, player_mid, player_isindialog
    player_in_matrice = plage_matrice
    # Réinitialisation des variables pour redémarrage de la partie
    can_player = 0
    player_posX = 0
    player_posY = 0
    player_look = "Down"
    player_move_px = 32
    player_pos_canX = 0
    player_mid = 0
    player_isindialog = False
    player_exeption_tiles = blocked_tiles
    player_itemcollected = 0
    dlg_writing = False
    # Dessin du menu
    can1.create_image(1,1,image=end_menu_bg_texture,anchor="nw")
    backmenu_button = can1.create_image(302, 410, image=menubutton,anchor="nw", state = "normal")
    backmenu_text = can1.create_text(384,415,text="Menu",fill="gray75", anchor="n", font=font_title, state = "normal")
    can1.tag_bind(backmenu_button, "<Button-1>", lambda event: ButtonClicked(event, 3))
    can1.tag_bind(backmenu_text, "<Button-1>", lambda event: ButtonClicked(event, 3))
    

def DrawMainMenu() :
    """Dessine le menu d'accueil du jeu."""
    can1.delete("all")
    global player_in_matrice
    player_in_matrice = "menu"
    can1.create_image(1, 1, image=mainmenu_texture,anchor="nw", state = "normal")
    play_button = can1.create_image(302, 380, image=menubutton,anchor="nw", state = "normal")
    player_text = can1.create_text(384,385,text="Jouer",fill="gray75", anchor="n", font=font_title, state = "normal")
    can1.tag_bind(play_button, "<Button-1>", lambda event: ButtonClicked(event, 0))
    can1.tag_bind(player_text, "<Button-1>", lambda event: ButtonClicked(event, 0))
    
    control_button = can1.create_image(302, 440, image=menubutton,anchor="nw", state = "normal")
    control_text = can1.create_text(384,445,text="Controles",fill="gray75", anchor="n", font=font_title, state = "normal")
    can1.tag_bind(control_button, "<Button-1>", lambda event: ButtonClicked(event, 1))
    can1.tag_bind(control_text, "<Button-1>", lambda event: ButtonClicked(event, 1))
    
    credits_button = can1.create_image(302, 500, image=menubutton,anchor="nw", state = "normal")
    credits_text = can1.create_text(384,505,text="Credits",fill="gray75", anchor="n", font=font_title, state = "normal")
    can1.tag_bind(credits_button, "<Button-1>", lambda event: ButtonClicked(event, 2))
    can1.tag_bind(credits_text, "<Button-1>", lambda event: ButtonClicked(event, 2))
    
    quit_button = can1.create_image(302, 560, image=menubutton,anchor="nw", state = "normal")
    quit_text = can1.create_text(384,565,text="Quitter",fill="gray75", anchor="n", font=font_title, state = "normal")
    can1.tag_bind(quit_button, "<Button-1>", lambda event: ButtonClicked(event, 4))
    can1.tag_bind(quit_text, "<Button-1>", lambda event: ButtonClicked(event, 4))

def DrawControlMenu():
    """Dessine le menu avec la légende des touches."""
    can1.delete("all")
    global player_in_matrice
    player_in_matrice = "menu"
    can1.create_image(1, 1, image=mainmenu_texture,anchor="nw", state = "normal")
    can1.create_image(234, 380, image=panel,anchor="nw", state = "normal")
    close_button = can1.create_image(264, 410, image=backbutton,anchor="nw", state = "normal")
    can1.tag_bind(close_button, "<Button-1>", lambda event: ButtonClicked(event, 3))
    
    can1.create_text(384,410,text="Controles",fill="gray28", anchor="n", font=font_title, state = "normal")
    can1.create_text(255,470,text="Flèche du haut      : Déplacement vers le haut",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,500,text="Flèche du bas        : Déplacement vers le bas",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,530,text="Flèche de droite   : Déplacement vers la droite",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,560,text="Flèche de gauche : Déplacement vers la gauche",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,590,text="Espace                     : Intéragir",fill="gray33", anchor="nw", font=font_base, state = "normal")


def DrawCreditMenu():
    """Dessine le menu avec la légende des touches."""
    can1.delete("all")
    global player_in_matrice, play_button, settings_button
    player_in_matrice = "menu"
    can1.create_image(1, 1, image=mainmenu_texture,anchor="nw", state = "normal")
    can1.create_image(234, 380, image=panel,anchor="nw", state = "normal")
    close_button = can1.create_image(264, 410, image=backbutton,anchor="nw", state = "normal")
    can1.tag_bind(close_button, "<Button-1>", lambda event: ButtonClicked(event, 3))
    
    can1.create_text(384,410,text="Credits",fill="gray28", anchor="n", font=font_title, state = "normal")
    can1.create_text(255,470,text="Design des cases exterieures par Ivan Voirol",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,500,text="Design des cases interieures par Bonsaiheldin",fill="gray33", anchor="nw", font=font_base, state = "normal")
    can1.create_text(255,530,text="Interface graphique par Kenney, www.kenney.nl",fill="gray33", anchor="nw", font=font_base, state = "normal")


def ButtonClicked(event, but_num) :
    """Execute un certain code selon le button d'interface cliqué par l'utilisateur
    event : evenement (class)
    but_num : int (identifiant du boutton)
    """
    global player_story_lvl
    if but_num == 0 :
        DrawMainMap(9,16)
        can1.after(200, DrawDialog, dialog_0)
    elif but_num == 1 :
        DrawControlMenu()
    elif but_num == 2 :
        DrawCreditMenu()
    elif but_num == 3 :
        player_story_lvl = 0
        DrawMainMenu()
    elif but_num == 4 :
        Mafenetre.destroy()
    else :
        pass

""" =============================
FONCTIONS D'INTERACTION
=============================="""

def OnKeyPressed(event) :
    """ Fonction appellée lorsque l'utilisateur appuye sur une touche.
    event : evenement recu sur pression de la touche
    """
    global player_posX, player_posY, next_move, player_in_matrice
    key = event.keysym
    if player_story_lvl != 5 and player_in_matrice != "menu" :
        if next_move < time() :
            next_move = time() + 0.13
            if player_isindialog == False :
                if key == "Up":
                    IsEvent(key)
                    MoveUp(key)
                if key == "Right":
                    IsEvent(key)
                    MoveRight(key)
                if key == "Left":
                    IsEvent(key)
                    MoveLeft(key)
                if key == "Down":
                    IsEvent(key)
                    MoveDown(key)
            if key == "space":
                IsEvent(key)

# Fonction de mouvement (Move)

def MoveUp(key) :
    """ Déplace le personnage vers la case supérieure. 
    key : str (touche pressée)
    """
    global can_player,player_posX,player_posY
    if player_posY > 0 :
        ply_cantmove = IsNextTileBlocked(key)
        if ply_cantmove == False :
            player_posY -= player_move_px
    if player_in_matrice != main_house_matrice and player_in_matrice != forest_house_matrice :
        can1.coords(can_player,player_posX + 5,player_posY - 8)
    else :
        can1.coords(can_player,player_posX + 5,player_posY)
    RefreshPlyImage(key)

def MoveRight(key) :
    """ Déplace le personnage vers la case latérale droite. 
    key : str (touche pressée)
    """
    global can_player,player_posX,player_posY
    if player_posX < 736 :
        ply_cantmove = IsNextTileBlocked(key)
        if ply_cantmove == False :
            player_posX += player_move_px
    if player_in_matrice != main_house_matrice and player_in_matrice != forest_house_matrice :
        can1.coords(can_player,player_posX + 5,player_posY - 8)
    else :
        can1.coords(can_player,player_posX + 5,player_posY)
    RefreshPlyImage(key)


def MoveLeft(key) :
    """ Déplace le personnage vers la case latérale gauche.
    key : str (touche pressée)
    """
    global can_player,player_posX,player_posY
    if player_posX > 0 :
        ply_cantmove = IsNextTileBlocked(key)
        if ply_cantmove == False :
            player_posX -= player_move_px
    if player_in_matrice != main_house_matrice and player_in_matrice != forest_house_matrice :
        can1.coords(can_player,player_posX + 5,player_posY - 8)
    else :
        can1.coords(can_player,player_posX + 5,player_posY)
    RefreshPlyImage(key)

def MoveDown(key) :
    """ Déplace le personnage vers la case inférieure. 
    key : str (touche pressée)
    """
    global can_player,player_posX,player_posY
    if player_posY < 832 :
        ply_cantmove = IsNextTileBlocked(key)
        if ply_cantmove == False :
            player_posY += player_move_px
    if player_in_matrice != main_house_matrice and player_in_matrice != forest_house_matrice :
        can1.coords(can_player,player_posX + 5,player_posY - 8)
    else :
        can1.coords(can_player,player_posX + 5,player_posY)
    RefreshPlyImage(key)

# Fonctions de vérification / actualisation

def IsNextTileBlocked(key) :
    """ Vérifie si la prochaine case de coordonnée ply_pX,ply_pY est bloqué ou non à cause d'un objet ou d'un type de case innaccessible.
    ply_pX : int (position du joueur en X)
    ply_pY : int (position du joueur en Y)
    key : str (nom de la touche préssée)
    """
    global player_pos_canX, player_move_px, player_mid, player_posX,player_posY
    line = (player_posY - player_pos_canX + player_mid) // player_move_px
    column = (player_posX - player_pos_canX) // player_move_px
    if key == "Up" :
        next_coords = [line - 1, column]
        if next_coords in blocked_obj_tiles or player_in_matrice[next_coords[0]][next_coords[1]] in player_exeption_tiles :
            return True
        else:
            return False
    elif key == "Down" :
        next_coords = [line + 1, column]
        if next_coords in blocked_obj_tiles or player_in_matrice[next_coords[0]][next_coords[1]] in player_exeption_tiles :
            return True
        else:
            return False
    elif key == "Right" :
        next_coords = [line, column + 1]
        if next_coords in blocked_obj_tiles or player_in_matrice[next_coords[0]][next_coords[1]] in player_exeption_tiles :
            return True
        else:
            return False
    elif key == "Left" :
        next_coords = [line, column - 1]
        if next_coords in blocked_obj_tiles or player_in_matrice[next_coords[0]][next_coords[1]] in player_exeption_tiles :
            return True
        else:
            return False
    else :
        return False

def IsEvent(key) :
    """ Vérifie pour chaque interaction de l'utilisateur si un evenement est déclenché.
    key : str (nom de la touche pressée)
    """
    # Stockage des informations concernants l'action du personnage.
    
    global player_pos_canX, player_move_px, player_mid, player_posX, player_posY, player_isindialog, dlg_writing, player_story_lvl, player_look, player_itemcollected, blocked_obj_tiles
    l = (player_posY - player_pos_canX + player_mid) // player_move_px
    c = (player_posX - player_pos_canX) // player_move_px
    front_case = (0,0)
    if player_look == "Up" :
        front_case = (l - 1, c)
    elif player_look == "Down" :
        front_case = (l + 1, c)
    elif player_look == "Right" :
        front_case = (l, c + 1)
    elif player_look == "Left" :
        front_case = (l, c - 1)
    
    # Evenements de la maison principale
    
    if player_in_matrice == main_house_matrice :
        if front_case == (20,10) and key == "Down" :
            door_sound.play()
            DrawMainMap(12,11)
        # Dialogue avec le PNJ
        if front_case == (14,3) and key == "space" and player_isindialog == False and dlg_writing == False:
            if player_story_lvl == 0 :
                can1.after(10, DrawDialog, dialog_1) 
                player_story_lvl = 1
            else :
                can1.after(10, DrawDialog, dialog_2) 

    
    # Evenements de la carte centrale      
    
    if player_in_matrice == main_matrice :
        if front_case == (11,12) and key == "space" :
            door_sound.play()
            DrawMainHouse()
        if player_posX == 736 and key == "Right":
            DrawPlageMap(0, player_posY // 32)
            RefreshPlyImage(key)
        if player_posX == 0 and key == "Left":
            DrawWaterfallMap(23, player_posY // 32)
            RefreshPlyImage(key)
        # Entités
        if front_case == (4,12) and key == "space" and champ_collected[1] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_2, state = "hidden")
            champ_collected[1] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [4,12] :
                    blocked_obj_tiles.pop(i)
                    break
        if front_case == (19,5) and key == "space" and champ_collected[2] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_3, state = "hidden")
            champ_collected[2] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [19,5] :
                    blocked_obj_tiles.pop(i)
                    break
        if front_case == (15,17) and key == "space" and champ_collected[3] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_4, state = "hidden")
            champ_collected[3] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [15,17] :
                    blocked_obj_tiles.pop(i)
                    break
    
    # Evenements de la carte cascade
    
    if player_in_matrice == waterfall_matrice :
        if front_case == (7,13) and key == "space" and player_isindialog == False and dlg_writing == False and player_look == "Up":
            can1.after(10, DrawDialog, dialog_10) 
        if player_posY == 0 and key == "Up":
            DrawForestMap(player_posX // 32, 26)
            RefreshPlyImage(key)
        if player_posX == 736 and key == "Right":
            DrawMainMap(0, player_posY // 32)
            RefreshPlyImage(key)
        if front_case == (8,2) and key == "space" and player_isindialog == False and dlg_writing == False and player_look == "Up":
            if player_story_lvl == 0 :
                can1.after(10, DrawDialog, dialog_4) 
            elif player_story_lvl == 1 :
                can1.after(10, DrawDialog, dialog_5)
                player_story_lvl = 2
            elif player_story_lvl == 2 :
                if player_itemcollected >= 6 :
                    can1.after(10, DrawDialog, dialog_7)
                    player_story_lvl = 3
                else :
                    can1.after(10, DrawDialog, dialog_6)
            else :
                can1.after(10, DrawDialog, dialog_4)
    
    
    # Evenements de la carte plage
            
    if player_in_matrice == plage_matrice :
        if player_posX == 0 and key == "Left":
            DrawMainMap(23, player_posY // 32)
            RefreshPlyImage(key)
        if player_posX == 736 and key == "Right" and player_story_lvl == 4:
            DrawEndScreen()
            player_story_lvl = 5
        if front_case == (11,16) and key == "space" and player_isindialog == False and dlg_writing == False and player_look == "Up":
            can1.after(10, DrawDialog, dialog_3) 
        # Entités
        if front_case == (5,7) and key == "space" and champ_collected[4] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_5, state = "hidden")
            champ_collected[4] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [5,7] :
                    blocked_obj_tiles.pop(i)
                    break
        if front_case == (16,10) and key == "space" and champ_collected[5] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_6, state = "hidden")
            champ_collected[5] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [16,10] :
                    blocked_obj_tiles.pop(i)
                    break
    
    # Evenements de la carte foret
    
    if player_in_matrice == forest_matrice :
        if player_posY == 832 and key == "Down":
            DrawWaterfallMap(player_posX // 32, 0)
            RefreshPlyImage(key)
            
        if front_case == (9,11) and key == "space" :
            door_sound.play()
            DrawForestHouse()
        if front_case == (24,9) and key == "space" and champ_collected[0] == False and player_story_lvl == 2:
            harvest_sound.play()
            can1.itemconfig(champ_1, state = "hidden")
            champ_collected[0] = True
            player_itemcollected += 1
            for i in range(0, len(blocked_obj_tiles)) :
                if blocked_obj_tiles[i] == [24,9] :
                    blocked_obj_tiles.pop(i)
                    break
        if front_case == (22,12) and key == "space" and rock_destroyed[0] == False :
            if player_story_lvl == 3:
                hit_sound.play()
                can1.itemconfig(rock_1, state = "hidden")
                rock_destroyed[0] = True
                player_itemcollected += 1
                for i in range(0, len(blocked_obj_tiles)) :
                    if blocked_obj_tiles[i] == [22,12] :
                        blocked_obj_tiles.pop(i)
                        break
            elif player_isindialog == False and dlg_writing == False:
                can1.after(10, DrawDialog, dialog_11)
        if front_case == (22,13) and key == "space" and rock_destroyed[1] == False :
            if player_story_lvl >= 3:
                hit_sound.play()
                can1.itemconfig(rock_2, state = "hidden")
                rock_destroyed[1] = True
                player_itemcollected += 1
                for i in range(0, len(blocked_obj_tiles)) :
                    if blocked_obj_tiles[i] == [22,13] :
                        blocked_obj_tiles.pop(i)
                        break
            elif player_isindialog == False and dlg_writing == False:
                can1.after(10, DrawDialog, dialog_11)
            
    
    # Evenements de la maison de l'hermite
    
    if player_in_matrice == forest_house_matrice :
        if front_case == (20,10) and key == "Down" :
            door_sound.play()
            DrawForestMap(11,9)
        if front_case == (7,14) and key == "space" and player_isindialog == False and dlg_writing == False:
            if player_story_lvl == 3 :
                can1.after(10, DrawDialog, dialog_8) 
                player_story_lvl = 4
            else :
                can1.after(10, DrawDialog, dialog_9)
    # Changement de la valeur pour passer à la prochaine réplique du dialogue
    if key == "space" and dlg_writing == False: 
        global_int.set(random.randint(0, 99**4))

""" =============================
FONCTIONS DE DIALOGUE
=============================="""

def ReloadChatBox():
    """ Recréer les éléments de la chat box, appellée après la suppression des éléments du canvas."""
    global cb_box, cb_author, cb_txt
    cb_box = can1.create_image(20, 724, image=chatbox_texture,anchor="nw", state = "hidden")
    cb_author = can1.create_text(45,745,text="",fill="White", anchor="nw", font=font_title, state = "hidden")
    cb_txt = can1.create_text(60,780,text="",fill="White", anchor="nw", font=font_base, state = "hidden")

def InitDialog(dlg, num) :
    """ Initialise toutes les variables nécéssaires pour afficher la réplique du dialogue.
    dlg : tuple contenant les textes et les auteurs de chaque prise de parole.
    num : int
    """
    global dlg_etapes, dlg_counter, dlg_start, player_isindialog
    dlg_etapes = []
    dlg_start = ""
    dlg_counter = 0
    phrase = dlg[num][0]
    for i in range(len(phrase) + 1) :
        dlg_etapes.append(phrase[:i])
    can1.itemconfig(cb_box, state = "normal")
    can1.itemconfig(cb_txt, text = "", state = "normal")
    can1.itemconfig(cb_author, text = "", state = "normal")

def DrawChat(dlg, num) :
    """ Affiche une réplique de dialogue sur l'écran.
    dlg : tuple contenant les textes et les auteurs de chaque prise de parole.
    num : int
    """
    global dlg_etapes, dlg_counter, dlg_start, player_isindialog, dlg_writing
    dlg_writing = True
    player_isindialog = True
    can1.itemconfig(cb_txt, text = dlg_start)
    can1.itemconfig(cb_author, text = dlg[num][1])
    dlg_start = dlg_etapes[dlg_counter]
    dlg_counter += 1
    if dlg_start == dlg[num][0]: 
        dlg_writing = False
        dlg_etapes = []
        dlg_start = ""
        dlg_counter = 0
    else: 
        can1.after(20, DrawChat, dlg, num) 

def DrawDialog(dlg) :
    """ Démarre un dialogue avec les répliques contenues dans "dlg".
    dlg : tuple contenant les textes et les auteurs de chaque prise de parole.
    """
    global global_int,player_isindialog
    for elt in range(len(dlg)) :
        InitDialog(dlg, elt)
        DrawChat(dlg, elt)
        Mafenetre.wait_variable(global_int)
        can1.itemconfig(cb_box, state = "hidden")
        can1.itemconfig(cb_txt, text = "", state = "hidden")
        can1.itemconfig(cb_author, text = "", state = "hidden")
    player_isindialog = False
    
def RefreshPlyImage(key) :
    """Actualise l'image du personnage selon la direction qu'il empreinte (key).
    key : str
    """
    global player_look
    player_look = key
    if move_ply_count_dict[key] == 7 :
        move_ply_count_dict[key] = 0
    else :
        move_ply_count_dict[key] += 1
    can1.itemconfig(can_player,image=move_ply_dict[key][move_ply_count_dict[key]])


""" =============================
STOCKAGE DES IMAGES
=============================="""

# Stockage de toutes les tiles du pack dans le tableau "tilestbl".

tilestbl = [0]

for k in range(2,669):
    maptile = PhotoImage(file="img/32x32_map_tile-v3_" + str(k) + ".gif")
    tilestbl.append(maptile)

tilestblin = []

for k in range(1,195):
    indoortile = PhotoImage(file="img/indoor/indoor_" + str(k) + ".gif")
    tilestblin.append(indoortile)
    
# Stockage de toutes les tiles du mouvement du personnage vers le bas dans le tableau "tilesmove_down".

for k in range(1,9):
    movetile = PhotoImage(file="img/player/Player-Base_" + str(k) + ".gif")
    move_ply_dict["Down"].append(movetile)

# Stockage de toutes les tiles du mouvement du personnage vers le haut dans le tableau "tilesmove_up".

for k in range(9,17):
    movetile = PhotoImage(file="img/player/Player-Base_" + str(k) + ".gif")
    move_ply_dict["Up"].append(movetile)

# Stockage de toutes les tiles du mouvement du personnage vers le bas dans le tableau "tilesmove_left".

for k in range(17,25):
    movetile = PhotoImage(file="img/player/Player-Base_" + str(k) + ".gif")
    move_ply_dict["Left"].append(movetile)

# Stockage de toutes les tiles du mouvement du personnage vers le bas dans le tableau "tilesmove_right".

for k in range(25,33):
    movetile = PhotoImage(file="img/player/Player-Base_" + str(k) + ".gif")
    move_ply_dict["Right"].append(movetile)

# Stockage de l'image d'apparition du personnage.

start_texture = PhotoImage(file="img/player/Player-Base_9.gif")

chatbox_texture = PhotoImage(file="img/chatbox.gif")

pnj_mh_texture = PhotoImage(file="img/player/npc1.gif")
tilestblin.append(pnj_mh_texture)

pnj_wf_texture = PhotoImage(file="img/player/npc2.gif")
tilestbl.append(pnj_wf_texture)

pnj_fh_texture = PhotoImage(file="img/player/npc3.gif")
tilestblin.append(pnj_fh_texture)

champ = PhotoImage(file="img/champignon.gif")
tilestbl.append(champ)

endscreen_texture = PhotoImage(file="img/endscreen.gif")

mainmenu_texture = PhotoImage(file="img/main_map_s_t.gif")
end_menu_bg_texture = PhotoImage(file="img/plage_map_s.gif")

menubutton = PhotoImage(file="img/button.gif")
panel = PhotoImage(file="img/gpanel.gif")
panelin = PhotoImage(file="img/panelInset_beige.gif")
backbutton = PhotoImage(file="img/arrowBrown_left.gif")

""" =============================
STOCKAGE DES SONS
=============================="""

pygs.init()

door_sound = pygs.Sound("sounds/door.ogg")
door_sound.set_volume(0.1)

hit_sound = pygs.Sound("sounds/hit.ogg")
hit_sound.set_volume(0.1)

harvest_sound = pygs.Sound("sounds/harvest.ogg")
harvest_sound.set_volume(0.1)

""" =============================
PROGRAMME PRINCIPAL - MONDE CENTRAL
=============================="""

DrawMainMenu()
# Detection touche et mainloop

can1.focus_set()    
can1.bind('<Key>',OnKeyPressed)
Mafenetre.mainloop()

