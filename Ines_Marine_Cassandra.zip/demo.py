#creation d'une bitmap
#modules
from tkinter import *
from pygame import mixer
mixer.init()
mixer.music.load("background_theme.mp3")
mixer.music.play()
mixer.music.play(loops=-1, start=0.0)
mixer.music.rewind()

#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('450x500')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=450,height=6500)
y_scroll=-5850
can1.place(x=0,y=y_scroll)
#creation des cases images
bhaut12=PhotoImage(file="bhaut12.gif")
good_ending=PhotoImage(file="good_ending.gif")
gameover=PhotoImage(file="gameover.gif")
carb1f=PhotoImage(file="carb1f.gif")
carb2f=PhotoImage(file="carb2f.gif")
carf1f=PhotoImage(file="carf1f.gif")
carf2f=PhotoImage(file="carf2f.gif")
jauge=PhotoImage(file="jauge.gif")
jauge2=PhotoImage(file="jauge2.gif")
jauge3=PhotoImage(file="jauge3.gif")
jauge4=PhotoImage(file="jauge4.gif")
jauge5=PhotoImage(file="jauge5.gif")
gnasha=PhotoImage(file="gnasha.gif")
dnashb=PhotoImage(file="dnashb.gif")
dnasha=PhotoImage(file="dnasha.gif")
cb=PhotoImage(file="cb.gif")
roadh5=PhotoImage(file="roadh5.gif")
roadh2=PhotoImage(file="roadh2.gif")
road=PhotoImage(file="road.gif")
poto=PhotoImage(file="poto.gif")
potog=PhotoImage(file="potog.gif")
potod=PhotoImage(file="potod.gif")
potodf=PhotoImage(file="potodf.gif")
nashb=PhotoImage(file="nashb.gif")
nasha=PhotoImage(file="nasha.gif")
nash=PhotoImage(file="nash.gif")
gnashb=PhotoImage(file="gnashb.gif")
ca=PhotoImage(file="ca.gif")
bnashb=PhotoImage(file="bnashb.gif")
bnasha=PhotoImage(file="bnasha.gif")
bnash=PhotoImage(file="bnash.gif")
bhaut3=PhotoImage(file="bhaut3.gif")
bhaut2=PhotoImage(file="bhaut2.gif")
bhaut1=PhotoImage(file="bhaut1.gif")
bbase3=PhotoImage(file="bbase3.gif")
bbase2=PhotoImage(file="bbase2.gif")
bbase1=PhotoImage(file="bbase1.gif")
roadh3=PhotoImage(file="roadh3.gif")
roadh4=PhotoImage(file="roadh4.gif")
bshad=PhotoImage(file="bshad.gif")
fire=PhotoImage(file="fire.gif")
fire2=PhotoImage(file="fire2.gif")
lvl2a=PhotoImage(file="lvl2a.gif")
lvl2b=PhotoImage(file="lvl2b.gif")
lvl2c=PhotoImage(file="lvl2c.gif")
lvl2c2=PhotoImage(file="lvl2c2.gif")
lvl2d=PhotoImage(file="lvl2d.gif")
lvl2e=PhotoImage(file="lvl2e.gif")
lvl2f=PhotoImage(file="lvl2f.gif")
poto2=PhotoImage(file="poto2.gif")
dnash=PhotoImage(file="dnash.gif")
gnash=PhotoImage(file="gnash.gif")
zombie1=PhotoImage(file="zombie1.gif")
zombie2=PhotoImage(file="zombie2.gif")
zombie3=PhotoImage(file="zombie3.gif")
zombie4=PhotoImage(file="zombie4.gif")
zombief1=PhotoImage(file="zombief1.gif")
zombief2=PhotoImage(file="zombief2.gif")
zombief3=PhotoImage(file="zombief3.gif")
zombief4=PhotoImage(file="zombief4.gif")
dc1=PhotoImage(file="dc1.gif")
dc2=PhotoImage(file="dc2.gif")
dc3=PhotoImage(file="dc3.gif")
dc4=PhotoImage(file="dc4.gif")
dc5=PhotoImage(file="dc5.gif")
dc6=PhotoImage(file="dc6.gif")
dc7=PhotoImage(file="dc7.gif")
dc8=PhotoImage(file="dc8.gif")
dc9=PhotoImage(file="dc9.gif")
dc10=PhotoImage(file="dc10.gif")
dr1=PhotoImage(file="dr1.gif")
dr2=PhotoImage(file="dr2.gif")
dr3=PhotoImage(file="dr3.gif")
dr4=PhotoImage(file="dr4.gif")
dr5=PhotoImage(file="dr5.gif")
dr6=PhotoImage(file="dr6.gif")
dr7=PhotoImage(file="dr7.gif")
dr8=PhotoImage(file="dr8.gif")
dr9=PhotoImage(file="dr9.gif")
dr10=PhotoImage(file="dr10.gif")
d1=PhotoImage(file="1.gif")
d2=PhotoImage(file="2.gif")
d3=PhotoImage(file="3.gif")
d4=PhotoImage(file="4.gif")
d5=PhotoImage(file="5.gif")
d6=PhotoImage(file="6.gif")
d7=PhotoImage(file="7.gif")
d8=PhotoImage(file="8.gif")
d9=PhotoImage(file="9.gif")
d10=PhotoImage(file="10.gif")
d11=PhotoImage(file="11.gif")
d12=PhotoImage(file="12.gif")
d13=PhotoImage(file="13.gif")
d14=PhotoImage(file="14.gif")
di1=PhotoImage(file="di1.gif")
di2=PhotoImage(file="di2.gif")
di3=PhotoImage(file="di3.gif")
di4=PhotoImage(file="di4.gif")
di5=PhotoImage(file="di5.gif")
di6=PhotoImage(file="di6.gif")
di7=PhotoImage(file="di7.gif")
di8=PhotoImage(file="di8.gif")
di9=PhotoImage(file="di9.gif")
di10=PhotoImage(file="di10.gif")
di11=PhotoImage(file="di11.gif")
di12=PhotoImage(file="di12.gif")
di13=PhotoImage(file="di13.gif")
di14=PhotoImage(file="di14.gif")
dia1=PhotoImage(file="dia1.gif")
dia2=PhotoImage(file="dia2.gif")
dia3=PhotoImage(file="dia3.gif")
dia4=PhotoImage(file="dia4.gif")
dia5=PhotoImage(file="dia5.gif")
dia6=PhotoImage(file="dia6.gif")
dia7=PhotoImage(file="dia7.gif")
dia8=PhotoImage(file="dia8.gif")
dia9=PhotoImage(file="dia9.gif")
dia10=PhotoImage(file="dia10.gif")
dia11=PhotoImage(file="dia11.gif")
dia12=PhotoImage(file="dia12.gif")
dia13=PhotoImage(file="dia13.gif")
dia14=PhotoImage(file="dia14.gif")
lvl3d=PhotoImage(file="lvl3d.gif")
lvl4d=PhotoImage(file="lvl4d.gif")
lvl5d=PhotoImage(file="lvl5d.gif")
cat=PhotoImage(file="catt.gif")
bro=PhotoImage(file="bro.gif")
cat2=PhotoImage(file="cat.gif")
pnj1=PhotoImage(file="pnj1.gif")
pnj1b=PhotoImage(file="pnj1b.gif")
entry=PhotoImage(file="entry.gif")
entrys=PhotoImage(file="entrys.gif")
pnj2=PhotoImage(file="pnj2.gif")
pnj2b=PhotoImage(file="pnj2b.gif")
carf1=PhotoImage(file="carf1.gif")
carf2=PhotoImage(file="carf2.gif")
carb1=PhotoImage(file="carb1.gif")
carb2=PhotoImage(file="carb2.gif")
tab_droite=[dnashb,dnasha]
tab_haut=[bnashb,bnasha]
tab_bas=[nasha,nashb]
tab_gauche=[gnashb,gnasha]
compteur_de_pas=0
#creation de la matrice
L130=["S","S","S","S","S","S","S","S","S"]
L129=["B1","B2","B3","B2","B1","B3","B2","B1","B3"]
L128=["H2","H3","H2","H3","B12","H1","H3","H1","H2"]
L127=["B1","B2","B1","B3","EN","B1","B3","B1","B3"]
L126=["S","PG","R1","R1","ES","R1","R3","PD","S"]
L125=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L124=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L123=["S","PG","R1","R1","R1","CF2","CB1","PD","S"]
L122=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L121=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L120=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L119=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L118=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L117=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L116=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L115=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L114=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L113=["R1","R1","R1","E","R1","F","R1","R1","R1"]
L112=["P2","P2","A","B","C","D5","P2","P2","P2"]    #level5
L111=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L110=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L109=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L108=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L107=["H2","H1","R1","R1","R1","R1","R1","H3","H1"]
L106=["B3","B1","CB","R1","R1","R1","CA","B3","B2"]
L105=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L104=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L103=["B2","B3","CF1","CB2","R1","R1","R1","B2","B1"] #car
L102=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L101=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L100=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L99=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L98=["B2","B3","R1","R2","Z4","R1","R1","B2","B1"]
L97=["S","PG","R1","Z3","BR","Z1","CB","PD","S"]   #bro
L96=["H2","H3","R1","R1","Z2","R1","R1","H1","H2"]
L95=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L94=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L93=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L92=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L91=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L90=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L89=["B2","B3","R1","R2","R1","CF1","CB1","B2","B3"]  #car
L88=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L87=["H2","H1","R1","R1","R1","R1","R1","H3","H1"]
L86=["B3","B1","CB","R1","R1","R1","CA","B3","B2"]
L85=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L84=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L83=["B2","B3","R1","R2","R1","R1","R1","B2","B1"]
L82=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L81=["R1","R1","R1","E","R1","F","R1","R1","R1"]
L80=["P2","P2","A","B","C","D4","P2","P2","P2"]    #level4
L79=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L78=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L77=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L76=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L75=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L74=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L73=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L72=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L71=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L70=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L69=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L68=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L67=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L66=["R1","CA","R1","R1","Z4","R1","R1","PD2","R1"]
L65=["S","PG","R1","Z1","PNJ2","Z2","R4","PD","S"]    #zombies
L64=["H2","H1","R1","R1","Z3","R1","R1","H3","H1"]
L63=["B3","B1","CB","R1","R1","R1","CA","B3","B2"]
L62=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L61=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L60=["B3","B1","R1","R1","R1","R1","R1","PD2","CA"]
L59=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L58=["H2","H1","R1","R3","R1","R1","R1","H3","H1"]
L57=["B3","B1","R4","R1","R1","R1","R5","B3","B2"]
L56=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L55=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L54=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L53=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L52=["R1","R1","R1","E","R1","F","R1","R1","R1"]
L51=["P2","P2","A","B","C","D3","P2","P2","P2"]    #level3
L50=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L49=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L48=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L47=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L46=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L45=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L44=["S","PG","R1","R1","R1","R1","R4","H3","H3"]
L43=["H2","H1","R1","R1","CB","R1","R1","B3","B1"]
L42=["B3","B1","R1","R1","R1","R1","R1","PD2","CA"]
L41=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L40=["H2","H3","R4","R1","R1","R1","R1","H1","H2"]
L39=["B1","B2","R1","R1","R1","R1","R1","B1","B3"]
L38=["S","PG","R1","R1","Z2","PNJ1","R5","PD","S"]   #zombie
L37=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L36=["B1","B2","R1","R1","R1","R2","R1","B1","B3"]
L35=["S","PG","CA","R1","R1","R1","R1","PD","S"]
L34=["H2","H3","R1","R1","R1","R1","CB","H1","H2"]
L33=["B1","B2","R5","R1","R1","R3","R1","B1","B3"]
L32=["S","PG","R1","R1","R1","R1","CA","PD","S"]
L31=["H2","H3","R1","R1","R5","R1","R1","H1","H2"]
L30=["B1","B2","R3","R1","R1","R1","R1","B1","B3"]
L29=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L28=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L27=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L26=["R1","R1","R1","E","R1","F","R1","CAT","R1"]    #chat
L25=["P2","P2","A","B","C","D","P2","P2","P2"]    #level2
L23=["S","PG","R1","R1","R1","R1","R4","PD","S"]
L22=["H2","H1","R1","R1","R1","R1","R1","H3","H1"]
L21=["B3","B1","CB","R1","R1","R1","CA","B3","B2"]
L20=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L19=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L18=["B2","B3","R1","R2","R1","R1","R1","B2","B1"]
L17=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L16=["H2","H1","R1","R3","R1","R1","R1","H3","H1"]
L15=["B3","B1","R4","R1","R1","R1","R5","B3","B2"]
L14=["S","PG","R1","R1","R1","R1","CB","PD","S"]
L11=["H2","H3","R1","R1","R1","R1","R1","H1","H2"]
L10=["B1","B2","R5","R1","R1","R1","R1","B1","B3"]
L8=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L0=["H3","H2","R1","R1","R1","R1","R1","H2","H3"]
L1=["B2","B3","R1","R2","R1","R1","R1","B2","B3"]
L2=["S","PG","R1","R1","R1","R1","R4","H3","H3"]
L3=["H2","H1","R1","CB","R1","R1","R1","B3","B1"]
L4=["B3","B1","R1","R1","R1","R1","R1","PD2","CA"]
L5=["S","PG","R1","R1","R1","R1","R3","PD","S"]
L6=["H2","H3","R5","R1","R1","R1","CAT","H1","H2"]   #chat
L7=["B1","B2","PO","PO","PO","PO","PO","B1","B3"]
L9=["R1","R1","R1","R1","R1","R1","R1","R1","R1"]
L12=["R1","R1","R1","R1","R1","R1","R1","R1","R1"]
L13=["R1","R1","R1","R1","R1","R1","R1","R1","R1"]
L24=["R1","R1","R1","R1","R1","R1","R1","R1","R1"]
ma_matrice=[L130,L129,L128,L127,L126,L125,L124,L123,L122,L121,L120,L119,L118,L117,L116,L115,L114,L113,L112,L111,L110,L109,L108,L107,L106,L105,L104,L103,L102,L101,L100,L99,L98,L97,L96,L95,L94,L93,L92,L91,L90,L89,L88,L87,L86,L85,L84,L83,L82,L81,L80,L79,L78,L77,L76,L75,L74,L73,L72,L71,L70,L69,L68,L67,L66,L65,L64,L63,L62,L61,L60,L59,L58,L57,L56,L55,L54,L53,L52,L51,L50,L49,L48,L47,L46,L45,L44,L43,L42,L41,L40,L39,L38,L37,L36,L35,L34,L33,L32,L31,L30,L29,L28,L27,L26,L25,L23,L22,L21,L20,L19,L18,L17,L16,L15,L14,L11,L10,L8,L0,L1,L2,L3,L4,L5,L6,L7,L9,L12,L13,L24,L50,L49,L48,L47,L46,L45,L44,L43,L42,L41,L40,L39,L38,L37,L36,L35,L34,L33,L32,L31,L30,L29,L28,L27,L26,L25,L23,L22,L21,L20,L19,L18,L17,L16,L15,L14,L11,L10,L8,L0,L1,L2,L3,L4,L5,L6,L7,L9,L12,L13,L24]
#creation de la map
dico={"D3":lvl3d,"D4":lvl4d,"BR":bro,"D5":lvl5d,"B1":bbase1,"B2":bbase2,"B12":bhaut12,"Z1":zombie1,"Z2":zombie2,"Z3":zombie3,"CAT":cat,"Z4":zombie4,"EN":entry,"ES":entrys,"PNJ2":pnj2,"B3":bbase3,"R1":road,"R2":roadh2,"R3":roadh3,"R4":roadh4,"R5":roadh5,"H1":bhaut1,"H2":bhaut2,"H3":bhaut3,"PG":potog,"PD":potod,"PD2":potodf,"S":bshad,"CA":ca,"CB":cb,"PO":poto,"A":lvl2a,"B":lvl2b,"C":lvl2c2,"D":lvl2d,"E":lvl2e,"F":lvl2f,"P2":poto2,"PNJ1":pnj1,"C2":lvl2c2,"CF1":carf1,"CF2":carf2,"CB1":carb1,"CB2":carb2}
for i in range(130):
        for j in range(9):
            can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
#position du personnage
posX=200  #abscisse de départ
posY=6150 #ordonnée de départ
X1=170
Y1=6140
perso=can1.create_image(posX,posY,image=bnash,anchor="nw")
rectangle2=can1.create_image(X1,Y1,image=jauge2,anchor="nw")
rectangle3=can1.create_image(X1,Y1,image=jauge3,anchor="nw")
rectangle4=can1.create_image(X1,Y1,image=jauge4,anchor="nw")
rectangle5=can1.create_image(X1,Y1,image=jauge5,anchor="nw")
rectangle=can1.create_image(X1,Y1,image=jauge,anchor="nw")
burn_compt_lvl1=0
cpt_z=0
truc=0
r1=1
r2=0
r3=0
r4=0
#zones de texte
#texte_pnj=can1.create_text(100,350,text="",font=("Arial",14),fill="red")

def Clavier(event):
    #event recupère l'information tapéee sur le clavier
    global posX,posY,X1,Y1,truc
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50
    car_list=["CF1","CF2","CB1","CB2"]
    cases_interdites=["B1","BR","B2","B3","H1","H2","H3","PD","PG","CA","CB","CAT","S","B","C","PO","D","E","P2","A","F","PNJ1","PNJ2","CF1","CF2","CB1","CB2"]
    if touche=='Up' and ma_matrice[ligne-1][colonne] not in cases_interdites:
        mvt_haut()
    elif touche=='Up':
        can1.itemconfig(perso,image=bnash)

    if touche=="Right" and ma_matrice[ligne][colonne+1] not in cases_interdites:
        mvt_droite()
    elif touche=="Right":
        can1.itemconfig(perso,image=dnash)

    if touche=="Left" and ma_matrice[ligne][colonne-1] not in cases_interdites:
        mvt_gauche()
    elif touche=="Left":
        can1.itemconfig(perso,image=gnash)

    if touche=="Down" and ma_matrice[ligne+1][colonne] not in cases_interdites:
        mvt_bas()
    elif touche=="Down":
        can1.itemconfig(perso,image=nash)
        


    #bruler objets
    if touche=="Return" and ma_matrice[ligne-1][colonne]=="CB":
        burn()

    if touche=="Return" and ma_matrice[ligne-1][colonne] in car_list:
        if ma_matrice[ligne-1][colonne]=="CF1":
            burn_car1()
        if ma_matrice[ligne-1][colonne]=="CF2":
            burn_car2()
        if ma_matrice[ligne-1][colonne]=="CB1":
            burn_car3()
        if ma_matrice[ligne-1][colonne]=="CB2":
            burn_car4()



    #bruler zombies
    if touche=="Return":
        if ma_matrice[ligne-1][colonne]=="Z1":
            burn_z1()

    if touche=="Return":
        if ma_matrice[ligne-1][colonne]=="Z2":
            burn_z2()

    if touche=="Return":
        if ma_matrice[ligne-1][colonne]=="Z3":
            burn_z3()

    if touche=="Return":
        if ma_matrice[ligne][colonne+1]=="Z4":
            burn_z4_d()

    if touche=="Return":
        if ma_matrice[ligne][colonne-1]=="Z4":
            burn_z4_g()



    #dialogue chat1
    if posX==250 and posY==6250:
            dial1()

    if touche=="Return" and ma_matrice[ligne][colonne+1]!="CAT2":
        dial2()

    #dialogue chat2
    if touche=="Return" and posX==300 and posY==5200:
        dial3()
    if touche=="Up" and posX==300 and posY==5150:
        dial3_2()

    #dialogue charlotte
    if touche=="Return" and posX==250 and posY==4650 and truc==1:
        dial_c()
    if touche=="Down" and posX==250 and posY==4700:
        dial_c_2()
    if touche=="Right" and posX==300 and posY==4650:
        dial_c_2()
    if touche=="Left" and posX==200 and posY==4650:
        dial_c_2()

    #dialogue igor
    if touche=="Return" and posX==200 and posY==3300 and cpt_z>=5:
        dial_i()
    if touche=="Down" and posX==200 and posY==3350 and cpt_z>=5:
        dial_i_2()
    if touche=="Right" and posX==250 and posY==3300 and cpt_z>=5:
        dial_i_2()
    if touche=="Left" and posX==150 and posY==3300 and cpt_z>=5:
        dial_i_2()

    #vie petit bro
    if touche=="Return" and posX==200 and posY==1700:
        vie()




def mvt_gauche():
    """deplace à gauche le perso"""
    global perso,posX,posY,compteur_de_pas,texte_pnj,X1,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    posX=posX-50
    X1-=50
    if posX<0 :
        posX=0
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(rectangle,X1,Y1)
    can1.coords(rectangle2,X1,Y1)
    can1.coords(rectangle3,X1,Y1)
    can1.coords(rectangle4,X1,Y1)
    can1.coords(rectangle5,X1,Y1)
    can1.coords(perso,posX,posY)


def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,y_scroll,X1,Y1,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    posY-=50
    y_scroll+=50
    Y1-=50
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.place(x=0,y=y_scroll)
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    can1.coords(rectangle,X1,Y1)
    can1.coords(rectangle2,X1,Y1)
    can1.coords(rectangle3,X1,Y1)
    can1.coords(rectangle4,X1,Y1)
    can1.coords(rectangle5,X1,Y1)
    if cpt_z==5:
        ma_matrice[50][4]="R1"
        can1.create_image(200,2500,image=lvl2c,anchor="nw")
        can1.tag_raise(perso)
        if r1==1:
            can1.tag_raise(rectangle)
        if r2==1:
            can1.tag_raise(rectangle2)
        if r3==1:
            can1.tag_raise(rectangle3)
        if r4==1:
            can1.tag_raise(rectangle4)
    if cpt_z==9:
        ma_matrice[18][4]="R1"
        can1.create_image(200,900,image=lvl2c,anchor="nw")
        can1.tag_raise(perso)
        if r1==1:
            can1.tag_raise(rectangle)
        if r2==1:
            can1.tag_raise(rectangle2)
        if r3==1:
            can1.tag_raise(rectangle3)
        if r4==1:
            can1.tag_raise(rectangle4)
    if posX==200 and posY==100:
        can1.after(1000,bonne_fin())



def mvt_bas():
    """deplace le perso vers le bas"""
    global perso,posY,posX,compteur_de_pas,y_scroll,Y1,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    posY+=50
    Y1+=50
    y_scroll-=50
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.place(x=0,y=y_scroll)
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(rectangle,X1,Y1)
    can1.coords(rectangle2,X1,Y1)
    can1.coords(rectangle3,X1,Y1)
    can1.coords(rectangle4,X1,Y1)
    can1.coords(rectangle5,X1,Y1)
    can1.coords(perso,posX,posY)

def mvt_droite():
    """deplace à droite le perso"""
    global perso,posX,posY,compteur_de_pas,X1,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    posX=posX+50
    X1+=50
    if posX>500 :
        posX=500
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(rectangle,X1,Y1)
    can1.coords(rectangle2,X1,Y1)
    can1.coords(rectangle3,X1,Y1)
    can1.coords(rectangle4,X1,Y1)
    can1.coords(rectangle5,X1,Y1)
    can1.coords(perso,posX,posY)


def burn():
    global burn_compt_lvl1,perso,rectangle,rectangle2,rectangle3,rectangle4,rectangle5,r1,r2,r3,r4
    can1.create_image(posX,posY-50,image=fire,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    burn_compt_lvl1+=1
    print("Nombre d'objets brûlées:",burn_compt_lvl1)
    if cpt_z<9:
        if burn_compt_lvl1==4 :
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            can1.tag_raise(rectangle4)
            r1=0
            r2=0
            r3=0
            r4=1
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)
    elif cpt_z>=9:
        if burn_compt_lvl1==4:
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            r1=0
            r2=0
            r3=0
            r4=1
            can1.tag_raise(rectangle4)
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)

    if burn_compt_lvl1==3:
        ma_matrice[105][4]="R1"
        can1.create_image(200,5250,image=lvl2c,anchor="nw")
        if r1==1:
            can1.tag_raise(rectangle)
        if r2==1:
            can1.tag_raise(rectangle2)
        if r3==1:
            can1.tag_raise(rectangle3)
        if r4==1:
            can1.tag_raise(rectangle4)
        can1.tag_raise(perso)

def burn_car1():
    global burn_compt_lvl1,r1,r2,r3,r4
    can1.create_image(posX,posY-50,image=carf1f,anchor="nw")
    burn_compt_lvl1+=1
    print("Nombre d'objets brûlées:",burn_compt_lvl1)
    if cpt_z<9:
        if burn_compt_lvl1==4 :
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            can1.tag_raise(rectangle4)
            r1=0
            r2=0
            r3=0
            r4=1
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)
    elif cpt_z>=9:
        if burn_compt_lvl1==4:
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            r1=0
            r2=0
            r3=0
            r4=1
            can1.tag_raise(rectangle4)
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)

def burn_car2():
    global burn_compt_lvl1,r1,r2,r3,r4
    can1.create_image(posX,posY-50,image=carf2f,anchor="nw")
    burn_compt_lvl1+=1
    print("Nombre d'objets brûlées:",burn_compt_lvl1)
    if cpt_z<9:
        if burn_compt_lvl1==4 :
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            can1.tag_raise(rectangle4)
            r1=0
            r2=0
            r3=0
            r4=1
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)
    elif cpt_z>=9:
        if burn_compt_lvl1==4:
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            r1=0
            r2=0
            r3=0
            r4=1
            can1.tag_raise(rectangle4)
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)

def burn_car3():
    global burn_compt_lvl1,cpt_z,r1,r2,r3,r4
    can1.create_image(posX,posY-50,image=carb1f,anchor="nw")
    burn_compt_lvl1+=1
    print("Nombre d'objets brûlées:",burn_compt_lvl1)
    if cpt_z<9:
        if burn_compt_lvl1==4 :
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            can1.tag_raise(rectangle4)
            r1=0
            r2=0
            r3=0
            r4=1
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)
    elif cpt_z>=9:
        if burn_compt_lvl1==4:
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            r1=0
            r2=0
            r3=0
            r4=1
            can1.tag_raise(rectangle4)
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)

def burn_car4():
    global burn_compt_lvl1,cpt_z,r1,r2,r3,r4
    can1.create_image(posX,posY-50,image=carb2f,anchor="nw")
    burn_compt_lvl1+=1
    print("Nombre d'objets brûlées:",burn_compt_lvl1)
    if cpt_z<9:
        if burn_compt_lvl1==4 :
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            can1.tag_raise(rectangle4)
            r1=0
            r2=0
            r3=0
            r4=1
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)
    elif cpt_z>=9:
        if burn_compt_lvl1==4:
            can1.tag_raise(rectangle2)
            r1=0
            r2=1
            r3=0
            r4=0
        if burn_compt_lvl1==5 :
            can1.tag_raise(rectangle3)
            r1=0
            r2=0
            r3=1
            r4=0
        if burn_compt_lvl1==6 :
            r1=0
            r2=0
            r3=0
            r4=1
            can1.tag_raise(rectangle4)
        if burn_compt_lvl1==7 :
            can1.tag_raise(rectangle5)
            can1.after(1000,fin)

def burn_z1():
    global posX,posY,cpt_z,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    ma_matrice[100][4]="R1"
    can1.create_image(posX,posY-50,image=zombief1,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.after(1000,dis_z1)
    cpt_z+=1
    print("Nombre de zombies brûlés:",cpt_z)
def dis_z1():
    ma_matrice[100][4]="R1"
    can1.create_image(posX,posY-50,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def burn_z2():
    global posX,posY,cpt_z,rectangle,rectangle2,rectangle3,rectangle4,rectangle5,truc
    can1.create_image(posX,posY-50,image=zombief2,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.after(1000,dis_z2)
    cpt_z+=1
    truc+=1
    print("Nombre de zombies brûlés:",cpt_z)
    if cpt_z==1:
        ma_matrice[79][4]="R1"
        can1.create_image(200,3950,image=lvl2c,anchor="nw")
        can1.tag_raise(perso)
        if r1==1:
            can1.tag_raise(rectangle)
        if r2==1:
            can1.tag_raise(rectangle2)
        if r3==1:
            can1.tag_raise(rectangle3)
        if r4==1:
            can1.tag_raise(rectangle4)

def dis_z2():
    can1.create_image(posX,posY-50,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def burn_z3():
    global posX,posY,cpt_z,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    can1.create_image(posX,posY-50,image=zombief3,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.after(1000,dis_z3)
    cpt_z+=1
    print("Nombre de zombies brûlés:",cpt_z)
def dis_z3():
    can1.create_image(posX,posY-50,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def burn_z4_g():
    global posX,posY,cpt_z,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    can1.create_image(posX-50,posY,image=zombief4,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.after(1000,dis_z4_g)
    cpt_z+=1
    print("Nombre de zombies brûlés:",cpt_z)
def dis_z4_g():
    can1.create_image(posX-50,posY,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def burn_z4_d():
    global posX,posY,cpt_z,rectangle,rectangle2,rectangle3,rectangle4,rectangle5
    can1.create_image(posX+50,posY,image=zombief4,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)
    can1.after(1000,dis_z4_d)
    cpt_z+=1
    print("Nombre de zombies brûlés:",cpt_z)
def dis_z4_d():
    can1.create_image(posX+50,posY,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)

def fin():
    """fin"""
    can1=Canvas(Mafenetre,bg='white', width=450, height=500)
    can1.place(x=0, y=0)
    can1.create_image(0,0,image=gameover,anchor="nw")

def bonne_fin():
    """bonne fin"""
    can1=Canvas(Mafenetre,bg='white', width=450, height=500)
    can1.place(x=0, y=0)
    can1.create_image(0,0,image=good_ending,anchor="nw")

def dial1():
    can1.create_image(100,6350,image=d1,anchor="nw")
    can1.create_image(150,6350,image=d2,anchor="nw")
    can1.create_image(200,6350,image=d3,anchor="nw")
    can1.create_image(250,6350,image=d4,anchor="nw")
    can1.create_image(300,6350,image=d5,anchor="nw")
    can1.create_image(350,6350,image=d6,anchor="nw")
    can1.create_image(400,6350,image=d7,anchor="nw")
    can1.create_image(100,6400,image=d8,anchor="nw")
    can1.create_image(150,6400,image=d9,anchor="nw")
    can1.create_image(200,6400,image=d10,anchor="nw")
    can1.create_image(250,6400,image=d11,anchor="nw")
    can1.create_image(300,6400,image=d12,anchor="nw")
    can1.create_image(350,6400,image=d13,anchor="nw")
    can1.create_image(400,6400,image=d14,anchor="nw")
    can1.create_image(300,6250,image=cat2,anchor="nw")

def dial2():
    can1.create_image(100,6350,image=di1,anchor="nw")
    can1.create_image(150,6350,image=di2,anchor="nw")
    can1.create_image(200,6350,image=di3,anchor="nw")
    can1.create_image(250,6350,image=di4,anchor="nw")
    can1.create_image(300,6350,image=di5,anchor="nw")
    can1.create_image(350,6350,image=di6,anchor="nw")
    can1.create_image(400,6350,image=di7,anchor="nw")
    can1.create_image(100,6400,image=di8,anchor="nw")
    can1.create_image(150,6400,image=di9,anchor="nw")
    can1.create_image(200,6400,image=di10,anchor="nw")
    can1.create_image(250,6400,image=di11,anchor="nw")
    can1.create_image(300,6400,image=di12,anchor="nw")
    can1.create_image(350,6400,image=di13,anchor="nw")
    can1.create_image(400,6400,image=di14,anchor="nw")

def dial3():
    can1.create_image(100,5100,image=dia1,anchor="nw")
    can1.create_image(150,5100,image=dia2,anchor="nw")
    can1.create_image(200,5100,image=dia3,anchor="nw")
    can1.create_image(250,5100,image=dia4,anchor="nw")
    can1.create_image(300,5100,image=dia5,anchor="nw")
    can1.create_image(350,5100,image=dia6,anchor="nw")
    can1.create_image(400,5100,image=dia7,anchor="nw")
    can1.create_image(100,5150,image=dia8,anchor="nw")
    can1.create_image(150,5150,image=dia9,anchor="nw")
    can1.create_image(200,5150,image=dia10,anchor="nw")
    can1.create_image(250,5150,image=dia11,anchor="nw")
    can1.create_image(300,5150,image=dia12,anchor="nw")
    can1.create_image(350,5150,image=dia13,anchor="nw")
    can1.create_image(400,5150,image=dia14,anchor="nw")
    can1.create_image(350,5200,image=cat2,anchor="nw")

def dial3_2():
    can1.create_image(100,5100,image=road,anchor="nw")
    can1.create_image(150,5100,image=road,anchor="nw")
    can1.create_image(200,5100,image=road,anchor="nw")
    can1.create_image(250,5100,image=road,anchor="nw")
    can1.create_image(300,5100,image=road,anchor="nw")
    can1.create_image(350,5100,image=bhaut2,anchor="nw")
    can1.create_image(400,5100,image=bhaut3,anchor="nw")
    can1.create_image(100,5150,image=road,anchor="nw")
    can1.create_image(150,5150,image=roadh2,anchor="nw")
    can1.create_image(200,5150,image=road,anchor="nw")
    can1.create_image(250,5150,image=road,anchor="nw")
    can1.create_image(300,5150,image=road,anchor="nw")
    can1.create_image(350,5150,image=bbase2,anchor="nw")
    can1.create_image(400,5150,image=bbase3,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def dial_c():
    global truc
    can1.create_image(150,4500,image=dc1,anchor="nw")
    can1.create_image(200,4500,image=dc2,anchor="nw")
    can1.create_image(250,4500,image=dc3,anchor="nw")
    can1.create_image(300,4500,image=dc4,anchor="nw")
    can1.create_image(350,4500,image=dc5,anchor="nw")
    can1.create_image(150,4550,image=dc6,anchor="nw")
    can1.create_image(200,4550,image=dc7,anchor="nw")
    can1.create_image(250,4550,image=dc8,anchor="nw")
    can1.create_image(300,4550,image=dc9,anchor="nw")
    can1.create_image(350,4550,image=dc10,anchor="nw")
    can1.create_image(250,4600,image=pnj1b,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)


def dial_c_2():
    global truc
    can1.create_image(150,4500,image=road,anchor="nw")
    can1.create_image(200,4500,image=road,anchor="nw")
    can1.create_image(250,4500,image=road,anchor="nw")
    can1.create_image(300,4500,image=road,anchor="nw")
    can1.create_image(350,4500,image=bhaut1,anchor="nw")
    can1.create_image(150,4550,image=road,anchor="nw")
    can1.create_image(200,4550,image=road,anchor="nw")
    can1.create_image(250,4550,image=road,anchor="nw")
    can1.create_image(300,4550,image=road,anchor="nw")
    can1.create_image(350,4550,image=bbase1,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)

def dial_i():
    can1.create_image(100,3150,image=dr1,anchor="nw")
    can1.create_image(150,3150,image=dr2,anchor="nw")
    can1.create_image(200,3150,image=dr3,anchor="nw")
    can1.create_image(250,3150,image=dr4,anchor="nw")
    can1.create_image(300,3150,image=dr5,anchor="nw")
    can1.create_image(100,3200,image=dr6,anchor="nw")
    can1.create_image(150,3200,image=dr7,anchor="nw")
    can1.create_image(200,3200,image=dr8,anchor="nw")
    can1.create_image(250,3200,image=dr9,anchor="nw")
    can1.create_image(300,3200,image=dr10,anchor="nw")
    can1.create_image(200,3250,image=pnj2b,anchor="nw")
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)

def dial_i_2():
    can1.create_image(100,3150,image=road,anchor="nw")
    can1.create_image(150,3150,image=road,anchor="nw")
    can1.create_image(200,3150,image=road,anchor="nw")
    can1.create_image(250,3150,image=road,anchor="nw")
    can1.create_image(300,3150,image=road,anchor="nw")
    can1.create_image(100,3200,image=road,anchor="nw")
    can1.create_image(150,3200,image=road,anchor="nw")
    can1.create_image(200,3200,image=road,anchor="nw")
    can1.create_image(250,3200,image=road,anchor="nw")
    can1.create_image(300,3200,image=road,anchor="nw")
    can1.tag_raise(perso)
    if r1==1:
        can1.tag_raise(rectangle)
    if r2==1:
        can1.tag_raise(rectangle2)
    if r3==1:
        can1.tag_raise(rectangle3)
    if r4==1:
        can1.tag_raise(rectangle4)

def vie():
    global cpt_z,burn_compt_lvl1,r1,r2,r3,r4
    if cpt_z==9:
        burn_compt_lvl1=3
        can1.tag_raise(rectangle)
        r=1
        r2=0
        r3=0
        r4=0


#programme principal
can1.focus_set()
can1.bind('<Key>',Clavier)
Mafenetre.mainloop()
mixer.music.stop()