#modules
from tkinter import*
#creation de la fenetre
mafenetre=Tk()
mafenetre.geometry("625x625")
mafenetre.title("E.SPACE")
#creation de la zone graphique
can1=Canvas(mafenetre, bg="black", width=625, height=625)
can1.place(x=0, y=0)
#chargement des images en memoire
case_sol= PhotoImage(file="sol.gif")
case_mur= PhotoImage(file="mur.gif")
case_interrupteur= PhotoImage(file="interrupteur.gif")
case_barriere= PhotoImage(file="barriere.gif")
case_sortie= PhotoImage(file="sortie.gif")
droite1= PhotoImage(file="perso1-droite.gif")
droite2= PhotoImage(file="perso1-droite.gif")
gauche1= PhotoImage(file="perso1-gauche.gif")
gauche2= PhotoImage(file="perso1-gauche.gif")
monte1= PhotoImage(file="perso1-haut.gif")
monte2= PhotoImage(file="perso1-haut.gif")
bas1= PhotoImage(file="perso1-bas.gif")
bas2= PhotoImage(file="perso1-bas.gif")
case_sortie0= PhotoImage(file="sortie0.gif")
case_interrupteur1= PhotoImage(file="interrupteur1.gif")
#creation de la matrice
#0: chmin 1; arbre 2; herbe 3; cailloux 4; eau 5
l0=["S","S","S","S","S","S","S","B","S","S","S","S","E","S","S","S","S","M","S","S","S","S","I","S","S"]
l1=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l2=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l3=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l4=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l5=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l6=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l7=["S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","B","S","S","S","S","S","S","S"]
l8=["S","S","S","S","S","I","S","M","S","S","I","S","S","S","S","S","S","M","S","S","S","S","S","S","S"]
l9=["M","M","M","M","M","M","M","M","M","M","M","M","M","M","B","M","M","M","M","M","M","M","M","M","M"]
l10=["S","S","S","S","S","S","S","S","S","S","B","S","S","S","S","S","S","S","S","S","S","S","S","S","I"]
l11=["S","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","S","S","S","S","S"]
l12=["S","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","S","S","S","S","S"]
l13=["I","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S","S","S","S","S","S"]
l14=["S","S","S","S","S","S","S","S","S","S","M","M","M","M","M","M","M","M","M","M","M","M","M","M","M"]
l15=["M","M","M","M","M","M","M","M","B","M","M","S","S","S","S","S","S","S","S","M","S","S","S","S","S"]
l16=["S","S","I","M","S","S","S","S","S","S","S","S","S","S","S","S","S","S","S","B","S","S","S","S","S"]
l17=["S","S","S","M","S","S","S","S","S","S","S","S","S","S","S","S","S","S","S","M","S","S","S","S","S"]
l18=["S","S","S","M","S","S","S","S","S","S","S","S","S","S","S","M","M","M","M","M","S","S","S","S","I"]
l19=["S","S","S","M","S","I","S","S","M","M","M","M","M","B","M","M","S","S","S","S","S","S","S","S","S"]
l20=["S","S","S","M","M","M","M","M","M","S","I","S","S","S","S","M","S","S","S","S","S","S","S","S","S"]
l21=["S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S"]
l22=["S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","M","M","M","M","M","M","M","M","M","M"]
l23=["S","S","S","S","S","S","S","S","M","S","S","S","S","S","S","M","S","S","S","S","S","S","S","S","S"]
l24=["S","S","S","S","S","S","S","S","B","S","S","S","S","S","S","B","S","S","S","S","S","S","S","S","I"]

matrice=[l0,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24]
#creation de la map
dico={"S":case_sol,"M":case_mur,"B":case_barriere,"I":case_interrupteur1,"E":case_sortie}
for i in range(25):
    for j in range(25):
        can1.create_image(25*j,25*i,image=dico[matrice[i][j]],anchor="nw")
#position du personnage
posX=350  #abscisse de départ
posY=600 #ordonnée de départ
perso=can1.create_image(posX,posY,image=monte2,anchor="nw")   
tab_droite=[droite1,droite2]
tab_haut=[monte1,monte2]
tab_gauche=[gauche1,gauche2]
tab_bas=[bas1,bas2]
compteur_de_pas=0
#zone de texte

#fonctions

def Clavier(event):
    """event variable qui a récupéré l'information tapée au Clavier"""
    global posY,posX,matrice
    touche=event.keysym
    ligne=posY//25
    colonne=posX//25
    print("X: ",posX, "Y: ",posY)
    print("Ligne: ",ligne)
    print("Colonne: ",colonne)
    cases_interdites=["M","B","E"]
    if touche=='Up' and matrice[ligne-1][colonne] not in cases_interdites: 
        mvt_haut()
    if touche=='Right' and matrice[ligne][colonne+1] not in cases_interdites: 
        mvt_droite()
    if touche=='Left' and matrice[ligne][colonne-1] not in cases_interdites: 
        mvt_gauche()
    if touche=='Down' and matrice[ligne+1][colonne] not in cases_interdites: 
        mvt_bas()

def mvt_haut():
    """deplacement du perso vers le haut"""
    global posX,posY,can1,compteur_de_pas,tab_haut
    posY=posY-25
    if posY<0:
        posY=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()
    test_position()
    
def mvt_droite():
    """deplacement du perso vers la droite"""
    global posX,posY,can1,compteur_de_pas,tab_droite
    posX=posX+25
    if posX>600:
        posX=600
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()
    test_position()

def mvt_gauche():
    """deplacement du perso vers la gauche"""
    global posX,posY,can1,compteur_de_pas,tab_gauche
    posX=posX-25
    if posX<0:
        posX=0
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()
    test_position()
    

def mvt_bas():
    """deplacement du perso vers la gauche"""
    global posX,posY,can1,compteur_de_pas,tab_bas
    posY=posY+25
    if posY>600:
        posY=600
    #mise à jour de l'image
    can1.itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    can1.coords(perso,posX,posY)
    position()
    test_position()
    
def position():
    global posX,posY,can1,case_sol,perso
    if posX==250 and posY==500:
        matrice[24][8]="S"
        can1.create_image(200,600,image=case_sol,anchor="nw")
        can1.create_image(250,500,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==50 and posY==400:
        matrice[19][13]="S"
        can1.create_image(325,475,image=case_sol,anchor="nw")
        can1.create_image(50,400,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==125 and posY==475:
        matrice[16][19]="S"
        can1.create_image(475,400,image=case_sol,anchor="nw")
        can1.create_image(125,475,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==600 and posY==450:
        matrice[15][8]="S"
        can1.create_image(200,375,image=case_sol,anchor="nw")
        can1.create_image(600,450,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==0 and posY==325:
        matrice[10][10]="S"
        can1.create_image(250,250,image=case_sol,anchor="nw")
        can1.create_image(0,325,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==600 and posY==250:
        matrice[9][14]="S"
        can1.create_image(350,225,image=case_sol,anchor="nw")
        can1.create_image(600,250,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==250 and posY==200:
        matrice[0][7]="S"
        can1.create_image(175,0,image=case_sol,anchor="nw")
        can1.create_image(250,200,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==125 and posY==200:
        matrice[7][17]="S"
        can1.create_image(425,175,image=case_sol,anchor="nw")
        can1.create_image(125,200,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==550 and posY==0:
        matrice[24][15]="S"
        can1.create_image(375,600,image=case_sol,anchor="nw")
        can1.create_image(550,0,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)
    if posX==600 and posY==600:
        matrice[0][12]="S"
        can1.create_image(300,0,image=case_sortie0,anchor="nw")
        can1.create_image(600,600,image=case_interrupteur,anchor="nw")
    can1.tag_raise(perso)


def niveau2():
    global perso,posX,posY,can1,matrice,niveau
    niveau=2
    can1.destroy()
    L0=["M", "M", "M", "M", "M", "M", "M", "M", "M", "M"]
    L1=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L2=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L3=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L4=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L5=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L6=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L7=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L8=["M", "S", "S", "S", "S", "S", "S", "S", "S", "M"]
    L9=["M", "M", "M", "M", "M", "M", "M", "M", "M", "M"]
    matrice=[L0, L1, L2, L3, L4, L5, L6, L7, L8, L9]
    can1=Canvas(mafenetre, bg="black", width=250, height=250)
    can1.place(x=0,y=0)
    dico={"S":case_sol, "M":case_mur}
    for i in range(10):
        for j in range(10):
            can1.create_image(25*j,25*i,image=dico[matrice[i][j]],anchor="nw")
    posX=25 #abscisse de départ
    posY=25 #ordonnée de départ
    perso=can1.create_image(posX,posY,image=bas2,anchor="nw")
    can1.create_image(200,200,image=monte1,anchor="nw")
    mafenetre.geometry("250x250")
    can1.focus_set()
    can1.bind('<Key>',Clavier)
    
def test_position():
    global perso,posX,posY,texte_pnj,can1,niveau
    if posX==300 and posY==0 and niveau==1: #case spéciale du  niveau 1
        can1.after(2000,niveau2)
    if posX==200 and posY==200 and niveau==2: #case spéciale du  niveau 1
        can1.destroy()
        can2=Canvas(mafenetre,bg="black",width=250,height=250)
        can2.place(x=0,y=0)
        can2.create_text(100,100,text="tu t es enfuis BRAVO",font=("Fixedsys",9),fill="white")


can1.focus_set()
can1.bind('<Key>',Clavier)  #fonction clavier si touche enfoncée 
niveau=1
mafenetre.mainloop()
