#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('750x800')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=750,height=800)
can1.place(x=0,y=0)
can2=Canvas(Mafenetre,bg="white",width=750,height=800)
tab_can=[can1,can2]
#creation des cases images
caseeau=PhotoImage(file="water.gif")
casepont=PhotoImage(file="pont.gif")
casebuisson=PhotoImage(file="buisson.gif")
casebarriere=PhotoImage(file="barriere.gif")
caseherbe=PhotoImage(file="herbe.gif")
casepont=PhotoImage(file="pont.gif")
casemaison1=PhotoImage(file="maison1.gif")
casemaison2=PhotoImage(file="maison2.gif")
casemaison3=PhotoImage(file="maison3.gif")
casemaison4=PhotoImage(file="maison4.gif")
casemaison5=PhotoImage(file="maison5.gif")
casemaison6=PhotoImage(file="maison6.gif")
casemaison7=PhotoImage(file="maison7.gif")
casemaison8=PhotoImage(file="maison8.gif")
casemaison9=PhotoImage(file="maison9.gif")
casenoire=PhotoImage(file="N.gif")
casemaisonpnj1=PhotoImage(file="mpnj1.gif")
casemaisonpnj2=PhotoImage(file="mpnj2.gif")
casemaisonpnj3=PhotoImage(file="mpnj3.gif")
casemaisonpnj4=PhotoImage(file="mpnj4.gif")


droite1=PhotoImage(file="hero3.gif")
droite2=PhotoImage(file="heroA3.gif")
gauche1=PhotoImage(file="hero2.gif")
gauche2=PhotoImage(file="heroA2.gif")
descend1=PhotoImage(file="hero1.gif")
descend2=PhotoImage(file="heroA1.gif")
monte1=PhotoImage(file="hero4.gif")
monte2=PhotoImage(file="heroA4.gif")
pnj1=PhotoImage(file="pnj1.gif")
pnj2=PhotoImage(file="pnj2.gif")
pnj3=PhotoImage(file="pnj3.gif")
marchand=PhotoImage(file="marchand.gif")

casemurfenetre=PhotoImage(file="mur fenetre.gif")
caseporte=PhotoImage(file="porte.gif")
casesol=PhotoImage(file="sol.gif")
casesol1=PhotoImage(file="sol1.gif")
casetv=PhotoImage(file="TV.gif")
casetable1=PhotoImage(file="table1.gif")
casetabe2=PhotoImage(file="table2.gif")
casetable3=PhotoImage(file="table3.gif")
casetable4=PhotoImage(file="table4.gif")
caselit=PhotoImage(file="lit.gif")
casebaignoire=PhotoImage(file="baignoire.gif")
casemur=PhotoImage(file="mur simple.gif")

tab_droite=[droite1,droite2]
tab_gauche=[gauche2,gauche1]
tab_haut=[monte1,monte2]
tab_bas=[descend1,descend2]

compteur_de_pas=0
#creation de la matrice
LL0=["B","B","B","B","B","B","B","B","B","B","B","B","B","B","B"]
LL1=["B","H","H","E","E","B","MP3","MP4","H","B","E","E","H","H","B"]
LL2=["B","H","H","E","E","B","MP1","MP2","m","B","E","E","H","H","B"]
LL3=["B","H","H","E","E","B","H","H","H","B","E","E","H","H","B"]
LL4=["B","H","H","H","H","H","H","H","H","H","H","H","H","H","B"]
LL5=["B","B","B","A","H","H","H","H","H","H","H","A","B","B","B"]
LL6=["B","H","E","E","B","H","H","H","H","H","B","E","E","H","B"]
LL7=["B","H","H","E","E","B","H","H","H","B","E","E","H","H","B"]
LL8=["B","H","H","H","E","E","P","P","P","E","E","H","H","H","B"]
LL9=["B","A","A","A","A","A","H","H","H","A","A","A","A","A","B"]
LL10=["B","H","H","H","H","H","M7","M8","M9","H","H","H","H","H","B"]
LL11=["B","H","H","H","H","H","M4","M5","M6","H","H","H","H","H","B"]
LL12=["B","H","H","H","H","H","M1","M2","M3","H","H","H","H","H","B"]


L6=["N","M","M","M","M","MF","M","D","M","MF","M","M","M","M","N"]
L7=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L8=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L9=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L10=["N","S","T1","T2","S","S","S","S","S","S","S","S","S","S","N"]
L11=["N","TV","T3","T4","S","S","S","S","S","S","S","S","S","L","N"]
L12=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L13=["N","N","N","N","S","S","S","S","S","S","S","S","S","S","N"]
L14=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L15=["N","S","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L16=["N","S","S","S","S","S","S","S","S","S","S","S","S","s","N"]
L17=["N","Z","S","S","S","S","S","S","S","S","S","S","S","S","N"]
L18=["N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"]


ma_matrice=[LL0,LL1,LL2,LL3,LL4,LL5,LL6,LL7,LL8,LL9,LL10,LL11,LL12]
ma_matrice2=[L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18]
#creation de la map
dico={"MP1":casemaisonpnj1,"m":marchand,"MP2":casemaisonpnj2,"MP3":casemaisonpnj3,"MP4":casemaisonpnj4,"E":caseeau,"P":casepont,"S":casesol,"s":casesol1,"B":casebuisson,"A":casebarriere,"H":caseherbe,"M1":casemaison1,"M2":casemaison2,"M3":casemaison3,"M4":casemaison4,"M5":casemaison5,"M6":casemaison6,"M7":casemaison7,"M8":casemaison8,"M9":casemaison9,"N":casenoire,"D":caseporte,"T1":casetable1,"T2":casetabe2,"T3":casetable3,"T4":casetable4,"M":casemur,"MF":casemurfenetre,"TV":casetv,"L":caselit,"Z":casebaignoire}
for i in range(13):
    for j in range(15):
        can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
niveau=0
#position du personnage
posX=50 #abscisse de départ
float(posX)
posY=50 #ordonnée de départ
float(posY)
perso=can1.create_image(posX,posY,image=descend2,anchor="nw")
pnj=can2.create_image(posX,posY,image=pnj2,anchor="nw")

#liste des zones mortes
liste=["MP1","MP2","A","B","E"]
liste2=["MF","M","D","T1","T2","T3","T4","N","s","Z"]

#compteur permettant la suite des niveaux
compteur=0


#zones de texte
texte_pnj=can1.create_text(360,700,text="Retournez chez vous.",font=("courier new",14),fill="black")
texte_pnj1=can1.create_text(6,700,text="",font=("courier new",14),fill="black")
texte_pnj2=can1.create_text(350,720,text="",font=("courier new",8),fill="black")

def Clavier(event):
    #event recupère l'information tapéee sur le clavier
    global posX,posY,ma_matrice,niveau,liste,compteur
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50


    if niveau==0 :
      for i in range(6):
        if touche=='Up' and ma_matrice[ligne-1][colonne]!=liste[i]:
            mvt_haut()
        if touche=="Right" and ma_matrice[ligne][colonne+1]!=liste[i]:
            mvt_droite()
            compteur+=2
        if touche=="Left" and ma_matrice[ligne][colonne-1]!=liste[i]:
            mvt_gauche()
        if touche=="Down" and ma_matrice[ligne+1][colonne]!=liste[i]:
            mvt_bas()

    if niveau==1 :
     for i in range(50):

        if touche=='Up' and ma_matrice2[ligne-1][colonne]!=liste2[i]:
            mvt_haut()
        if touche=="Right" and ma_matrice2[ligne][colonne+1]!=liste2[i]:
            mvt_droite()
        if touche=="Left" and ma_matrice2[ligne][colonne-1]!=liste2[i]:
            mvt_gauche()
        if touche=="Down" and ma_matrice2[ligne+1][colonne]!=liste2[i]:
            mvt_bas()




def mvt_gauche():
    """deplace à gauche le perso"""
    global perso,posX,posY,compteur_de_pas,texte_pnj,niveau,tab_can
    if niveau==0 :
       posX=posX-10
       if posX<0 :
        posX=00
    if niveau==1 :
       posX=posX-5
       if posX<0 :
        posX=00

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    tab_can[niveau].coords(perso,posX,posY)
    print(posX)

def mvt_bas():
    """deplace le perso vers le bas"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can,tab_bas,can1,can2,pnj
    if niveau==0 :
       posY=posY+10
       if posY>1500 :
        posY=1500
    if niveau==1 :
       posY=posY+5
       if posY>1500 :
        posY=1500

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    print(niveau)
    tab_can[niveau].coords(perso,posX,posY)
    if posX==450 and posY==100:
        compteur=1
        can1.itemconfig(texte_pnj1,text="Marchand : Oh, tu es revenu ! Mes parents m'ont demandé te prévenir qu'ils allaient rentrer tard aujoud'hui.")
    if (posX==350 or posX==400 or posX==300)and posY==500 and niveau==0:
        can1.itemconfig(texte_pnj2,text="Vous obtenez la compétence 'Ultravision' !")
        can1.itemconfig(texte_pnj,text="BRAVO !")
        can1.delete(perso)
        can1.after(3000,maison)
    if posX==650 and posY==450:
        can2.delete(pnj)
        pnj=can2.create_image(posX,posY+50,image=pnj3,anchor="nw")
    if posX==650 and posY==550:
        can2.delete(pnj)
        pnj=can2.create_image(posX,posY-50,image=pnj1,anchor="nw")
    if posX==600 and posY==500:
        can2.delete(pnj)
        pnj=can2.create_image(posX+50,posY,image=pnj2,anchor="nw")

    print(posY)



def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can
    if niveau==0 :
       posY=posY-10
       if posY<0 :
        posY=0
    if niveau==1 :
       posY=posY-5
       if posY<0 :
        posY=0

        #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées

    print(niveau)
    tab_can[niveau].coords(perso,posX,posY)

    if posX==650 and posY==450:
        can2.delete(pnj)
        pnj=can2.create_image(posX,posY+50,image=pnj3,anchor="nw")
    if posX==650 and posY==550:
        can2.delete(pnj)
        pnj=can2.create_image(posX,posY-50,image=pnj1,anchor="nw")
    if posX==600 and posY==500:
        can2.delete(pnj)
        pnj=can2.create_image(posX+50,posY,image=pnj2,anchor="nw")
    print(posY)



def mvt_droite():
    """deplace à droite le perso"""
    global perso,posX,posY,compteur_de_pas,niveau,tab_can,compteur
    colonne=posX//50
    ligne=posY//50

    if niveau==0 :
       posX=posX+5
       if compteur%2:
        posX=posX+2
       if posX>1200 :
        posX=1200
    if niveau==1 :
       posX=posX+5
       if posX>1200 :
        posX=1200

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    tab_can[niveau].coords(perso,posX,posY)
    print(posX)



def maison():
    """2ème niveau"""
    global can1
    can1=Canvas(Mafenetre,bg="black",width=750,height=800)
    can1.place(x=0,y=0)
    can1.create_text(325,400,text="Vous êtes à l'abri...",fill="White")
    can1.after(3000,maison2)

def maison2():
     global dico,niveau,can2,posX,posY,perso

     niveau=1
     can2=Canvas(Mafenetre,bg="white",width=750,height=800)
     can2.place(x=0,y=0)
     tab_can[1]=can2
     for i in range(13):
        for j in range(15):
          can2.create_image(50*j,50*i,image=dico[ma_matrice2[i][j]],anchor="nw")
     posX=650
     posY=500
     pnj=can2.create_image(posX,posY,image=pnj2,anchor="nw")
     posX=300
     posY=50
     perso=can2.create_image(posX,posY,image=descend2,anchor="nw")
     can2.focus_set()
     can2.bind('<Key>',Clavier)


#programme principal
can1.focus_set()
can1.bind('<Key>',Clavier)

Mafenetre.mainloop()













