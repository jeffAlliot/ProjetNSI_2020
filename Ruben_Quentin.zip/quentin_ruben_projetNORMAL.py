#creation d'une bitmap
#modules
from tkinter import *
#creation de la fenetre
Mafenetre=Tk()
Mafenetre.geometry('750x800')
#zone de dessin
can1=Canvas(Mafenetre,bg="white",width=750,height=800)
can1.place(x=0,y=0)
can2=Canvas(Mafenetre,bg="white",width=750,height=800)
can3=Canvas(Mafenetre,bg="black",width=750,height=800)
tab_can=[can1,can2,can3]
#creation des cases images
caseeau=PhotoImage(file="eau2.gif")
casepont=PhotoImage(file="pont.gif")
casebuisson=PhotoImage(file="buisson.gif")
casebarriere=PhotoImage(file="barriere.gif")
caseherbe=PhotoImage(file="herbe.gif")
casepont=PhotoImage(file="pont.gif")
casemaison1=PhotoImage(file="maison1.gif")
casemaison2=PhotoImage(file="maison2.gif")
casemaison3=PhotoImage(file="maison3.gif")
casemaison4=PhotoImage(file="maison4.gif")
casemaison5=PhotoImage(file="maison5.gif")
casemaison6=PhotoImage(file="maison6.gif")
casemaison7=PhotoImage(file="maison7.gif")
casemaison8=PhotoImage(file="maison8.gif")
casemaison9=PhotoImage(file="maison9.gif")
casenoire=PhotoImage(file="N.gif")
marchand=PhotoImage(file="marchand.gif")
casemaisonpnj1=PhotoImage(file="mpnj1.gif")
casemaisonpnj2=PhotoImage(file="mpnj2.gif")
casemaisonpnj3=PhotoImage(file="mpnj3.gif")
casemaisonpnj4=PhotoImage(file="mpnj4.gif")
casebureau1=PhotoImage(file="bureau1.gif")
casebureau2=PhotoImage(file="bureau2.gif")
casecuisine1=PhotoImage(file="cuisine1.gif")
casecuisine2=PhotoImage(file="cuisine2.gif")
casecuisine3=PhotoImage(file="cuisine3.gif")
casecuisine4=PhotoImage(file="cuisine4.gif")
casecuisine5=PhotoImage(file="cuisine5.gif")
casecuisine6=PhotoImage(file="cuisine6.gif")
caselavabo1=PhotoImage(file="lavabo1.gif")
caselavabo2=PhotoImage(file="lavabo2.gif")
caselavabo3=PhotoImage(file="lavabo3.gif")
caselavabo4=PhotoImage(file="lavabo4.gif")
casewc2=PhotoImage(file="wc2.gif")
caseTV=PhotoImage(file="TV.gif")
casecanapé2=PhotoImage(file="canape2.gif")
casecanapé1=PhotoImage(file="canape1.gif")

case1bureau1=PhotoImage(file="1bureau1.gif")
case1bureau2=PhotoImage(file="1bureau2.gif")
case1cuisine1=PhotoImage(file="1cuisine1.gif")
case1cuisine2=PhotoImage(file="1cuisine2.gif")
case1cuisine3=PhotoImage(file="1cuisine3.gif")
case1cuisine4=PhotoImage(file="1cuisine4.gif")
case1cuisine5=PhotoImage(file="1cuisine5.gif")
case1cuisine6=PhotoImage(file="1cuisine6.gif")
case1lavabo1=PhotoImage(file="1sdb1.gif")
case1lavabo2=PhotoImage(file="1sdb2.gif")
case1lavabo3=PhotoImage(file="1sdb3.gif")
case1lavabo4=PhotoImage(file="1sdb4.gif")
case1wc2=PhotoImage(file="1wc.gif")
case1tv=PhotoImage(file="1tv.gif")
case1canapé2=PhotoImage(file="1canape2.gif")
case1canapé1=PhotoImage(file="1canape1.gif")
case1murfenetre=PhotoImage(file="1fenetre.gif")
case1porte=PhotoImage(file="1porte.gif")
case1sol=PhotoImage(file="1sol.gif")
case1sol1=PhotoImage(file="1sol1.gif")
case1table1=PhotoImage(file="1table1.gif")
case1table2=PhotoImage(file="1table2.gif")
case1table3=PhotoImage(file="1table3.gif")
case1table4=PhotoImage(file="1table4.gif")
case1lit=PhotoImage(file="1lit.gif")
case1baignoire=PhotoImage(file="1bain.gif")
case1mur=PhotoImage(file="1mur.gif")

caseindice1=PhotoImage(file="indice1.gif")
caseindice2=PhotoImage(file="indice2.gif")
caseindice3=PhotoImage(file="indice3.gif")




droite1=PhotoImage(file="hero3.gif")
droite2=PhotoImage(file="heroA3.gif")
gauche1=PhotoImage(file="hero2.gif")
gauche2=PhotoImage(file="heroA2.gif")
descend1=PhotoImage(file="hero1.gif")
descend2=PhotoImage(file="heroA1.gif")
monte1=PhotoImage(file="hero4.gif")
monte2=PhotoImage(file="heroA4.gif")
pnj1=PhotoImage(file="pnj1.gif")
pnj2=PhotoImage(file="pnj2.gif")
pnj3=PhotoImage(file="pnj3.gif")

casemurfenetre=PhotoImage(file="mur fenetre.gif")
caseporte=PhotoImage(file="porte.gif")
casesol=PhotoImage(file="sol.gif")
casesol1=PhotoImage(file="sol1.gif")
casetv=PhotoImage(file="TV.gif")
casetable1=PhotoImage(file="table1.gif")
casetable2=PhotoImage(file="table2.gif")
casetable3=PhotoImage(file="table3.gif")
casetable4=PhotoImage(file="table4.gif")
caselit=PhotoImage(file="lit.gif")
casebaignoire=PhotoImage(file="baignoire.gif")
casemur=PhotoImage(file="mur simple.gif")

tab_droite=[droite1,droite2]
tab_gauche=[gauche2,gauche1]
tab_haut=[monte1,monte2]
tab_bas=[descend1,descend2]

compteur_de_pas=0
#creation de la matrice
LL0=["B","B","B","B","B","B","B","B","B","B","B","B","B","B","B"]
LL1=["B","H","H","E","E","B","MP3","MP4","H","B","E","E","H","H","B"]
LL2=["B","H","H","E","E","B","MP1","MP2","m","B","E","E","H","H","B"]
LL3=["B","H","H","E","E","B","H","H","H","B","E","E","H","H","B"]
LL4=["B","H","H","H","H","H","H","H","H","H","H","H","H","H","B"]
LL5=["B","B","B","A","H","H","H","H","H","H","H","A","B","B","B"]
LL6=["B","H","E","E","B","H","H","H","H","H","B","E","E","H","B"]
LL7=["B","H","H","E","E","B","H","H","H","B","E","E","H","H","B"]
LL8=["B","H","H","H","E","E","P","P","P","E","E","H","H","H","B"]
LL9=["B","A","A","A","A","A","H","H","H","A","A","A","A","A","B"]
LL10=["B","H","H","H","H","H","M7","M8","M9","H","H","H","H","H","B"]
LL11=["B","H","H","H","H","H","M4","M5","M6","H","H","H","H","H","B"]
LL12=["B","H","H","H","H","H","M1","M2","M3","H","H","H","H","H","B"]


L6=["M","C4","C5","C6","M","M","M","D","M","MF","M","MF","M","M","M"]
L7=["M","C1","C2","C3","S","M","S","S","S","S","S","S","S","S","M"]
L8=["M","S","S","S","S","M","S","S","S","S","S","S","S","S","M"]
L9=["M","S","S","S","S","S","S","S","S","S","S","T1","T2","S","M"]
L10=["M","M","L3","L4","M","M","S","S","M","S","S","T3","T4","S","M"]
L11=["M","S","L1","L2","S","S","S","S","M","S","S","S","S","S","M"]
L12=["M","Z","S","S","S","M","S","S","M","S","S","S","S","S","M"]
L13=["M","M","M","M","M","M","S","S","M","M","M","M","M","M","M"]
L14=["M","L","L","M","S","S","S","S","S","S","S","S","S","S","M"]
L15=["M","S","S","M","WC2","M","S","S","M","TV","S","can1","S","S","M"]
L16=["M","S","S","M","M","M","S","S","M","TV","S","can2","S","s","M"]
L17=["M","S","S","S","S","S","S","S","S","S","S","S","S","S","M"]
L18=["M","M","M","M","M","M","M","M","M","M","M","M","M","M","M"]

L06=["1M","1C4","1C5","1C6","1M","1M","1M","1D","1M","1MF","1M","1MF","1M","1M","1M"]
L07=["1M","1C1","1C2","1C3","1S","1M","1S","1S","1S","1S","1S","1S","1S","1S","1M"]
L08=["1M","I1","1S","1S","1S","1M","1S","1S","1S","1S","1S","1S","1S","1S","1M"]
L09=["1M","I1","1S","1S","1S","1S","1S","1S","1S","1S","1S","1T3","1T4","1S","1M"]
L010=["1M","1M","1L3","1L4","1M","1M","1S","1S","1M","1S","1S","1T1","1T2","1S","1M"]
L011=["1M","1S","1L1","1L2","1S","1S","1S","1S","1M","1S","1S","1S","1S","1S","1M"]
L012=["1M","1Z","1S","1S","1S","1M","1S","1S","1M","1S","1S","1S","1S","1S","1M"]
L013=["1M","1M","1M","1M","1M","1M","1S","1S","1M","1M","1M","1M","1M","1M","1M"]
L014=["1M","1L","1L","1M","1S","1S","1S","1S","1S","1S","1S","1S","1S","1S","1M"]
L015=["1M","I2","1S","1M","1WC2","1M","1S","1S","1M","1TV","1S","I3","1S","1S","1M"]
L016=["1M","1S","1S","1M","1M","1M","1S","1S","1M","1TV","1S","1can1","1S","1s","1M"]
L017=["1M","1S","1S","1S","1S","1S","1S","1S","1S","1S","1S","1S","1S","1S","1M"]
L018=["1M","1M","1M","1M","1M","1M","1M","1M","1M","1M","1M","1M","1M","1M","1M"]



ma_matrice=[LL0,LL1,LL2,LL3,LL4,LL5,LL6,LL7,LL8,LL9,LL10,LL11,LL12]
ma_matrice2=[L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18]
ma_matrice3=[L06,L07,L08,L09,L010,L011,L012,L013,L014,L015,L016,L017,L018]
#creation de la map
dico={"I1":caseindice1,"I2":caseindice2,"I3":caseindice3,"1S":case1sol,"1s":case1sol1,"1D":case1porte,"1T1":case1table1,"1T2":case1table2,"1T3":case1table3,"1T4":case1table4,"1M":case1mur,"1MF":case1murfenetre,"1TV":case1tv,"1L":case1lit,"1Z":case1baignoire,"1C1":case1cuisine1,"1C2":case1cuisine2,"1C3":case1cuisine3,"1C4":case1cuisine4,"1C5":case1cuisine5,"1C6":case1cuisine6,"1L1":case1lavabo1,"1L2":case1lavabo2,"1L3":case1lavabo3,"1L4":case1lavabo4,"1WC2":case1wc2,"1can1":case1canapé1,"1can2":case1canapé2,"MP1":casemaisonpnj1,"m":marchand,"MP2":casemaisonpnj2,"MP3":casemaisonpnj3,"MP4":casemaisonpnj4,"E":caseeau,"P":casepont,"S":casesol,"s":casesol1,"B":casebuisson,"A":casebarriere,"H":caseherbe,"M1":casemaison1,"M2":casemaison2,"M3":casemaison3,"M4":casemaison4,"M5":casemaison5,"M6":casemaison6,"M7":casemaison7,"M8":casemaison8,"M9":casemaison9,"N":casenoire,"D":caseporte,"T1":casetable1,"T2":casetable2,"T3":casetable3,"T4":casetable4,"M":casemur,"MF":casemurfenetre,"TV":casetv,"L":caselit,"Z":casebaignoire,"C1":casecuisine1,"C2":casecuisine2,"C3":casecuisine3,"C4":casecuisine4,"C5":casecuisine5,"C6":casecuisine6,"L1":caselavabo1,"L2":caselavabo2,"L3":caselavabo3,"L4":caselavabo4,"WC2":casewc2,"TV":caseTV,"can1":casecanapé1,"can2":casecanapé2}
for i in range(13):
    for j in range(15):
        can1.create_image(50*j,50*i,image=dico[ma_matrice[i][j]],anchor="nw")
niveau=0
#position du personnage
posX=50  #abscisse de départ
posY=50 #ordonnée de départ
posiX=300
posiY=50
n=0
a=0
b=0
c=0



perso=can1.create_image(posX,posY,image=descend2,anchor="nw")
pnj=can2.create_image(posX,posY,image=pnj2,anchor="nw")

#zones de texte
texte_pnj=can1.create_text(375,700,text="Retournez chez vous.",font=("courier new",14),fill="black")
texte_pnj1=can1.create_text(375,740,text="",font=("courier new",8),fill="blue")
texte_pnj2=can1.create_text(375,720,text="",font=("courier new",8),fill="black")
texte_pnj3=can3.create_text(375,720,text="",font=("courier new",8),fill="red")

def Clavier(event):
    #event recupère l'information tapéee sur le clavier
    global posX,posY,ma_matrice,niveau,posiX,posiY
    touche=event.keysym
    colonne=posX//50
    ligne=posY//50



    if niveau==0 :
        if touche=='Up' and ma_matrice[ligne-1][colonne]!="MP1" and ma_matrice[ligne-1][colonne]!="MP2" and ma_matrice[ligne-1][colonne]!="m" and ma_matrice[ligne-1][colonne]!="E" and ma_matrice[ligne-1][colonne]!="A" and ma_matrice[ligne-1][colonne]!="B":
            mvt_haut()
        if touche=="Right" and ma_matrice[ligne][colonne+1]!="MP1" and ma_matrice[ligne][colonne+1]!="MP2" and ma_matrice[ligne][colonne+1]!="m" and ma_matrice[ligne][colonne+1]!="E" and ma_matrice[ligne][colonne+1]!="A" and ma_matrice[ligne][colonne+1]!="B":
            mvt_droite()
        if touche=="Left" and ma_matrice[ligne][colonne-1]!="MP1" and ma_matrice[ligne][colonne-1]!="MP2" and ma_matrice[ligne][colonne-1]!="m" and ma_matrice[ligne][colonne-1]!="E" and ma_matrice[ligne][colonne-1]!="A" and ma_matrice[ligne][colonne-1]!="B":
            mvt_gauche()
        if touche=="Down" and ma_matrice[ligne+1][colonne]!="MP1" and ma_matrice[ligne+1][colonne]!="MP2" and ma_matrice[ligne+1][colonne]!="m" and ma_matrice[ligne+1][colonne]!="E" and ma_matrice[ligne+1][colonne]!="A" and ma_matrice[ligne+1][colonne]!="B":
            mvt_bas()

    if niveau==1 :
        if touche=='Up' and ma_matrice2[ligne-1][colonne]!="Z" and ma_matrice2[ligne-1][colonne]!="can1" and ma_matrice2[ligne-1][colonne]!="can2" and ma_matrice2[ligne-1][colonne]!="L" and ma_matrice2[ligne-1][colonne]!="WC2" and ma_matrice2[ligne-1][colonne]!="L3" and ma_matrice2[ligne-1][colonne]!="L4" and ma_matrice2[ligne-1][colonne]!="C4" and ma_matrice2[ligne-1][colonne]!="C5" and ma_matrice2[ligne-1][colonne]!="C6" and ma_matrice2[ligne-1][colonne]!="T4" and ma_matrice2[ligne-1][colonne]!="T3" and ma_matrice2[ligne-1][colonne]!="T2" and ma_matrice2[ligne-1][colonne]!="T1" and ma_matrice2[ligne-1][colonne]!="N" and ma_matrice2[ligne-1][colonne]!="M" and ma_matrice2[ligne-1][colonne]!="MF" and ma_matrice2[ligne-1][colonne]!="s":
            mvt_haut()
        if touche=="Right" and ma_matrice2[ligne][colonne+1]!="Z" and ma_matrice2[ligne][colonne+1]!="can1" and ma_matrice2[ligne][colonne+1]!="can2" and ma_matrice2[ligne][colonne+1]!="L" and ma_matrice2[ligne][colonne+1]!="WC2" and ma_matrice2[ligne][colonne+1]!="L3" and ma_matrice2[ligne][colonne+1]!="L4" and ma_matrice2[ligne][colonne+1]!="C4" and ma_matrice2[ligne][colonne+1]!="C5" and ma_matrice2[ligne][colonne+1]!="C6" and ma_matrice2[ligne][colonne+1]!="T4"and ma_matrice2[ligne][colonne+1]!="T3" and ma_matrice2[ligne][colonne+1]!="T2" and ma_matrice2[ligne][colonne+1]!="T1" and ma_matrice2[ligne][colonne+1]!="N" and ma_matrice2[ligne][colonne+1]!="M" and ma_matrice2[ligne][colonne+1]!="MF" and ma_matrice2[ligne][colonne+1]!="s":
            mvt_droite()
        if touche=="Left" and ma_matrice2[ligne][colonne-1]!="Z" and ma_matrice2[ligne][colonne-1]!="can1" and ma_matrice2[ligne][colonne-1]!="can2" and ma_matrice2[ligne][colonne-1]!="L" and ma_matrice2[ligne][colonne-1]!="WC2" and ma_matrice2[ligne][colonne-1]!="L3" and ma_matrice2[ligne][colonne-1]!="L4" and ma_matrice2[ligne][colonne-1]!="C4" and ma_matrice2[ligne][colonne-1]!="C5" and ma_matrice2[ligne][colonne-1]!="C6" and ma_matrice2[ligne][colonne-1]!="T4" and ma_matrice2[ligne][colonne-1]!="T3" and ma_matrice2[ligne][colonne-1]!="T2" and ma_matrice2[ligne][colonne-1]!="T1" and ma_matrice2[ligne][colonne-1]!="N" and ma_matrice2[ligne][colonne-1]!="M" and ma_matrice2[ligne][colonne-1]!="MF":
            mvt_gauche()
        if touche=="Down" and ma_matrice2[ligne+1][colonne]!="Z" and ma_matrice2[ligne+1][colonne]!="can1" and ma_matrice2[ligne+1][colonne]!="can2" and ma_matrice2[ligne+1][colonne]!="L" and ma_matrice2[ligne+1][colonne]!="WC2" and ma_matrice2[ligne+1][colonne]!="L3" and ma_matrice2[ligne+1][colonne]!="L4" and ma_matrice2[ligne+1][colonne]!="C4" and ma_matrice2[ligne+1][colonne]!="C5" and ma_matrice2[ligne+1][colonne]!="C6" and ma_matrice2[ligne+1][colonne]!="T4" and ma_matrice2[ligne+1][colonne]!="T3" and ma_matrice2[ligne+1][colonne]!="T2" and ma_matrice2[ligne+1][colonne]!="T1" and ma_matrice2[ligne+1][colonne]!="N" and ma_matrice2[ligne+1][colonne]!="M" and ma_matrice2[ligne+1][colonne]!="MF" and ma_matrice2[ligne+1][colonne]!="s":
            mvt_bas()
        if touche=="space":
            posiX=posX
            posiY=posY
            can2.after(1000,maison3)
    if niveau==2 :
        if touche=='Up' and ma_matrice2[ligne-1][colonne]!="Z" and ma_matrice2[ligne-1][colonne]!="can1" and ma_matrice2[ligne-1][colonne]!="can2" and ma_matrice2[ligne-1][colonne]!="L" and ma_matrice2[ligne-1][colonne]!="WC2" and ma_matrice2[ligne-1][colonne]!="L3" and ma_matrice2[ligne-1][colonne]!="L4" and ma_matrice2[ligne-1][colonne]!="C4" and ma_matrice2[ligne-1][colonne]!="C5" and ma_matrice2[ligne-1][colonne]!="C6" and ma_matrice2[ligne-1][colonne]!="T4" and ma_matrice2[ligne-1][colonne]!="T3" and ma_matrice2[ligne-1][colonne]!="T2" and ma_matrice2[ligne-1][colonne]!="T1" and ma_matrice2[ligne-1][colonne]!="N" and ma_matrice2[ligne-1][colonne]!="M" and ma_matrice2[ligne-1][colonne]!="MF" and ma_matrice2[ligne-1][colonne]!="s":
            mvt_haut()
        if touche=="Right" and ma_matrice2[ligne][colonne+1]!="Z" and ma_matrice2[ligne][colonne+1]!="can1" and ma_matrice2[ligne][colonne+1]!="can2" and ma_matrice2[ligne][colonne+1]!="L" and ma_matrice2[ligne][colonne+1]!="WC2" and ma_matrice2[ligne][colonne+1]!="L3" and ma_matrice2[ligne][colonne+1]!="L4" and ma_matrice2[ligne][colonne+1]!="C4" and ma_matrice2[ligne][colonne+1]!="C5" and ma_matrice2[ligne][colonne+1]!="C6" and ma_matrice2[ligne][colonne+1]!="T4"and ma_matrice2[ligne][colonne+1]!="T3" and ma_matrice2[ligne][colonne+1]!="T2" and ma_matrice2[ligne][colonne+1]!="T1" and ma_matrice2[ligne][colonne+1]!="N" and ma_matrice2[ligne][colonne+1]!="M" and ma_matrice2[ligne][colonne+1]!="MF" and ma_matrice2[ligne][colonne+1]!="s":
            mvt_droite()
        if touche=="Left" and ma_matrice2[ligne][colonne-1]!="Z" and ma_matrice2[ligne][colonne-1]!="can1" and ma_matrice2[ligne][colonne-1]!="can2" and ma_matrice2[ligne][colonne-1]!="L" and ma_matrice2[ligne][colonne-1]!="WC2" and ma_matrice2[ligne][colonne-1]!="L3" and ma_matrice2[ligne][colonne-1]!="L4" and ma_matrice2[ligne][colonne-1]!="C4" and ma_matrice2[ligne][colonne-1]!="C5" and ma_matrice2[ligne][colonne-1]!="C6" and ma_matrice2[ligne][colonne-1]!="T4" and ma_matrice2[ligne][colonne-1]!="T3" and ma_matrice2[ligne][colonne-1]!="T2" and ma_matrice2[ligne][colonne-1]!="T1" and ma_matrice2[ligne][colonne-1]!="N" and ma_matrice2[ligne][colonne-1]!="M" and ma_matrice2[ligne][colonne-1]!="MF":
            mvt_gauche()
        if touche=="Down" and ma_matrice2[ligne+1][colonne]!="Z" and ma_matrice2[ligne+1][colonne]!="can1" and ma_matrice2[ligne+1][colonne]!="can2" and ma_matrice2[ligne+1][colonne]!="L" and ma_matrice2[ligne+1][colonne]!="WC2" and ma_matrice2[ligne+1][colonne]!="L3" and ma_matrice2[ligne+1][colonne]!="L4" and ma_matrice2[ligne+1][colonne]!="C4" and ma_matrice2[ligne+1][colonne]!="C5" and ma_matrice2[ligne+1][colonne]!="C6" and ma_matrice2[ligne+1][colonne]!="T4" and ma_matrice2[ligne+1][colonne]!="T3" and ma_matrice2[ligne+1][colonne]!="T2" and ma_matrice2[ligne+1][colonne]!="T1" and ma_matrice2[ligne+1][colonne]!="N" and ma_matrice2[ligne+1][colonne]!="M" and ma_matrice2[ligne+1][colonne]!="MF" and ma_matrice2[ligne+1][colonne]!="s":
            mvt_bas()
        if touche=="space":
            posiX=posX
            posiY=posY
            can3.after(1000,maison2)






def mvt_gauche():
    """deplace à gauche le perso"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can,tab_bas,can1,can2,pnj,n,a,b,c
    posX=posX-50
    if posX<0 :
        posX=00

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_gauche[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    tab_can[niveau].coords(perso,posX,posY)
    if posX==50 and (posY==150 or posY==100) and niveau==2  and b==0:
        can3.create_text(230,690,text="Indice trouvé: empreintes de chaussures",font=("courier new",12),fill="blue")
        n+=1
        b+=1
    if posX==50 and (posY==450) and niveau==2 and a==0:
        can3.create_text(230,710,text="Indice trouvé: particules d'eau de cologne",font=("courier new",12),fill="blue")
        n+=1
        a+=1
    print(compteur_de_pas)
    if compteur_de_pas>120 and niveau==2:
        can3.after(1000,perdu)
    if n==3 and niveau==2:
        can3.after(1000,gagne)




def mvt_bas():
    """deplace le perso vers le bas"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can,tab_bas,can1,can2,pnj,n,a,b,c

    posY=posY+50
    if posY>1500 :
        posY=1500

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_bas[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    print(niveau)
    tab_can[niveau].coords(perso,posX,posY)
    if (posX==350 or posX==400 or posX==300)and posY==500 and niveau==0:
        can1.itemconfig(texte_pnj2,text="Vous obtenez la compétence 'Ultravision' !")
        can1.itemconfig(texte_pnj,text="BRAVO !")
        can1.delete(perso)
        can1.after(3000,maison)
    if posX==650 and posY==450:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY+50,image=pnj3,anchor="nw")
    if posX==650 and posY==550:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY-50,image=pnj1,anchor="nw")
    if posX==600 and posY==500:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX+50,posY,image=pnj2,anchor="nw")
    if posX==500 and (posY==450) and niveau==2 and c==0:
        can3.create_text(230,730,text="Indice trouvé: bijoux de Guillaume",font=("courier new",12),fill="blue")
        n+=1
        c+=1
    print(compteur_de_pas)
    if compteur_de_pas>120 and niveau==2:
        can3.after(1000,perdu)
    if n==3 and niveau==2:
        can3.after(1000,gagne)


def mvt_haut():
    """deplace le perso vers le haut"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can,tab_bas,can1,can2,pnj,n,a,b,c
    posY=posY-50
    if posY<0 :
        posY=0

        #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_haut[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    tab_can[niveau].coords(perso,posX,posY)
    if posX==400 and posY==150:
        can1.itemconfig(texte_pnj1,text="Marchand: Ton frère Ludo avait l'air inquiet, tu ferais mieux de le voir.")
    if posX==650 and posY==450:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY+50,image=pnj3,anchor="nw")
    if posX==650 and posY==550:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY-50,image=pnj1,anchor="nw")
    if posX==600 and posY==500:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX+50,posY,image=pnj2,anchor="nw")
    if posX==50 and (posY==450) and niveau==2 and a==0:
        can3.create_text(230,710,text="Indice trouvé: particules d'eau de cologne",font=("courier new",12),fill="blue")
        n+=1
        a+=1
    if posX==500 and (posY==450) and niveau==2 and c==0:
        can3.create_text(230,730,text="Indice trouvé: bijoux de Guillaume",font=("courier new",12),fill="blue")
        n+=1
        c+=1
    print(compteur_de_pas)
    if compteur_de_pas>120 and niveau==2:
        can3.after(1000,perdu)
    if n==3 and niveau==2:
        can3.after(1000,gagne)

def mvt_droite():
    """deplace à droite le perso"""
    global perso,posY,posX,compteur_de_pas,niveau,tab_can,tab_bas,can1,can2,pnj,n,a,b,c
    posX=posX+50
    if posX>1200 :
        posX=1200

    #mise à jour de l'image
    tab_can[niveau].itemconfig(perso,image=tab_droite[compteur_de_pas%2])
    compteur_de_pas+=1
    #mise à jour des coordonnées
    tab_can[niveau].coords(perso,posX,posY)
    if posX==650 and posY==450:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY+50,image=pnj3,anchor="nw")
    if posX==650 and posY==550:
        tab_can[niveau].delete(pnj)
        pnj=tab_can[niveau].create_image(posX,posY-50,image=pnj1,anchor="nw")
    if posX==600 and posY==500:
       tab_can[niveau].delete(pnj)
       pnj=tab_can[niveau].create_image(posX+50,posY,image=pnj2,anchor="nw")
    if posX==400 and posY==150:
        can1.itemconfig(texte_pnj1,text="Marchand: Tes parents m'ont demandé te prévenir qu'ils allaient rentrer tôt aujoud'hui.")
    if posX==500 and (posY==450) and niveau==2 and c==0:
        can3.create_text(230,730,text="Indice trouvé: bijoux de Guillaume",font=("courier new",12),fill="blue")
        n+=1
        c+=1
    print(compteur_de_pas)
    if compteur_de_pas>120 and niveau==2:
        can3.after(1000,perdu)
    if n==3 and niveau==2:
        can3.after(1000,gagne)



def maison():
    """2ème niveau"""
    global can1
    can1=Canvas(Mafenetre,bg="black",width=750,height=800)
    can1.place(x=0,y=0)
    can1.create_text(375,400,text="Ludo: Où est Guillaume ?!",fill="White")
    can1.after(3000,maison2)
def perdu():
    """echec du niveau"""
    global can1
    can1=Canvas(Mafenetre,bg="black",width=750,height=800)
    can1.place(x=0,y=0)
    can1.create_text(375,400,text="Vous avez perdu, vos parents sont rentrés et se sont enérvés suite à la disparition de Guillaume.",fill="White")
def  gagne():
    """succès du niveau"""
    global can1
    can1=Canvas(Mafenetre,bg="black",width=750,height=800)
    can1.place(x=0,y=0)
    can1.create_text(375,400,text="Vous avez retrouvé Guillaume, il s'était caché derrière la maison !",fill="White")
    if compteur_de_pas>110:
      can1.create_text(375,420,text="Ce fut tout de même in extremis, vos parents sont rentrés quelques secondes après que vous l'ayiez retrouvé. RANG : C",fill="White")
    if compteur_de_pas>90:
      can1.create_text(375,420,text="Bien joué ! Vous avez, vous trois, eu le temps de vous expliquez avant l'arrivée de vos parents. RANG : B",fill="White")
    if compteur_de_pas<90:
      can1.create_text(375,420,text="Excellent ! Après les explications de Guillaume, vous avez pu profiter de la maison pour une petiite heure. RANG : A",fill="White")


def maison2():
     global dico,niveau,can2,posX,posY,perso,posiX,posiY

     niveau=1
     can2=Canvas(Mafenetre,bg="black",width=750,height=800)
     can2.place(x=0,y=0)
     tab_can[1]=can2
     for i in range(13):
        for j in range(15):
          can2.create_image(50*j,50*i,image=dico[ma_matrice2[i][j]],anchor="nw")
     posX=650
     posY=500
     pnj=can2.create_image(posX,posY,image=pnj2,anchor="nw")
     posX=posiX
     posY=posiY
     perso=can2.create_image(posX,posY,image=descend2,anchor="nw")
     can2.create_text(375,740,text="Ludo: Aides-moi, t'es doué pour le trouver ! Appuies sur Espace !",font=("courier new",12),fill="blue")
     can2.focus_set()
     can2.bind('<Key>',Clavier)
     can2.bind('<space>',Clavier)


def maison3():
     global dico,niveau,can3,posX,posY,perso,posiX,posiY,compteur_de_pas

     niveau=2
     can3=Canvas(Mafenetre,bg="black",width=750,height=800)
     can3.place(x=0,y=0)
     tab_can[2]=can3
     for i in range(13):
        for j in range(15):
          can3.create_image(50*j,50*i,image=dico[ma_matrice3[i][j]],anchor="nw")
     posX=650
     posY=500
     pnj=can3.create_image(posX,posY,image=pnj2,anchor="nw")
     posX=posiX
     posY=posiY
     perso=can3.create_image(posX,posY,image=descend2,anchor="nw")
     can3.create_text(150,670,text="Trouvez des indices !",font=("courier new",12),fill="white")
     can3.focus_set()
     can3.bind('<Key>',Clavier)
     can3.bind('<space>',Clavier)



#programme principal
can1.focus_set()
can1.bind('<Key>',Clavier)

Mafenetre.mainloop()













